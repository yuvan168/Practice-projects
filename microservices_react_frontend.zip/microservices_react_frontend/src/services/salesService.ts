import api from './api';
import { Sale, SalesTrend } from '../types';

export const salesService = {
  getAllSales: async (): Promise<Sale[]> => {
    const response = await api.get<Sale[]>('/sales-service/sales/all');
    return response.data;
  },
  createSale: async (sale: Partial<Sale>): Promise<Sale> => {
    const response = await api.post<Sale>('/sales-service/sales', sale);
    return response.data;
  },
  getSalesByDateRange: async (startDate: string, endDate: string): Promise<Sale[]> => {
    const response = await api.get<Sale[]>('/sales-service/sales/date-range', { params: { startDate, endDate } });
    return response.data;
  },
  getSalesTrends: async (startDate?: string, endDate?: string): Promise<SalesTrend> => {
    const response = await api.get<SalesTrend>('/sales-service/sales/trends', { params: { startDate, endDate } });
    return response.data;
  },
  deleteSale: async (id: number): Promise<void> => {
    await api.delete(`/sales-service/sales/${id}`);
  },
  updateSale: async (id: number, sale: Partial<Sale>): Promise<Sale> => {
    const response = await api.put<Sale>(`/sales-service/sales/${id}`, sale);
    return response.data;
  },
};
