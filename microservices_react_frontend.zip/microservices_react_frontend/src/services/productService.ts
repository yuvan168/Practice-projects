import api from './api';
import { Product } from '../types';

export const productService = {
  getAllProducts: async (): Promise<Product[]> => {
    const response = await api.get<Product[]>('/product-service/products/all');
    return response.data;
  },
  getProductById: async (id: number): Promise<Product> => {
    const response = await api.get<Product>(`/product-service/products/${id}`);
    return response.data;
  },
  addProduct: async (product: Product): Promise<Product> => {
    const response = await api.post<Product>('/product-service/products', product);
    return response.data;
  },
  updateProduct: async (id: number, product: Product): Promise<Product> => {
    const response = await api.put<Product>(`/product-service/products/${id}`, product);
    return response.data;
  },
  deleteProduct: async (id: number): Promise<void> => {
    const response = await api.delete(`/product-service/products/${id}`);
    return response.data;
  },
};
