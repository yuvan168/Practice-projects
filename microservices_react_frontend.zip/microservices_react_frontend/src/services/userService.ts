import api from './api';
import { User, LoginRequest, LoginResponse } from '../types';

export const userService = {
  register: async (user: User): Promise<LoginResponse> => {
    const response = await api.post<LoginResponse>('/user-service/users/register', user);
    return response.data;
  },
  login: async (credentials: LoginRequest): Promise<LoginResponse> => {
    const response = await api.post<LoginResponse>('/user-service/users/login', credentials);
    return response.data;
  },
  getAllUsers: async (): Promise<User[]> => {
    const response = await api.get<User[]>('/user-service/users/all');
    return response.data;
  },
  getUserById: async (id: string): Promise<User> => {
    const response = await api.get<User>(`/user-service/users/${id}`);
    return response.data;
  },
  updateUser: async (id: string, user: User): Promise<User> => {
    const response = await api.put<User>(`/user-service/users/${id}`, user);
    return response.data;
  },
  deleteUser: async (id: string): Promise<void> => {
    const response = await api.delete(`/user-service/users/${id}`);
    return response.data;
  },
};
