import axios, { AxiosInstance, InternalAxiosRequestConfig } from 'axios';

const API_BASE_URL = 'http://localhost:3000'; // Use Vite dev server proxy

const api: AxiosInstance = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
});

api.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    const token = localStorage.getItem('token');
    const isAuthEndpoint = config.url?.includes('/login') || config.url?.includes('/register');
    
    // Set Content-Type if not already set
    if (!config.headers['Content-Type']) {
      config.headers['Content-Type'] = 'application/json';
    }
    
    // Add other headers that Postman sends by default
    config.headers['Accept'] = 'application/json';
    
    if (token && !isAuthEndpoint) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    
    if (config.method === 'get') {
      console.log(`🔍 GET Request to ${config.url}`, config.params);
    } else if (config.method === 'put' || config.method === 'post') {
      console.log(`🚀 ${config.method?.toUpperCase()} Request to ${config.url}:`, config.data);
    }
    
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

api.interceptors.response.use(
  (response) => {
    if (response.config.method === 'get') {
      console.log(`✅ GET Response from ${response.config.url}:`, response.data);
    } else if (response.config.method === 'put' || response.config.method === 'post') {
      console.log(`✅ ${response.config.method?.toUpperCase()} Response from ${response.config.url}:`, response.data);
    }
    return response;
  },
  (error) => {
    console.error('API Error:', {
      status: error.response?.status,
      data: error.response?.data,
      message: error.message,
      code: error.code,
    });
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    if (error.code === 'ERR_NETWORK') {
      console.error('Network error - ensure backend is running on port 8086');
    }
    return Promise.reject(error);
  }
);

export default api;
