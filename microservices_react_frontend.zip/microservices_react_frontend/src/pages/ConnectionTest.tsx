import React, { useState } from 'react';
import axios from 'axios';
import '../styles/Table.css';

const ConnectionTest: React.FC = () => {
  const [result, setResult] = useState<string>('');
  const [loading, setLoading] = useState(false);

  const testConnection = async () => {
    setLoading(true);
    setResult('Testing connection...');

    try {
      const response = await axios.post('http://localhost:8086/user-service/users/login', {
        email: 'test@test.com',
        password: 'test123',
      });
      setResult(`✓ Connection successful! Status: ${response.status}`);
    } catch (error: any) {
      setResult(
        `✗ Connection failed: ${error.message}\n\nMake sure the API Gateway is running on http://localhost:8086\n\nRequired services:\n1. Eureka Server (8761)\n2. Config Server (8888)\n3. API Gateway (8086)\n4. User Service (8081)\n5. Product Service (8082)\n6. Sales Service (8083)`
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>Backend Connection Test</h1>
      </div>

      <div className="test-card">
        <h2>API Gateway Status</h2>
        <p>Click the button to test connectivity to the API Gateway</p>
        <button onClick={testConnection} disabled={loading} className="btn-primary">
          {loading ? 'Testing...' : 'Test Connection'}
        </button>

        {result && (
          <div className="test-result">
            <h3>Result:</h3>
            <pre>{result}</pre>
          </div>
        )}

        <div className="services-checklist">
          <h3>Services Checklist:</h3>
          <ul>
            <li>🔷 Eureka Server: http://localhost:8761</li>
            <li>🔷 Config Server: http://localhost:8888</li>
            <li>🔷 API Gateway: http://localhost:8086</li>
            <li>🔷 User Service: http://localhost:8081</li>
            <li>🔷 Product Service: http://localhost:8082</li>
            <li>🔷 Sales Service: http://localhost:8083</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default ConnectionTest;
