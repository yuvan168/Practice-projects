import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import '../styles/Dashboard.css';

const Dashboard: React.FC = () => {
  const { user } = useAuth();

  return (
    <div className="dashboard-container">
      <div className="welcome-section">
        <h1>Welcome, {user?.firstName}!</h1>
        <p>Manage your inventory system from here</p>
      </div>

      <div className="dashboard-grid">
        <Link to="/users" className="dashboard-card">
          <div className="card-icon">👥</div>
          <h3>Users</h3>
          <p>Manage user accounts</p>
        </Link>

        <Link to="/products" className="dashboard-card">
          <div className="card-icon">📦</div>
          <h3>Products</h3>
          <p>Manage inventory products</p>
        </Link>

        <Link to="/sales" className="dashboard-card">
          <div className="card-icon">💰</div>
          <h3>Sales</h3>
          <p>Record and manage sales</p>
        </Link>

        <Link to="/sales-trends" className="dashboard-card">
          <div className="card-icon">📈</div>
          <h3>Sales Trends</h3>
          <p>View analytics and trends</p>
        </Link>
      </div>
    </div>
  );
};

export default Dashboard;
