import React, { useState, useEffect, useRef } from 'react';
import { salesService } from '../services/salesService';
import { SalesTrend } from '../types';
import '../styles/Sales.css';

const SalesTrends: React.FC = () => {
  const [trends, setTrends] = useState<SalesTrend | null>(null);
  const [loading, setLoading] = useState(true);
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');

  useEffect(() => {
    // Set default date range (last 1 year)
    const today = new Date();
    const oneYearAgo = new Date(today.getTime() - 365 * 24 * 60 * 60 * 1000);
    
    const startStr = oneYearAgo.toISOString().split('T')[0];
    const endStr = today.toISOString().split('T')[0];
    
    setEndDate(endStr);
    setStartDate(startStr);
    
    // Fetch with calculated dates
    fetchTrendsData(startStr, endStr);
  }, []);

  const fetchTrendsData = async (start: string, end: string) => {
    try {
      setLoading(true);
      const data = await salesService.getSalesTrends(start, end);
      setTrends(data);
      setLoading(false);
    } catch (error) {
      console.error('Failed to fetch trends:', error);
      alert('Failed to load sales trends. Please check your connection.');
      setLoading(false);
    }
  };

  const fetchTrends = (start?: string, end?: string) => {
    fetchTrendsData(start || startDate, end || endDate);
  };

  const handleFilterClick = () => {
    if (!startDate || !endDate) {
      alert('Please select both start and end dates');
      return;
    }
    if (new Date(startDate) > new Date(endDate)) {
      alert('Start date must be before end date');
      return;
    }
    fetchTrends(startDate, endDate);
  };

  const handlePresetRange = (days: number, label: string) => {
    const today = new Date();
    const start = new Date(today.getTime() - days * 24 * 60 * 60 * 1000);
    
    const startStr = start.toISOString().split('T')[0];
    const endStr = today.toISOString().split('T')[0];
    
    setStartDate(startStr);
    setEndDate(endStr);
    fetchTrendsData(startStr, endStr);
  };

  const handleRefreshDefault = () => {
    const today = new Date();
    const oneYearAgo = new Date(today.getTime() - 365 * 24 * 60 * 60 * 1000);
    
    const startStr = oneYearAgo.toISOString().split('T')[0];
    const endStr = today.toISOString().split('T')[0];
    
    setStartDate(startStr);
    setEndDate(endStr);
    fetchTrendsData(startStr, endStr);
  };

  // Calculate monthly aggregates from daily data and fill missing months
  const calculateMonthlyData = () => {
    if (!trends) return { monthlyRevenue: {}, monthlyCount: {} };

    const monthlyRevenue: { [key: string]: number } = {};
    const monthlyCount: { [key: string]: number } = {};

    // Aggregate daily data
    Object.entries(trends.dailyRevenue).forEach(([date, revenue]) => {
      const monthKey = date.substring(0, 7); // YYYY-MM format
      monthlyRevenue[monthKey] = (monthlyRevenue[monthKey] || 0) + revenue;
    });

    Object.entries(trends.dailyCount).forEach(([date, count]) => {
      const monthKey = date.substring(0, 7); // YYYY-MM format
      monthlyCount[monthKey] = (monthlyCount[monthKey] || 0) + count;
    });

    // Fill in missing months with 0 to show complete picture
    const startDate = new Date(trends.startDate);
    const endDate = new Date(trends.endDate);
    
    for (let date = new Date(startDate); date <= endDate; date.setMonth(date.getMonth() + 1)) {
      const monthKey = date.toISOString().substring(0, 7);
      if (!(monthKey in monthlyRevenue)) {
        monthlyRevenue[monthKey] = 0;
      }
      if (!(monthKey in monthlyCount)) {
        monthlyCount[monthKey] = 0;
      }
    }

    return { monthlyRevenue, monthlyCount };
  };

  if (loading || !trends) {
    return <div className="page-container">Loading...</div>;
  }

  const { monthlyRevenue, monthlyCount } = calculateMonthlyData();

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>Sales Trends</h1>
      </div>

      <div className="filter-form">
        <div className="filter-form" style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', alignItems: 'flex-end' }}>
            <div className="form-group" style={{ flex: 1, minWidth: '150px', margin: 0 }}>
              <label style={{ display: 'block', marginBottom: '5px', fontWeight: 500 }}>Start Date</label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
            </div>
            <div className="form-group" style={{ flex: 1, minWidth: '150px', margin: 0 }}>
              <label style={{ display: 'block', marginBottom: '5px', fontWeight: 500 }}>End Date</label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>
            <button onClick={handleFilterClick} className="btn-primary" style={{ whiteSpace: 'nowrap' }}>
              🔍 Apply Filter
            </button>
          </div>
          
          <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
            <span style={{ fontWeight: 500, alignSelf: 'center' }}>Quick Select:</span>
            <button 
              onClick={() => handlePresetRange(7, 'Last 7 Days')} 
              className="btn-secondary"
              style={{ padding: '6px 12px', fontSize: '12px' }}
            >
              📅 Last 7 Days
            </button>
            <button 
              onClick={() => handlePresetRange(30, 'Last 30 Days')} 
              className="btn-secondary"
              style={{ padding: '6px 12px', fontSize: '12px' }}
            >
              📅 Last 30 Days
            </button>
            <button 
              onClick={() => handlePresetRange(90, 'Last 90 Days')} 
              className="btn-secondary"
              style={{ padding: '6px 12px', fontSize: '12px' }}
            >
              📅 Last 90 Days
            </button>
            <button 
              onClick={() => handlePresetRange(365, 'Last Year')} 
              className="btn-secondary"
              style={{ padding: '6px 12px', fontSize: '12px' }}
            >
              📅 Last Year
            </button>
            <button 
              onClick={handleRefreshDefault} 
              className="btn-primary"
              style={{ padding: '6px 12px', fontSize: '12px', marginLeft: 'auto' }}
              title="Reset to default time period (Last 1 Year)"
            >
              🔄 Refresh
            </button>
          </div>
        </div>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <h3>Total Revenue</h3>
          <p className="stat-value">₹{trends.totalRevenue.toFixed(2)}</p>
        </div>
        <div className="stat-card">
          <h3>Total Sales</h3>
          <p className="stat-value">{trends.totalSales}</p>
        </div>
        <div className="stat-card">
          <h3>Average Sale</h3>
          <p className="stat-value">
            ₹{trends.totalSales > 0 ? (trends.totalRevenue / trends.totalSales).toFixed(2) : '0.00'}
          </p>
        </div>
        <div className="stat-card">
          <h3>Period</h3>
          <p className="stat-value">
            {new Date(trends.startDate).toLocaleDateString()} - {new Date(trends.endDate).toLocaleDateString()}
          </p>
        </div>
      </div>

      <div className="charts-container">
        <div className="chart">
          <h3>Daily Revenue</h3>
          <div className="bar-chart">
            {Object.keys(trends.dailyRevenue).length > 0 ? (
              Object.entries(trends.dailyRevenue).map(([date, revenue]) => {
                const maxRevenue = Math.max(...Object.values(trends.dailyRevenue));
                return (
                <div key={date} className="bar-container">
                  <div>
                                      ₹{revenue.toFixed(0)}
                                    </div>                  <div
                    className="bar"
                    style={{
                      height: `${(revenue / (maxRevenue || 1)) * 200}px`,
                      background: 'linear-gradient(to top, #667eea, #764ba2)',
                    }}
                  >
                    <span className="value"></span>
                  </div>
                  <span className="label">{new Date(date).toLocaleDateString()}</span>
                </div>
                );
              })
            ) : (
              <p>No data available</p>
            )}
          </div>
        </div>

        <div className="chart">
          <h3>Daily Sales Count</h3>
          <div className="bar-chart">
            {Object.keys(trends.dailyCount).length > 0 ? (
              Object.entries(trends.dailyCount).map(([date, count]) => {
                const maxCount = Math.max(...Object.values(trends.dailyCount));
                return (
                <div key={date} className="bar-container">
                  <div 
                    style={{ 
                      fontSize: '11px', 
                      fontWeight: 'bold', 
                      color: '#1565c0',
                      marginBottom: '4px',
                      minHeight: '16px'
                    }}
                  >
                    {count}
                  </div>
                  <div
                    className="bar"
                    style={{
                      height: `${(count / (maxCount || 1)) * 200}px`,
                      background: 'linear-gradient(to top, #0ea5e9, #0284c7)',
                    }}
                  >
                    <span className="value"></span>
                  </div>
                  <span className="label">{new Date(date).toLocaleDateString()}</span>
                </div>
                );
              })
            ) : (
              <p>No data available</p>
            )}
          </div>
        </div>
      </div>

      <div className="top-products">
        <h3>📊 Monthly Summary</h3>
        <table className="data-table">
          <thead>
            <tr>
              <th>Month</th>
              <th>Revenue</th>
              <th>Sales Count</th>
              <th>Avg Sale</th>
            </tr>
          </thead>
          <tbody>
            {Object.keys(monthlyRevenue).length > 0 ? (
              Object.entries(monthlyRevenue)
                .sort(([monthA], [monthB]) => monthA.localeCompare(monthB))
                .map(([month]) => {
                  const monthDate = new Date(month + '-01');
                  const monthLabel = monthDate.toLocaleDateString('en-US', { year: 'numeric', month: 'long' });
                  const revenue = monthlyRevenue[month] || 0;
                  const count = monthlyCount[month] || 0;
                  const avgSale = count > 0 ? revenue / count : 0;
                  
                  return (
                    <tr key={month}>
                      <td><strong>{monthLabel}</strong></td>
                      <td style={{ fontWeight: 'bold', color: '#10b981' }}>₹{revenue.toFixed(2)}</td>
                      <td style={{ fontWeight: 'bold', color: '#3b82f6' }}>{count}</td>
                      <td style={{ fontWeight: 'bold', color: '#667eea' }}>₹{avgSale.toFixed(2)}</td>
                    </tr>
                  );
                })
            ) : (
              <tr>
                <td colSpan={4} style={{ textAlign: 'center', padding: '20px', color: '#999' }}>
                  No monthly data available
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="top-products">
        <h3>📦 All Products</h3>
        <table className="data-table">
          <thead>
            <tr>
              <th>Rank</th>
              <th>Product</th>
              <th>Total Sales</th>
              <th>Revenue</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {trends.topProducts && trends.topProducts.length > 0 ? (
              trends.topProducts.map((product, index) => (
                <tr key={product.productId} style={{
                  backgroundColor: product.totalRevenue === 0 || product.totalQuantity === 0 ? '#fff3e0' : 'transparent'
                }}>
                  <td className={`rank rank-${index + 1}`}>#{index + 1}</td>
                  <td><strong>{product.productName}</strong></td>
                  <td>{product.totalQuantity}</td>
                  <td>₹{product.totalRevenue.toFixed(2)}</td>
                  <td>
                    {product.totalRevenue === 0 || product.totalQuantity === 0 ? (
                      <span style={{ color: '#f57f17', fontWeight: 'bold' }}>📦 No Sales Yet</span>
                    ) : (
                      <span style={{ color: '#2e7d32', fontWeight: 'bold' }}>✅ Active</span>
                    )}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={5} style={{ textAlign: 'center', padding: '20px', color: '#999' }}>
                  📭 No products found in this date range
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default SalesTrends;
