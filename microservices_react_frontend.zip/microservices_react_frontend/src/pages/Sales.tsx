import React, { useState, useEffect } from 'react';
import { salesService } from '../services/salesService';
import { productService } from '../services/productService';
import { Sale, Product } from '../types';
import '../styles/Table.css';

const Sales: React.FC = () => {
  const [sales, setSales] = useState<Sale[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState<Partial<Sale>>({
    productId: undefined,
    productName: '',
    quantity: 1,
    unitPrice: 0,
    totalPrice: 0,
    saleDate: new Date().toISOString(),
    customerName: '',
    customerEmail: '',
  });

  // Helper to ensure quantity defaults to 1 if not set
  const getQuantity = (): number => {
    return formData.quantity && formData.quantity > 0 ? formData.quantity : 1;
  };

  useEffect(() => {
    fetchSales();
    fetchProducts();
  }, []);

  const fetchSales = async () => {
    setLoading(true);
    try {
      const data = await salesService.getAllSales();
      setSales(data);
    } catch (error) {
      console.error('Failed to fetch sales:', error);
      alert('Failed to load sales. Please check your connection and try again.');
    } finally {
      setLoading(false);
    }
  };

  const fetchProducts = async () => {
    try {
      const data = await productService.getAllProducts();
      console.log('📦 Products loaded:', data.length, data);
      setProducts(data);
    } catch (error) {
      console.error('❌ Failed to fetch products:', error);
      alert('⚠️ Failed to load products. Make sure product service is running.');
    }
  };

  const handleOpenModal = (sale?: Sale) => {
    if (sale) {
      setEditingId(sale.id || null);
      
      // Safely handle the date - it might be in different formats from backend
      let dateString = '';
      if (sale.saleDate) {
        // If it contains 'T', split on it; otherwise assume it's just a date
        if (typeof sale.saleDate === 'string' && sale.saleDate.includes('T')) {
          dateString = sale.saleDate.split('T')[0];
        } else if (typeof sale.saleDate === 'string') {
          dateString = sale.saleDate;
        } else {
          dateString = new Date(sale.saleDate).toISOString().split('T')[0];
        }
      } else {
        dateString = new Date().toISOString().split('T')[0];
      }
      
      setFormData({
        id: sale.id,
        productId: sale.productId,
        productName: sale.productName,
        quantity: sale.quantity,
        unitPrice: sale.unitPrice,
        totalPrice: sale.totalPrice,
        saleDate: dateString + 'T00:00:00',
        customerName: sale.customerName,
        customerEmail: sale.customerEmail,
      });
    } else {
      setEditingId(null);
      const today = new Date();
      const dateString = today.toISOString().split('T')[0];
      
      setFormData({
        productId: undefined,
        productName: '',
        quantity: 1,
        unitPrice: 0,
        totalPrice: 0,
        saleDate: dateString + 'T00:00:00',
        customerName: '',
        customerEmail: '',
      });
    }
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditingId(null);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;

    setFormData((prev) => {
      let updatedState = { ...prev };

      if (name === 'productId') {
        const productId = parseInt(value, 10);
        const selectedProduct = products.find((p) => p.id === productId);
        updatedState.productId = productId;
        updatedState.productName = selectedProduct?.name || '';
        updatedState.unitPrice = selectedProduct?.price || 0;
      } else if (name === 'quantity') {
        updatedState.quantity = parseInt(value, 10) || 1;
      } else if (name === 'saleDate') {
        // Format date as ISO string: YYYY-MM-DDTHH:mm:ss
        if (value) {
          updatedState.saleDate = `${value}T00:00:00`;
        }
      } else {
        updatedState = { ...updatedState, [name]: value };
      }

      updatedState.totalPrice = (updatedState.quantity || 1) * (updatedState.unitPrice || 0);
      return updatedState;
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    console.log('📋 Form validation starting...', { formData });

    if (!formData.productId) {
      console.warn('❌ No product selected');
      alert('Please select a product');
      return;
    }
    const quantity = getQuantity();
    if (quantity < 1) {
      console.warn('❌ Invalid quantity:', quantity);
      alert('Quantity must be at least 1');
      return;
    }
    if (!formData.customerName || formData.customerName.trim() === '') {
      console.warn('❌ No customer name');
      alert('Please enter customer name');
      return;
    }
    if (!formData.customerEmail || formData.customerEmail.trim() === '') {
      console.warn('❌ No customer email');
      alert('Please enter customer email');
      return;
    }

    try {
      // Ensure all numeric fields are numbers
      const dataToSend = {
        productId: Number(formData.productId),
        productName: String(formData.productName),
        quantity: getQuantity(),
        unitPrice: Number(formData.unitPrice),
        totalPrice: Number(formData.totalPrice),
        saleDate: String(formData.saleDate),
        customerName: String(formData.customerName).trim(),
        customerEmail: String(formData.customerEmail).trim(),
      };

      console.log('📤 Sending sale data:', JSON.stringify(dataToSend, null, 2));
      console.log('🔗 URL: /sales-service/sales' + (editingId ? `/${editingId}` : ''));

      if (editingId) {
        console.log(`⬆️  Updating sale ID: ${editingId}`);
        await salesService.updateSale(editingId, dataToSend);
        alert('✅ Sale updated successfully!');
      } else {
        console.log('➕ Creating new sale');
        await salesService.createSale(dataToSend);
        alert('✅ Sale recorded successfully!');
      }
      
      console.log('🔄 Refreshing sales list...');
      fetchSales();
      handleCloseModal();
    } catch (error: any) {
      console.error('❌ Error occurred:', error);
      console.error('   Status:', error.response?.status);
      console.error('   Data:', error.response?.data);
      console.error('   Message:', error.message);
      console.error('   Code:', error.code);
      
      const errorMsg = error.response?.data?.message || 
                       error.response?.data?.error || 
                       error.message || 
                       'Unknown error - check backend is running on port 8086';
      
      alert(`❌ Failed to ${editingId ? 'update' : 'create'} sale:\n\n${errorMsg}`);
    }
  };

  const handleDelete = async (id: number | undefined) => {
    if (typeof id !== 'number') return;
    
    if (window.confirm('Are you sure you want to delete this sale?')) {
      try {
        await salesService.deleteSale(id);
        fetchSales();
      } catch (error) {
        console.error('Failed to delete sale:', error);
      }
    }
  };



  return (
    <div className="page-container">
      <div className="page-header">
        <h1>Sales</h1>
        <button onClick={handleOpenModal} className="btn-primary">
          ➕ Record Sale
        </button>
      </div>

      {loading ? (
        <div className="loading">Loading...</div>
      ) : (
        <table className="data-table">
          <thead>
            <tr>
              <th>Product</th>
              <th>Customer</th>
              <th>Quantity</th>
              <th>Unit Price</th>
              <th>Total Price</th>
              <th>Sale Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {sales.map((sale) => (
              <tr key={sale.id}>
                <td><strong>{sale.productName}</strong></td>
                <td>{sale.customerName}</td>
                <td>{sale.quantity}</td>
                <td>₹{sale.unitPrice.toFixed(2)}</td>
                <td style={{ fontWeight: 'bold', color: '#2e7d32' }}>
                  ₹{sale.totalPrice.toFixed(2)}
                </td>
                <td>{new Date(sale.saleDate).toLocaleDateString()}</td>
                <td className="action-buttons">
                  <button onClick={() => handleOpenModal(sale)} className="btn-edit">
                    Edit
                  </button>
                  <button onClick={() => handleDelete(sale.id)} className="btn-delete">
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {showModal && (
        <div className="modal-overlay" onClick={handleCloseModal}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>{editingId ? 'Edit Sale' : 'Record Sale'}</h2>
              <button onClick={handleCloseModal} className="close-btn">×</button>
            </div>
            <form onSubmit={handleSubmit} className="modal-form">
              <div className="form-group">
                <label>Product *</label>
                <select 
                  name="productId" 
                  value={formData.productId || ''} 
                  onChange={handleChange} 
                  required
                >
                  <option value="">-- Select a product --</option>
                  {products.length > 0 ? (
                    products.map((product) => (
                      <option key={product.id} value={product.id}>
                        {product.name} (₹{product.price?.toFixed(2) || '0.00'})
                      </option>
                    ))
                  ) : (
                    <option disabled>No products available</option>
                  )}
                </select>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Quantity *</label>
                  <input
                    type="number"
                    name="quantity"
                    value={getQuantity()}
                    onChange={handleChange}
                    min="1"
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Unit Price</label>
                  <input 
                    type="number" 
                    value={formData.unitPrice || 0} 
                    readOnly 
                    step="0.01"
                  />
                </div>
              </div>
              <div className="form-group">
                <label>Total Price</label>
                <input 
                  type="number" 
                  value={formData.totalPrice?.toFixed(2) || '0.00'} 
                  readOnly 
                  step="0.01"
                />
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Customer Name *</label>
                  <input
                    type="text"
                    name="customerName"
                    value={formData.customerName || ''}
                    onChange={handleChange}
                    placeholder="Enter customer name"
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Customer Email *</label>
                  <input
                    type="email"
                    name="customerEmail"
                    value={formData.customerEmail || ''}
                    onChange={handleChange}
                    placeholder="Enter customer email"
                    required
                  />
                </div>
              </div>
              <div className="form-group">
                <label>Sale Date *</label>
                <input
                  type="date"
                  name="saleDate"
                  value={formData.saleDate?.split('T')[0] || ''}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="modal-actions">
                <button type="button" onClick={handleCloseModal} className="btn-cancel">Cancel</button>
                <button type="submit" className="btn-primary">{editingId ? 'Update' : 'Record'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Sales;
