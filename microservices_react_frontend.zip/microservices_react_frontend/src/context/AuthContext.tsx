import React, { createContext, useContext, useState, useEffect } from 'react';
import { userService } from '../services/userService';
import { AuthContextType, User } from '../types';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);

  useEffect(() => {
    const storedToken = localStorage.getItem('token');
    const storedUser = localStorage.getItem('user');
    if (storedToken && storedUser) {
      setToken(storedToken);
      setUser(JSON.parse(storedUser));
      setIsAuthenticated(true);
    }
  }, []);

  const login = async (email: string, password: string) => {
    try {
      console.log('AuthContext: Starting login with email:', email);
      const response = await userService.login({ email, password });
      console.log('AuthContext: Login response received:', response);
      
      if (response.success && response.token) {
        const { token, ...userData } = response;
        const user: User = {
          email: userData.email || '',
          firstName: userData.firstName || '',
          lastName: userData.lastName || '',
          location: '',
          mobileNumber: '',
        };
        console.log('AuthContext: Setting user and token', user);
        setToken(token);
        setUser(user);
        setIsAuthenticated(true);
        localStorage.setItem('token', token);
        localStorage.setItem('user', JSON.stringify(user));
      } else {
        throw new Error(response.message || 'Invalid email or password');
      }
    } catch (error: any) {
      console.error('AuthContext: Login error caught:', {
        message: error.message,
        response: error.response?.data,
        status: error.response?.status,
        fullError: error
      });
      // Re-throw the error to be handled by the calling component (e.g., Login page)
      throw error;
    }
  };

  const logout = () => {
    setIsAuthenticated(false);
    setUser(null);
    setToken(null);
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, user, token, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};
