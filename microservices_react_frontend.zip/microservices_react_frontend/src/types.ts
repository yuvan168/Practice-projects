export interface User {
  id?: number;
  email: string;
  password?: string;
  firstName: string;
  lastName: string;
  location: string;
  mobileNumber: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  success: boolean;
  message: string;
  token?: string;
  email?: string;
  firstName?: string;
  lastName?: string;
}

export interface Product {
  id?: number;
  name: string;
  description: string;
  manufacturer: string;
  price: number;
  quantity: number;
  saleDate?: string; // Date in YYYY-MM-DD format
}

export interface Sale {
  id?: number;
  productId: number;
  productName: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  saleDate: string;
  customerName: string;
  customerEmail: string;
}

export interface TopProduct {
  productId: number;
  productName: string;
  totalQuantity: number;
  totalRevenue: number;
}

export interface SalesTrend {
  totalRevenue: number;
  totalSales: number;
  dailyRevenue: { [key: string]: number };
  dailyCount: { [key: string]: number };
  topProducts: TopProduct[];
  startDate: string;
  endDate: string;
}

export interface AuthContextType {
    isAuthenticated: boolean;
    user: User | null;
    token: string | null;
    login: (email: string, password: string) => Promise<void>;
    logout: () => void;
}
