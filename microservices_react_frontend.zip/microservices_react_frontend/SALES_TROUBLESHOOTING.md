# 🐛 Troubleshooting: Sale Date & Timeline Filter Issues

## Issues You're Experiencing

1. **Sale date in sales page not changing** - Date picker not updating visually
2. **No data displayed in timeline filter** - Filter returns empty results

## Why This Happens

### Issue 1: Sale Date Not Changing in Form

**Cause**: The date picker value is being updated internally but may not display visually if:
- Initial state was formatted as full ISO string (e.g., `2025-12-18T15:30:00`)
- Date input expects just `YYYY-MM-DD` format

**Fixed in**: Sales.tsx line 49-59
```typescript
// BEFORE (WRONG):
saleDate: new Date().toISOString()  // Returns: 2025-12-18T15:30:00.000Z

// AFTER (CORRECT):
const today = new Date();
const dateString = today.toISOString().split('T')[0];  // Returns: 2025-12-18
saleDate: dateString + 'T00:00:00'  // Stores as: 2025-12-18T00:00:00
```

### Issue 2: Timeline Filter Shows No Data

**Cause**: The filter returns empty results because:

1. **No sales exist in database** ← Primary cause
   - Sales creation is returning 400 error
   - So nothing gets saved to database
   - So filter can't find anything to display

2. **Sale was created but date is outside filter range**
   - Filter: 2025-12-01 to 2025-12-31
   - Sale date: 2025-11-30 (outside range)
   - Result: No matching data

3. **Backend date parsing issue**
   - Frontend sends: `startDate=2025-12-01&endDate=2025-12-31`
   - Backend might not be parsing correctly
   - Returns empty array

## How to Verify Each Issue

### Check 1: Can You Create a Sale?

```
Frontend Console:
  ✅ GOOD: "✅ Sale created successfully!"
  ❌ BAD: "❌ Failed to create sale: 400 Bad Request"
```

If getting 400 error, you need to fix Sale entity first (see Step 1 below).

### Check 2: Is Sale Saved in Database?

Go to backend database:
```sql
SELECT * FROM sales;
```

**Expected**: Should show your sale records
**Problem**: If empty, sale creation is failing

### Check 3: Is Date Filter Working?

Backend console should show:
```
🔍 getSalesTrends called with startDate=2025-12-01, endDate=2025-12-31
✅ Parsed startDate: 2025-12-01
✅ Parsed endDate: 2025-12-31
📊 Fetching trends from 2025-12-01 to 2025-12-31
```

If parsing fails, it logs error with details.

## Step-by-Step Fix

### Step 1: Fix Backend Sale Entity (CRITICAL)

Your `Sale.java` has issues. Replace it with `Sale_CORRECTED.java`:

**Key differences:**
```java
// ✅ ADDED: Jackson import for date handling
import com.fasterxml.jackson.annotation.JsonFormat;

// ✅ FIXED: Proper annotation with pattern
@Column(nullable = false)
@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
private LocalDateTime saleDate;

// ✅ ADDED: Missing columns now present
@Column(nullable = false)
private String customerName;

@Column(nullable = false)
private String customerEmail;
```

**What to check for in YOUR Sale.java:**
- ❌ Duplicate `saleDate` field
- ❌ Floating `@JsonFormat` annotation not attached to a field
- ❌ Missing `@Column` annotations on customerName/Email
- ❌ Missing Jackson import statement

### Step 2: Update Database Schema

Add missing columns if not present:

```sql
-- For MySQL
ALTER TABLE sales 
ADD COLUMN customer_name VARCHAR(255) NOT NULL DEFAULT 'Unknown',
ADD COLUMN customer_email VARCHAR(255) NOT NULL DEFAULT 'unknown@example.com';

-- For PostgreSQL
ALTER TABLE sales 
ADD COLUMN customer_name VARCHAR(255) NOT NULL DEFAULT 'Unknown',
ADD COLUMN customer_email VARCHAR(255) NOT NULL DEFAULT 'unknown@example.com';
```

### Step 3: Rebuild Backend

```bash
# Navigate to sales-service
cd sales-service

# Clean and rebuild
mvn clean install

# Restart service (should run on port 8086)
```

Watch for startup logs:
```
✅ GOOD:
  - No errors in console
  - Server started on port 8086
  - "Mapping servlet: 'dispatcherServlet' to '/*'"

❌ BAD:
  - Compilation errors
  - Jackson deserialization errors
  - Port 8086 already in use
```

### Step 4: Frontend Already Fixed

✅ Sales.tsx is updated:
- Date picker initialization fixed
- Date format conversion added
- Proper YYYY-MM-DD to YYYY-MM-DDTHH:mm:ss conversion

✅ SalesTrends.tsx is updated:
- Date validation in filter
- Auto-refresh every 5 seconds
- Manual refresh button

### Step 5: Test in This Order

**Test A: Create First Sale**
1. Go to **Products** → Confirm you have at least one product
2. Go to **Sales** → Click **"Record Sale"**
3. Select a product
4. Enter Quantity: `1`
5. Enter Customer Name: `Test Customer`
6. Enter Customer Email: `test@example.com`
7. Select Sale Date: `2025-12-18` (today)
8. Click **"Record"**

**Check console for:**
```
✅ Sale created successfully!
```

If error appears, check backend logs immediately.

**Test B: Verify Sale in Database**
```sql
SELECT * FROM sales WHERE customer_name = 'Test Customer';
```

Should return 1 row.

**Test C: View in Sales Trends**
1. Go to **Sales Trends** page
2. Page auto-refreshes every 5 seconds
3. Should see your new sale in the "Products" table

**Test D: Filter by Date**
1. Go to **Sales Trends**
2. Start Date: `2025-12-01`
3. End Date: `2025-12-31`
4. Click **"Filter"**
5. Should see results (because your sale is from 2025-12-18)

## Common Error Messages & Solutions

### Error: `400 Bad Request` from `/sales-service/sales`

**Problem**: Backend can't deserialize the request

**Solutions** (in order):
1. Check if `@JsonFormat` is on `saleDate` field
2. Check if Jackson import is present
3. Check if all required fields exist in entity
4. Verify pom.xml has Jackson dependency
5. Try rebuilding with `mvn clean install -DskipTests`

### Error: `Bad JSON format` in backend logs

**Problem**: Date format mismatch

**Check**: Frontend is sending `YYYY-MM-DDTHH:mm:ss` format?
- Should be: `2025-12-18T00:00:00`
- NOT: `2025-12-18T15:30:00.000Z`

### Error: Column not found exception in database

**Problem**: Database schema missing customerName/Email columns

**Solution**:
```sql
-- Add missing columns
ALTER TABLE sales ADD COLUMN customer_name VARCHAR(255);
ALTER TABLE sales ADD COLUMN customer_email VARCHAR(255);
```

## Debugging Checklist

- [ ] Backend Sale entity has @JsonFormat import
- [ ] Backend Sale entity has @JsonFormat annotation on saleDate
- [ ] Database has customer_name and customer_email columns
- [ ] pom.xml has Jackson dependency
- [ ] Backend restarted after changes
- [ ] First sale created successfully (no 400 error)
- [ ] Sale appears in database: `SELECT * FROM sales;`
- [ ] Sale appears in Sales Trends page
- [ ] Date filter works: Returns results within date range

## Success Indicators

Once everything is working:

✅ **Console shows**:
```
POST /sales-service/sales 200 (Success)
✅ Sale created successfully!
```

✅ **Database shows**:
```
sales table contains: [id, productId, quantity, customerName, customerEmail, saleDate]
```

✅ **Frontend shows**:
- Sale appears in Sales page table
- Sale appears in Sales Trends after 5 seconds
- Date filter returns matching sales
- Can manually select dates in date picker

✅ **Complete workflow**:
1. Create product with sale date → ✅
2. Create sale with customer info → ✅
3. See sale in trends → ✅
4. Filter by date → ✅

Done! 🎉
