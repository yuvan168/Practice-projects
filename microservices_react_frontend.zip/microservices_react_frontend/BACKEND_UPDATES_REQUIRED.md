# Backend Configuration for Sales Trends by Product Date

## Overview

Your application now has a **complete sales management system** that tracks trends based on **Product Sale Date** (when products are scheduled) rather than transaction date.

### What Changed:
- ✅ Products have a `saleDate` field
- ✅ ProductService saves saleDate when updating products
- ✅ ProductDTO includes saleDate for inter-service communication
- ✅ SaleController's `/trends` endpoint groups sales by product's saleDate

---

## Files Updated

### 1. **Product.java (Product Service)**
**Status**: ✅ ALREADY UPDATED

**Includes**:
```java
@Column(name = "sale_date")
private LocalDate saleDate;

public LocalDate getSaleDate() { return saleDate; }
public void setSaleDate(LocalDate saleDate) { this.saleDate = saleDate; }
```

### 2. **ProductDTO.java (Sales Service)**
**Status**: ⚠️ NEEDS UPDATE

**Add**:
```java
import java.time.LocalDate;

public class ProductDTO {
    // ... existing fields ...
    private LocalDate saleDate;
    
    public LocalDate getSaleDate() {
        return saleDate;
    }
    
    public void setSaleDate(LocalDate saleDate) {
        this.saleDate = saleDate;
    }
}
```

### 3. **ProductService.java (Product Service)**
**Status**: ✅ ALREADY UPDATED

**Key Method**:
```java
public Optional<Product> updateProduct(Long id, Product updatedProduct) {
    return productRepository.findById(id).map(product -> {
        product.setName(updatedProduct.getName());
        product.setDescription(updatedProduct.getDescription());
        product.setManufacturer(updatedProduct.getManufacturer());
        product.setPrice(updatedProduct.getPrice());
        product.setQuantity(updatedProduct.getQuantity());
        product.setSaleDate(updatedProduct.getSaleDate());  // ← CRITICAL
        return productRepository.save(product);
    });
}
```

### 4. **SaleController.java (Sales Service)**
**Status**: ✅ ALREADY UPDATED

**Key Method**: `getSalesTrends()`

**What It Does**:
```java
for (Sale sale : allSales) {
    // Get product details including saleDate
    ProductDTO product = productServiceClient.getProductById(sale.getProductId());
    
    if (product != null && product.getSaleDate() != null) {
        LocalDate productSaleDate = product.getSaleDate();
        
        // Check if product date is in requested range
        if (!productSaleDate.isBefore(finalStartDate) && !productSaleDate.isAfter(finalEndDate)) {
            // Group by PRODUCT's sale date, not transaction date
            String dateKey = productSaleDate.toString();
            dailyRevenue.put(dateKey, dailyRevenue.getOrDefault(dateKey, 0.0) + sale.getTotalPrice());
            dailyCount.put(dateKey, dailyCount.getOrDefault(dateKey, 0) + 1);
        }
    }
}
```

---

## Database Schema

### Required Column
```sql
ALTER TABLE products ADD COLUMN sale_date DATE NULL;
```

If using migration tools:

**Liquibase**:
```xml
<changeSet id="add-sale-date-to-products" author="dev">
    <addColumn tableName="products">
        <column name="sale_date" type="DATE" remarks="Product sale schedule date"/>
    </addColumn>
</changeSet>
```

**Flyway**:
```sql
-- V1__Add_sale_date_to_products.sql
ALTER TABLE products ADD COLUMN sale_date DATE NULL;
```

---

## Configuration Files

### application.properties
```properties
spring.jackson.serialization.write-dates-as-timestamps=false
spring.jackson.time-zone=UTC
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQL8Dialect
```

### application.yml
```yaml
spring:
  jackson:
    serialization:
      write-dates-as-timestamps: false
    time-zone: UTC
  jpa:
    properties:
      hibernate:
        dialect: org.hibernate.dialect.MySQL8Dialect
```

---

## API Endpoints

### Product Service Endpoints

#### GET /products/all
**Returns**: All products with saleDate

**Response**:
```json
[
  {
    "id": 1,
    "name": "Laptop",
    "description": "Dell XPS",
    "manufacturer": "Dell",
    "price": 999.99,
    "quantity": 5,
    "saleDate": "2025-12-10"
  },
  {
    "id": 2,
    "name": "Phone",
    "description": "iPhone",
    "manufacturer": "Apple",
    "price": 599.99,
    "quantity": 10,
    "saleDate": "2025-12-15"
  }
]
```

#### POST /products
**Creates**: New product with saleDate

**Request**:
```json
{
  "name": "Tablet",
  "description": "iPad Pro",
  "manufacturer": "Apple",
  "price": 399.99,
  "quantity": 8,
  "saleDate": "2025-12-20"
}
```

#### PUT /products/{id}
**Updates**: Product including saleDate

**Request**:
```json
{
  "name": "Laptop",
  "description": "Dell XPS Updated",
  "manufacturer": "Dell",
  "price": 1099.99,
  "quantity": 3,
  "saleDate": "2025-12-25"
}
```

**Important**: Must include `setSaleDate()` in updateProduct method!

---

### Sales Service Endpoints

#### POST /sales
**Creates**: New sale record

**Request**:
```json
{
  "productId": 1,
  "quantity": 2,
  "customerName": "John Doe",
  "customerEmail": "john@example.com"
}
```

**Response**:
```json
{
  "id": 1,
  "productId": 1,
  "productName": "Laptop",
  "quantity": 2,
  "unitPrice": 999.99,
  "totalPrice": 1999.98,
  "customerName": "John Doe",
  "customerEmail": "john@example.com",
  "saleDate": "2025-12-18T10:30:00"
}
```

#### GET /sales/trends
**Returns**: Sales aggregated by Product Sale Date

**Query Parameters**:
- `startDate` (optional): YYYY-MM-DD format
- `endDate` (optional): YYYY-MM-DD format

**Request Examples**:
```bash
# Default (last 30 days)
GET http://localhost:8086/sales-service/sales/trends

# Specific date range
GET http://localhost:8086/sales-service/sales/trends?startDate=2025-12-01&endDate=2025-12-31

# December 2025
GET http://localhost:8086/sales-service/sales/trends?startDate=2025-12-01&endDate=2025-12-31
```

**Response**:
```json
{
  "totalRevenue": 3794.00,
  "totalSales": 6,
  "dailyRevenue": {
    "2025-12-10": 1998.00,
    "2025-12-15": 599.00,
    "2025-12-20": 1197.00
  },
  "dailyCount": {
    "2025-12-10": 2,
    "2025-12-15": 1,
    "2025-12-20": 3
  },
  "topProducts": [
    {
      "productId": 1,
      "productName": "Laptop",
      "totalQuantity": 2,
      "totalRevenue": 1998.00
    },
    {
      "productId": 3,
      "productName": "Tablet",
      "totalQuantity": 3,
      "totalRevenue": 1197.00
    },
    {
      "productId": 2,
      "productName": "Phone",
      "totalQuantity": 1,
      "totalRevenue": 599.00
    }
  ],
  "startDate": "2025-12-01",
  "endDate": "2025-12-31"
}
```

---

## How Sales Trends Are Calculated

**Algorithm**:

```
1. Receive GET /sales/trends request with optional date range
   ↓
2. Default to last 30 days if no range specified
   ↓
3. Fetch ALL sales from database
   ↓
4. For EACH sale:
   a. Call ProductServiceClient.getProductById(productId)
   b. Extract product.saleDate
   c. Check if product.saleDate is within [startDate, endDate]
   d. If YES:
      - Add sale.totalPrice to dailyRevenue[productSaleDate]
      - Increment dailyCount[productSaleDate]
      - Update topProducts metrics
   ↓
5. Sort topProducts by totalRevenue (descending)
   ↓
6. Return aggregated data
```

**Key Points**:
- ✅ Uses product's saleDate (not sale's saleDate)
- ✅ Filters sales by product's date range
- ✅ Groups by product's date, not transaction date
- ✅ Aggregates across all sales for each product date

---

## Deployment Checklist

### Code Changes
- [ ] ProductDTO.java has `saleDate` field and getters/setters
- [ ] ProductService.java has `product.setSaleDate(updatedProduct.getSaleDate())` in updateProduct()
- [ ] SaleController.java has updated `getSalesTrends()` method
- [ ] All files compiled without errors

### Database
- [ ] `ALTER TABLE products ADD COLUMN sale_date DATE NULL;` executed
- [ ] Products table has `sale_date` column
- [ ] Existing products may have null values (acceptable)

### Configuration
- [ ] application.properties/yml has Jackson date config
- [ ] Spring Boot running with correct dialect

### Testing
- [ ] Can POST/PUT products with saleDate
- [ ] Can GET /products/all and see saleDate in response
- [ ] Can POST sales and record transactions
- [ ] GET /sales/trends returns data grouped by product dates

### Frontend
- [ ] Products.tsx shows success message with Trends link
- [ ] Sales.tsx shows Product Date column
- [ ] SalesTrends.tsx has Refresh button
- [ ] All pages can navigate and interact

---

## Troubleshooting

### ProductDTO saleDate is null
**Cause**: ProductDTO doesn't have saleDate field
**Fix**: Add `private LocalDate saleDate;` and getters/setters

### 503 Service Unavailable when updating product
**Cause**: Backend crashed or not running
**Fix**: Check logs, restart service

### Trends show no data
**Cause**: Products don't have saleDate set
**Fix**: 
```bash
# Update products with dates
PUT /products/1
{
  ...existing fields...,
  "saleDate": "2025-12-10"
}
```

### Date format error
**Cause**: Date sent in wrong format
**Fix**: Use YYYY-MM-DD format (ISO 8601)

### Trends still show old data
**Cause**: Frontend cached data
**Fix**: Click Refresh button on SalesTrends page

---

## Performance Notes

**Current Implementation**:
- Fetches product details for each sale
- Works well for 1000s of sales
- May need optimization for 100k+ sales

**Future Optimization**:
```java
// Instead of loop, use database join
@Query("""
  SELECT s, p.saleDate 
  FROM Sale s 
  JOIN Product p ON s.productId = p.id 
  WHERE p.saleDate BETWEEN :start AND :end
""")
List<Object[]> getSalesTrendsByProductDate(LocalDate start, LocalDate end);
```

---

## Version Requirements

- Spring Boot 3.x+
- Java 11+
- Jackson 2.15+
- Lombok (if using @Data annotations)
- Spring Cloud Feign (for ProductServiceClient)

---

## Support

If you encounter issues:

1. Check backend logs for errors
2. Verify ProductServiceClient can reach Product Service
3. Ensure product.saleDate is not null for products you're checking
4. Check date format (YYYY-MM-DD)
5. Verify database migration was applied
```java
// OLD CODE (Wrong - uses today's date):
LocalDate today = LocalDate.now();
// or
Date now = new Date();

// NEW CODE (Correct - uses product's sale date):
LocalDate saleDate = product.getSaleDate(); // Use the product's date
// If saleDate is null, fallback to today:
LocalDate dateToUse = saleDate != null ? saleDate : LocalDate.now();
```

### 4. Update Sales Trend Query
When calculating `dailyRevenue` and `dailyCount` in your trends calculation, use the product's sale date:

```java
// Instead of:
// calendar.setTime(new Date());

// Use:
// calendar.setTime(Date.from(product.getSaleDate().atStartOfDay(ZoneId.systemDefault())));
```

### 5. Full Example Update
Here's a more complete example of what your sales trend calculation should look like:

```java
public SalesTrend calculateSalesTrends(LocalDate startDate, LocalDate endDate) {
    List<Sale> sales = saleRepository.findSalesByDateRange(startDate, endDate);
    
    double totalRevenue = 0;
    int totalCount = 0;
    Map<String, Double> dailyRevenue = new HashMap<>();
    Map<String, Integer> dailyCount = new HashMap<>();
    
    for (Sale sale : sales) {
        // Use sale's date or product's date
        LocalDate dateKey = sale.getSaleDate() != null 
            ? sale.getSaleDate().toLocalDate()
            : sale.getProduct().getSaleDate();
        
        String dateStr = dateKey.toString(); // "2025-12-18"
        
        double saleAmount = sale.getTotalPrice();
        totalRevenue += saleAmount;
        totalCount += sale.getQuantity();
        
        dailyRevenue.put(dateStr, dailyRevenue.getOrDefault(dateStr, 0.0) + saleAmount);
        dailyCount.put(dateStr, dailyCount.getOrDefault(dateStr, 0) + sale.getQuantity());
    }
    
    // ... rest of calculation
}
```

## Testing Steps

1. **Restart your backend** after making these changes
2. **Add a product** with a date from a previous month (e.g., October 2025)
3. **Check Sales Trends** - you should see data for that month
4. **Add another product** with a different month date (e.g., November 2025)
5. **Verify** sales trends show data for multiple months

## Frontend Side
The frontend has been updated to:
- ✅ Accept `saleDate` input when adding/editing products
- ✅ Display the date in the products table
- ✅ Show success messages after adding/editing
- ✅ Send `saleDate` to the backend API

## Important Notes
- The frontend defaults to **today's date** when adding new products
- You can select **any date** when adding products to create historical data
- The backend will use this date for all sales trend calculations
- Make sure your database allows NULL values for `sale_date` initially (for existing products)

## Questions?
If sales trends still don't update after these changes:
1. Check backend logs for errors
2. Verify the `sale_date` column was added to the database
3. Make sure the backend is using `getSaleDate()` in calculations
4. Restart the backend service completely (not just reload)
