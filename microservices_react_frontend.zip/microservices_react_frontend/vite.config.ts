import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    proxy: {
      '/user-service': {
        target: 'http://localhost:8086',
        changeOrigin: true,
        logLevel: 'debug',
      },
      '/product-service': {
        target: 'http://localhost:8086',
        changeOrigin: true,
        logLevel: 'debug',
      },
      '/sales-service': {
        target: 'http://localhost:8083',
        changeOrigin: true,
        logLevel: 'debug',
      },
    },
  },
})
