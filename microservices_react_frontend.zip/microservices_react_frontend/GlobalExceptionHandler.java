package com.example.salesservice.exception;

import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.context.request.WebRequest;

import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    @Override
    protected ResponseEntity<Object> handleHttpMessageNotReadable(
            HttpMessageNotReadableException ex,
            HttpHeaders headers,
            HttpStatus status,
            WebRequest request) {
        
        System.out.println("❌ JSON Deserialization Error!");
        System.out.println("   Error: " + ex.getMessage());
        if (ex.getCause() instanceof JsonProcessingException) {
            System.out.println("   JSON Parse Error: " + ex.getCause().getMessage());
        }
        
        Map<String, Object> response = new HashMap<>();
        response.put("error", "Invalid request format - JSON parsing failed");
        response.put("message", ex.getMessage());
        response.put("type", "JSON_DESERIALIZATION_ERROR");
        response.put("hint", "Check date format: should be YYYY-MM-DD'T'HH:mm:ss like 2025-12-18T00:00:00");
        response.put("cause", ex.getCause() != null ? ex.getCause().getMessage() : "Unknown");
        
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<?> handleGenericException(Exception ex) {
        System.out.println("❌ Unexpected Exception!");
        System.out.println("   Error: " + ex.getMessage());
        ex.printStackTrace();
        
        Map<String, Object> response = new HashMap<>();
        response.put("error", ex.getClass().getSimpleName());
        response.put("message", ex.getMessage());
        response.put("type", "INTERNAL_SERVER_ERROR");
        
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
    }
}
