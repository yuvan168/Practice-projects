# Quick Sales Creation Testing Checklist

## ✅ Pre-Test Verification

Before trying to create a sale, verify:

- [ ] **Backend is running** on port 8086
- [ ] **Product Service is running** (needed for product validation)
- [ ] **Frontend is running** on port 3000 (or your configured port)
- [ ] **You're logged in** to the application
- [ ] **At least one product exists** in the Products page

## 📋 Step-by-Step Test

### 1️⃣ Prepare Test Data

Before starting, check what products are available:
1. Click on **Products** page
2. **Note down:**
   - Product ID (should show in table)
   - Product Name (e.g., "Laptop9")
   - Product Quantity (e.g., 5 units available)
   - Product Price (e.g., 7575876)

**Example for testing:**
- Product ID: 7
- Product Name: Laptop9
- Available Quantity: 5
- Unit Price: 7575876

### 2️⃣ Create a Sale

1. Click **Sales** page in navigation
2. Click **"Record Sale"** button (should open modal dialog)
3. **Fill the form:**

| Field | Example Value | Notes |
|-------|---------------|-------|
| Product | Select "Laptop9" | Must select from dropdown |
| Quantity | 1 | Must be ≤ available quantity |
| Unit Price | 7575876 | Auto-filled, read-only |
| Total Price | 7575876 | Auto-calculated |
| Customer Name | John Doe | ✅ REQUIRED - Cannot be empty |
| Customer Email | john@example.com | ✅ REQUIRED - Cannot be empty |
| Sale Date | 2025-12-18 | Date when sale happened |

### 3️⃣ Submit and Check Results

1. Click **"Record"** button
2. **Check for success:**
   - ✅ Modal should close
   - ✅ Success message should appear
   - ✅ New sale should appear in the table

3. **If error occurs:**
   - Check the alert message
   - Open browser console (F12 → Console tab)
   - Look for error details logged
   - Go to Step 4

### 4️⃣ Troubleshoot Error (If Occurs)

**Open browser console (F12):**

Look for logs like:
```
Creating sale with data: {...}
Error: Insufficient product quantity
```

**Check specific error:**

| If You See | Problem | Solution |
|-----------|---------|----------|
| `Insufficient product quantity` | Trying to sell more than available | Reduce quantity in form |
| `Product not found` | Invalid product ID | Select product from dropdown |
| `Customer name is required` | Empty customer name field | Enter customer name |
| `Customer email is required` | Empty customer email field | Enter customer email |
| `Quantity must be positive` | Quantity is 0 or negative | Enter quantity > 0 |
| `Product Service is unavailable` | Backend service not running | Restart backend services |

### 5️⃣ Verify in Sales Trends

After successful sale creation:

1. Click **Sales Trends** page
2. Click **🔄 Refresh (All Products)** button
3. **Verify:**
   - ✅ Your product appears in the table
   - ✅ Revenue is updated (shows the sale amount)
   - ✅ Status shows "✅ Active"

## 🐛 Debug Mode

To enable detailed debugging:

### In Browser (F12 Console):
```javascript
// Add before submitting form:
console.log('Form data:', {
  productId: 7,
  quantity: 1,
  customerName: 'Test',
  customerEmail: 'test@example.com'
});
```

### In Backend Console:
Look for logs containing:
- `📝 createSale called`
- `🔍 Checking product quantity`
- `✅ Sale created successfully`
- `❌ Error: [specific error]`

## 📊 Test Scenarios

### Scenario 1: Happy Path (Should Succeed ✅)
```
Product: Any available product
Quantity: 1
Customer Name: Test Customer
Customer Email: test@example.com
Expected: Sale created, appears in table
```

### Scenario 2: Insufficient Quantity (Should Fail ❌)
```
Product: Product with 5 available
Quantity: 10
Customer Name: Test Customer
Customer Email: test@example.com
Expected: Error "Insufficient product quantity"
```

### Scenario 3: Missing Customer Name (Should Fail ❌)
```
Product: Any product
Quantity: 1
Customer Name: [EMPTY]
Customer Email: test@example.com
Expected: Alert "Please enter customer name"
```

### Scenario 4: Missing Customer Email (Should Fail ❌)
```
Product: Any product
Quantity: 1
Customer Name: Test Customer
Customer Email: [EMPTY]
Expected: Alert "Please enter customer email"
```

### Scenario 5: Missing Product Selection (Should Fail ❌)
```
Product: [NOT SELECTED]
Quantity: 1
Customer Name: Test Customer
Customer Email: test@example.com
Expected: Alert "Please select a product"
```

## ✅ Success Indicators

A sale was created successfully if:

1. ✅ **Modal closes** after clicking Record
2. ✅ **Success message appears** (or redirects to trends)
3. ✅ **Sale appears in table** on Sales page
4. ✅ **Console shows** `✅ Sale created successfully`
5. ✅ **Product quantity decreased** in Products page
6. ✅ **Sales Trends updated** with new revenue

## 🔍 Backend Diagnostics

If something fails, check backend logs:

```bash
# Terminal where backend is running should show:

# For successful sale:
📝 createSale called
📦 Request body: Sale(productId=7, quantity=1, ...)
✅ Product found: Laptop9
✅ Product quantity updated: 4
✅ Sale created successfully with ID: 42

# For failed sale:
❌ Error: Insufficient product quantity
OR
❌ Error: productId is missing or invalid
OR
❌ Error: Product Service is unavailable
```

## 📱 Mobile/Browser Testing

Test on different screen sizes:
- [ ] Desktop (1920x1080)
- [ ] Laptop (1366x768)
- [ ] Tablet (768x1024)
- [ ] Mobile (375x667)

Form should adapt properly on all sizes.

---

## 🚀 Ready to Test?

Start with the **Happy Path** scenario first to verify everything works. Then test error scenarios to ensure proper error handling.

**Questions?** Check the **SALES_CREATION_GUIDE.md** for detailed explanations.
