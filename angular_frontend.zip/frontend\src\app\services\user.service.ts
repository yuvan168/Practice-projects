import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, BehaviorSubject, Subject, of } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';
import { Product, ProductStatistics } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private apiUrl = 'http://localhost:8080/api/products';
  private readonly STORAGE_KEY = 'products';
  
  // Observable state management
  private productsSubject = new BehaviorSubject<Product[]>([]);
  public products$ = this.productsSubject.asObservable();
  
  private loadingSubject = new BehaviorSubject<boolean>(false);
  public loading$ = this.loadingSubject.asObservable();
  
  private errorSubject = new Subject<string>();
  public error$ = this.errorSubject.asObservable();

  // Default products with categories
  private defaultProducts: Product[] = [
    { id: 1, productName: 'Laptop Pro', sku: 'LAP001', productCode: 'PC-001', price: 999.99, quantity: 5, category: 'Electronics', inStock: true },
    { id: 2, productName: 'Wireless Mouse', sku: 'MOU001', productCode: 'PC-002', price: 29.99, quantity: 50, category: 'Electronics', inStock: true },
    { id: 3, productName: 'Mechanical Keyboard', sku: 'KEY001', productCode: 'PC-003', price: 79.99, quantity: 30, category: 'Electronics', inStock: true },
    { id: 4, productName: 'Office Chair', sku: 'CHR001', productCode: 'FUR-001', price: 199.99, quantity: 10, category: 'Furniture', inStock: true },
    { id: 5, productName: 'Desk Lamp', sku: 'LAM001', productCode: 'LIT-001', price: 45.99, quantity: 25, category: 'Lighting', inStock: true }
  ];

  constructor(private http: HttpClient) {
    this.loadProducts();
  }

  private loadProducts(): void {
    const stored = localStorage.getItem(this.STORAGE_KEY);
    if (stored) {
      try {
        const products = JSON.parse(stored);
        this.productsSubject.next(products);
      } catch {
        this.initializeDefaultProducts();
      }
    } else {
      this.initializeDefaultProducts();
    }
  }

  private initializeDefaultProducts(): void {
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this.defaultProducts));
    this.productsSubject.next(this.defaultProducts);
  }

  private saveProducts(products: Product[]): void {
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(products));
    this.productsSubject.next([...products]);
  }

  // Get all products
  getAllProducts(): Observable<Product[]> {
    return of(this.productsSubject.value);
  }

  getProductById(id: number): Observable<Product> {
    const product = this.productsSubject.value.find(p => p.id === id);
    return of(product || this.defaultProducts[0]);
  }

  // Search products with filters (localStorage-based)
  searchProducts(keyword: string, category?: string): Observable<Product[]> {
    const allProducts = this.productsSubject.value;
    let results = allProducts.filter(product => 
      product.productName.toLowerCase().includes(keyword.toLowerCase()) ||
      product.productCode.toLowerCase().includes(keyword.toLowerCase()) ||
      product.sku.toLowerCase().includes(keyword.toLowerCase())
    );

    if (category && category !== 'All' && category !== '') {
      results = results.filter(product => product.category === category);
    }

    return of(results);
  }

  // Create product (localStorage-based)
  createProduct(product: Product): Observable<Product> {
    const products = this.productsSubject.value;
    const newProduct: Product = {
      ...product,
      id: Math.max(...products.map(p => p.id || 0), 0) + 1,
      inStock: (product.quantity || 0) > 0
    };
    this.saveProducts([...products, newProduct]);
    return of(newProduct);
  }

  // Update product (localStorage-based)
  updateProduct(id: number, product: Product): Observable<Product> {
    const products = this.productsSubject.value;
    const index = products.findIndex(p => p.id === id);
    if (index !== -1) {
      const updated = {
        ...product,
        id,
        inStock: (product.quantity || 0) > 0
      };
      products[index] = updated;
      this.saveProducts([...products]);
      return of(updated);
    }
    return of(product);
  }

  // Delete product (localStorage-based)
  deleteProduct(id: number): Observable<void> {
    const products = this.productsSubject.value;
    this.saveProducts(products.filter(p => p.id !== id));
    return of(undefined);
  }

  // Get statistics
  getStatistics(): Observable<ProductStatistics> {
    const products = this.productsSubject.value;
    const stats: ProductStatistics = {
      totalProducts: products.length,
      totalValue: products.reduce((sum, p) => sum + ((p.price || 0) * (p.quantity || 0)), 0),
      lowStockCount: products.filter(p => (p.quantity || 0) < 10).length,
      outOfStockCount: products.filter(p => (p.quantity || 0) === 0).length,
      categories: [...new Set(products.map(p => p.category || 'Uncategorised').filter(c => c !== ''))]
    };
    return of(stats);
  }

  // Get unique categories
  getCategories(): Observable<string[]> {
    const products = this.productsSubject.value;
    const categories = [...new Set(products.map(p => p.category || '').filter(c => c !== ''))];
    return of(categories.sort());
  }

  // Get low stock products
  getLowStockProducts(threshold: number = 10): Observable<Product[]> {
    const products = this.productsSubject.value;
    return of(products.filter(p => (p.quantity || 0) < threshold && (p.quantity || 0) > 0));
  }

  // Get out of stock products
  getOutOfStockProducts(): Observable<Product[]> {
    const products = this.productsSubject.value;
    return of(products.filter(p => (p.quantity || 0) === 0));
  }

  // Get featured products (top 5 by quantity)
  getFeaturedProducts(): Observable<Product[]> {
    const products = this.productsSubject.value;
    return of(products.slice(0, 5));
  }

  // Clear error (method stub for compatibility)
  clearError(): void {
    this.errorSubject.next('');
  }

  // Delete multiple products
  deleteMultiple(ids: number[]): Observable<void> {
    const products = this.productsSubject.value;
    this.saveProducts(products.filter(p => !ids.includes(p.id || 0)));
    return of(undefined);
  }
}
