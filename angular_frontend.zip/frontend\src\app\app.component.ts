import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from './services/auth.service';
import { DarkModeService } from './services/dark-mode.service';

@Component({
  selector: 'app-root',
  template: `
    <div class="app-wrapper">
      <app-navbar></app-navbar>
      <div class="main-content">
        <router-outlet></router-outlet>
      </div>
      <footer *ngIf="isLoggedIn" class="app-footer">
        <p>&copy; 2024 Product Manager. All rights reserved.</p>
      </footer>
    </div>
  `,
  styles: [`
    .app-wrapper {
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      background-color: #f8f9fa;
      transition: background-color 0.3s ease;
    }

    .app-wrapper :host-context(body.dark-mode) {
      background-color: #1a1a1a;
    }

    .main-content {
      flex: 1;
    }

    .app-footer {
      background-color: #2c3e50;
      color: white;
      text-align: center;
      padding: 2rem;
      margin-top: 3rem;
      border-top: 1px solid #ecf0f1;
      transition: background-color 0.3s ease, border-color 0.3s ease;
    }

    :host-context(body.dark-mode) .app-footer {
      background-color: #0d0d0d;
      border-top-color: #444;
    }

    .app-footer p {
      margin: 0;
      font-size: 0.9rem;
      color: #bdc3c7;
    }

    :host-context(body.dark-mode) .app-footer p {
      color: #999;
    }

    :host ::ng-deep {
      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
      }

      body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        color: #2c3e50;
        background-color: #f8f9fa;
        transition: background-color 0.3s ease, color 0.3s ease;
      }

      body.dark-mode {
        background-color: #1a1a1a;
        color: #ecf0f1;
      }

      /* Dark mode for cards */
      .card {
        background-color: white;
        transition: background-color 0.3s ease;
      }

      body.dark-mode .card {
        background-color: #2d2d2d;
        border-color: #444;
      }

      /* Dark mode for forms */
      .form-container {
        background-color: white;
        transition: background-color 0.3s ease;
      }

      body.dark-mode .form-container {
        background-color: #2d2d2d;
      }

      .form-control {
        background-color: white;
        color: #2c3e50;
        border-color: #bdc3c7;
        transition: background-color 0.3s ease, color 0.3s ease, border-color 0.3s ease;
      }

      body.dark-mode .form-control {
        background-color: #3d3d3d;
        color: #ecf0f1;
        border-color: #555;
      }

      body.dark-mode .form-control:focus {
        border-color: #66a3ff;
        box-shadow: 0 0 0 3px rgba(102, 163, 255, 0.1);
      }

      /* Dark mode for tables */
      .user-table {
        background-color: white;
        transition: background-color 0.3s ease;
      }

      body.dark-mode .user-table {
        background-color: #2d2d2d;
      }

      .user-table thead {
        background-color: #34495e;
        transition: background-color 0.3s ease;
      }

      body.dark-mode .user-table thead {
        background-color: #1a1a1a;
        border-bottom: 1px solid #555;
      }

      .user-table th {
        color: white;
        transition: color 0.3s ease;
      }

      body.dark-mode .user-table th {
        color: #ecf0f1;
        border-bottom-color: #555;
      }

      .user-table td {
        border-bottom-color: #e9ecef;
        color: #2c3e50;
        transition: border-color 0.3s ease, color 0.3s ease;
      }

      body.dark-mode .user-table td {
        border-bottom-color: #444;
        color: #ecf0f1;
      }

      .user-table tbody tr:hover {
        background-color: #f8f9fa;
        transition: background-color 0.3s ease;
      }

      body.dark-mode .user-table tbody tr:hover {
        background-color: #3d3d3d;
      }

      /* Dark mode for alerts */
      .alert {
        transition: background-color 0.3s ease, color 0.3s ease, border-color 0.3s ease;
      }

      body.dark-mode .alert-error {
        background-color: #4a2626;
        color: #ff9999;
        border-color: #662222;
      }

      body.dark-mode .alert-success {
        background-color: #264a26;
        color: #99ff99;
        border-color: #226622;
      }

      /* Dark mode for buttons */
      .btn {
        transition: background-color 0.3s ease, color 0.3s ease;
      }

      /* Dark mode for labels and text */
      label {
        color: #2c3e50;
        transition: color 0.3s ease;
      }

      body.dark-mode label {
        color: #ecf0f1;
      }

      h1, h2, h3, h4, h5, h6 {
        color: #2c3e50;
        transition: color 0.3s ease;
      }

      body.dark-mode h1,
      body.dark-mode h2,
      body.dark-mode h3,
      body.dark-mode h4,
      body.dark-mode h5,
      body.dark-mode h6 {
        color: #ecf0f1;
      }

      /* Dark mode for table wrapper */
      .table-wrapper {
        background-color: white;
        transition: background-color 0.3s ease;
      }

      body.dark-mode .table-wrapper {
        background-color: #2d2d2d;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.5);
      }

      .table-info {
        background-color: #f8f9fa;
        border-bottom-color: #e9ecef;
        color: #2c3e50;
        transition: background-color 0.3s ease, border-color 0.3s ease, color 0.3s ease;
      }

      body.dark-mode .table-info {
        background-color: #1a1a1a;
        border-bottom-color: #444;
        color: #ecf0f1;
      }
    }
  `]
})
export class AppComponent implements OnInit {
  isLoggedIn = false;

  constructor(
    private authService: AuthService,
    private darkModeService: DarkModeService
  ) {}

  ngOnInit(): void {
    this.authService.getCurrentUser$().subscribe(user => {
      this.isLoggedIn = !!user;
    });

    // Dark mode is now handled by DarkModeService
    // No need to initialize it here
  }
}

