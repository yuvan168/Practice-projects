import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../../services/user.service';
import { Product } from '../../models/user.model';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-product-form',
  template: `
    <div class="form-container">
      <h2>{{ isEditMode ? 'Edit Product' : 'Add New Product' }}</h2>
      
      <!-- Error Alert -->
      <div *ngIf="errorMessage" class="alert alert-error">
        <span>{{ errorMessage }}</span>
        <button class="close-btn" (click)="clearError()">&times;</button>
      </div>

      <!-- Success Alert -->
      <div *ngIf="successMessage" class="alert alert-success">
        {{ successMessage }}
      </div>

      <form (ngSubmit)="onSubmit()" [ngClass]="{'form-disabled': isLoading}">
        <div class="form-group">
          <label for="productName">Product Name: <span class="required">*</span></label>
          <input
            type="text"
            id="productName"
            [(ngModel)]="product.productName"
            name="productName"
            class="form-control"
            required
            [disabled]="isLoading"
            (blur)="validateField('productName')"
          />
          <span *ngIf="fieldErrors['productName']" class="error-text">{{ fieldErrors['productName'] }}</span>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="sku">SKU: <span class="required">*</span></label>
            <input
              type="text"
              id="sku"
              [(ngModel)]="product.sku"
              name="sku"
              class="form-control"
              required
              [disabled]="isLoading"
              (blur)="validateField('sku')"
            />
            <span *ngIf="fieldErrors['sku']" class="error-text">{{ fieldErrors['sku'] }}</span>
          </div>

          <div class="form-group">
            <label for="productCode">Product Code: <span class="required">*</span></label>
            <input
              type="text"
              id="productCode"
              [(ngModel)]="product.productCode"
              name="productCode"
              class="form-control"
              required
              [disabled]="isLoading"
              (blur)="validateField('productCode')"
            />
            <span *ngIf="fieldErrors['productCode']" class="error-text">{{ fieldErrors['productCode'] }}</span>
          </div>

          <div class="form-group">
            <label for="category">Category:</label>
            <select
              id="category"
              [(ngModel)]="product.category"
              name="category"
              class="form-control"
              [disabled]="isLoading"
            >
              <option value="">-- Select Category --</option>
              <option *ngFor="let cat of categories" [value]="cat">{{ cat }}</option>
            </select>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="price">Price: <span class="required">*</span></label>
            <input
              type="number"
              id="price"
              [(ngModel)]="product.price"
              name="price"
              class="form-control"
              step="0.01"
              min="0"
              required
              [disabled]="isLoading"
              (blur)="validateField('price')"
            />
            <span *ngIf="fieldErrors['price']" class="error-text">{{ fieldErrors['price'] }}</span>
          </div>

          <div class="form-group">
            <label for="quantity">Quantity: <span class="required">*</span></label>
            <input
              type="number"
              id="quantity"
              [(ngModel)]="product.quantity"
              name="quantity"
              class="form-control"
              min="0"
              required
              [disabled]="isLoading"
              (blur)="validateField('quantity')"
            />
            <span *ngIf="fieldErrors['quantity']" class="error-text">{{ fieldErrors['quantity'] }}</span>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="discount">Discount (%):</label>
            <input
              type="number"
              id="discount"
              [(ngModel)]="product.discount"
              name="discount"
              class="form-control"
              min="0"
              max="100"
              step="0.01"
              [disabled]="isLoading"
            />
            <small class="help-text">Enter discount percentage (0-100)</small>
          </div>

          <div class="form-group">
            <label for="inStock">In Stock:</label>
            <select
              id="inStock"
              [(ngModel)]="product.inStock"
              name="inStock"
              class="form-control"
              [disabled]="isLoading"
            >
              <option [value]="true">Yes - In Stock</option>
              <option [value]="false">No - Out of Stock</option>
            </select>
          </div>
        </div>

        <div class="form-group">
          <label for="description">Description:</label>
          <textarea
            id="description"
            [(ngModel)]="product.description"
            name="description"
            class="form-control"
            rows="4"
            maxlength="500"
            [disabled]="isLoading"
          ></textarea>
          <div class="char-count">{{ (product.description || '').length }}/500</div>
        </div>

        <div class="button-group">
          <button 
            type="submit" 
            class="btn btn-primary"
            [disabled]="isLoading || !isFormValid()"
          >
            <span *ngIf="!isLoading">{{ isEditMode ? 'Update' : 'Create' }}</span>
            <span *ngIf="isLoading">{{ isEditMode ? 'Updating...' : 'Creating...' }}</span>
          </button>
          <button 
            type="button" 
            class="btn btn-secondary" 
            (click)="onCancel()"
            [disabled]="isLoading"
          >
            Cancel
          </button>
        </div>
      </form>
    </div>
  `,
  styles: [`
    .form-container {
      max-width: 600px;
      margin: 2rem auto;
      padding: 2rem;
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }

    h2 {
      margin-bottom: 2rem;
      color: #2c3e50;
    }

    .alert {
      padding: 1rem;
      margin-bottom: 1.5rem;
      border-radius: 4px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .alert-error {
      background-color: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }

    .alert-success {
      background-color: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }

    .close-btn {
      background: none;
      border: none;
      font-size: 1.5rem;
      cursor: pointer;
      color: inherit;
    }

    .form-disabled {
      opacity: 0.6;
      pointer-events: none;
    }

    .form-group {
      margin-bottom: 1.5rem;
    }

    .form-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1rem;
    }

    label {
      display: block;
      margin-bottom: 0.5rem;
      font-weight: bold;
      color: #2c3e50;
    }

    .required {
      color: #e74c3c;
    }

    .form-control {
      width: 100%;
      padding: 0.75rem;
      border: 1px solid #bdc3c7;
      border-radius: 4px;
      font-size: 1rem;
      box-sizing: border-box;
      font-family: inherit;
      transition: border-color 0.2s;
    }

    .form-control:focus {
      outline: none;
      border-color: #3498db;
      box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.1);
    }

    .form-control:disabled {
      background-color: #ecf0f1;
      cursor: not-allowed;
    }

    textarea.form-control {
      resize: vertical;
    }

    .error-text {
      color: #e74c3c;
      font-size: 0.875rem;
      margin-top: 0.25rem;
      display: block;
    }

    .char-count {
      font-size: 0.875rem;
      color: #7f8c8d;
      margin-top: 0.25rem;
      text-align: right;
    }

    .button-group {
      display: flex;
      gap: 1rem;
      margin-top: 2rem;
    }

    .btn {
      padding: 0.75rem 1.5rem;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 1rem;
      font-weight: bold;
      transition: background-color 0.2s;
      flex: 1;
    }

    .btn-primary {
      background-color: #3498db;
      color: white;
    }

    .btn-primary:hover:not(:disabled) {
      background-color: #2980b9;
    }

    .btn-primary:disabled {
      background-color: #95a5a6;
      cursor: not-allowed;
    }

    .btn-secondary {
      background-color: #95a5a6;
      color: white;
    }

    .btn-secondary:hover:not(:disabled) {
      background-color: #7f8c8d;
    }

    .btn-secondary:disabled {
      cursor: not-allowed;
      opacity: 0.6;
    }

    @media (max-width: 600px) {
      .form-row {
        grid-template-columns: 1fr;
      }

      .button-group {
        flex-direction: column;
      }
    }
  `]
})
export class ProductFormComponent implements OnInit, OnDestroy {
  product: Product = {
    productName: '',
    price: 0,
    quantity: 0,
    sku: '',
    productCode: '',
    category: '',
    description: '',
    discount: 0,
    inStock: true
  };

  isEditMode = false;
  productId: number | null = null;
  isLoading = false;
  errorMessage = '';
  successMessage = '';
  fieldErrors: { [key: string]: string } = {};

  categories = ['Electronics', 'Clothing', 'Food', 'Books', 'Furniture', 'Lighting', 'Other'];

  private destroy$ = new Subject<void>();

  constructor(
    private productService: ProductService,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.route.params.pipe(takeUntil(this.destroy$)).subscribe((params: any) => {
      if (params['id']) {
        this.isEditMode = true;
        this.productId = params['id'];
        if (this.productId !== null) {
          this.loadProduct(this.productId);
        }
      }
    });

    this.productService.error$.pipe(takeUntil(this.destroy$)).subscribe(error => {
      this.errorMessage = error;
    });
  }

  loadProduct(id: number): void {
    this.isLoading = true;
    this.productService.getProductById(id).pipe(takeUntil(this.destroy$)).subscribe({
      next: (data: Product) => {
        // Ensure category has a value (default to empty string if not set)
        if (!data.category) {
          data.category = '';
        }
        this.product = { ...data };
        this.isLoading = false;
      },
      error: (error: any) => {
        this.errorMessage = 'Failed to load product';
        this.isLoading = false;
      }
    });
  }

  validateField(fieldName: string): void {
    this.fieldErrors[fieldName] = '';

    switch (fieldName) {
      case 'productName':
        if (!this.product.productName || this.product.productName.trim().length === 0) {
          this.fieldErrors[fieldName] = 'Product name is required';
        } else if (this.product.productName.length > 100) {
          this.fieldErrors[fieldName] = 'Product name must be less than 100 characters';
        }
        break;
      case 'sku':
        if (!this.product.sku || this.product.sku.trim().length === 0) {
          this.fieldErrors[fieldName] = 'SKU is required';
        }
        break;
      case 'productCode':
        if (!this.product.productCode || this.product.productCode.trim().length === 0) {
          this.fieldErrors[fieldName] = 'Product code is required';
        } else if (this.product.productCode.length > 50) {
          this.fieldErrors[fieldName] = 'Product code must be less than 50 characters';
        }
        break;
      case 'price':
        if (this.product.price <= 0) {
          this.fieldErrors[fieldName] = 'Price must be greater than 0';
        }
        break;
      case 'quantity':
        if (this.product.quantity < 0) {
          this.fieldErrors[fieldName] = 'Quantity cannot be negative';
        }
        break;
    }
  }

  isFormValid(): boolean {
    return this.product.productName.trim().length > 0 &&
           this.product.sku.trim().length > 0 &&
           this.product.productCode.trim().length > 0 &&
           this.product.price > 0 &&
           this.product.quantity >= 0;
  }

  onSubmit(): void {
    // Validate all required fields
    this.validateField('productName');
    this.validateField('sku');
    this.validateField('productCode');
    this.validateField('price');
    this.validateField('quantity');
    
    if (!this.isFormValid()) {
      const missingFields = [];
      if (!this.product.productName?.trim()) missingFields.push('Product Name');
      if (!this.product.sku?.trim()) missingFields.push('SKU');
      if (!this.product.productCode?.trim()) missingFields.push('Product Code');
      if (!this.product.price || this.product.price <= 0) missingFields.push('Price (must be > 0)');
      if (this.product.quantity === undefined || this.product.quantity === null || this.product.quantity < 0) missingFields.push('Quantity');
      
      this.errorMessage = 'Please fill in all required fields: ' + missingFields.join(', ');
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';

    if (this.isEditMode && this.productId) {
      this.productService.updateProduct(this.productId, this.product)
        .pipe(takeUntil(this.destroy$))
        .subscribe({
          next: () => {
            this.successMessage = 'Product updated successfully!';
            this.isLoading = false;
            setTimeout(() => this.router.navigate(['/products']), 1500);
          },
          error: (error: any) => {
            this.errorMessage = 'Failed to update product';
            this.isLoading = false;
          }
        });
    } else {
      this.productService.createProduct(this.product)
        .pipe(takeUntil(this.destroy$))
        .subscribe({
          next: () => {
            this.successMessage = 'Product created successfully!';
            this.isLoading = false;
            setTimeout(() => this.router.navigate(['/products']), 1500);
          },
          error: (error: any) => {
            console.error('Create product error:', error);
            this.errorMessage = error?.error?.message || 'Failed to create product: ' + (error?.status || 'Unknown error');
            this.isLoading = false;
          }
        });
    }
  }

  clearError(): void {
    this.errorMessage = '';
    this.productService.clearError();
  }

  onCancel(): void {
    this.router.navigate(['/products']);
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
