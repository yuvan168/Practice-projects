export interface Product {
  id?: number;
  productName: string;
  price: number;
  quantity: number;
  sku: string;
  productCode: string;
  description?: string;
  // Product features
  imageUrl?: string;
  inStock?: boolean;
  minQuantity?: number;
  discount?: number;
  category?: string;
  createdAt?: string;
  updatedAt?: string;
  isActive?: boolean;
  status?: string;
}

export interface User {
  id?: number;
  email: string;
  firstName: string;
  lastName: string;
  password?: string;
  token?: string;
  type?: string;
}

export interface ProductFilters {
  keyword?: string;
  priceMin?: number;
  priceMax?: number;
}

export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data?: T;
  error?: string;
}

export interface PaginatedResponse<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  currentPage: number;
}

export interface ProductStatistics {
  totalProducts: number;
  totalValue: number;
  lowStockCount: number;
  outOfStockCount: number;
  categories: string[];
}
