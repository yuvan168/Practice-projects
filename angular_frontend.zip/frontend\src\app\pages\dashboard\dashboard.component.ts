import { Component, OnInit, OnDestroy } from '@angular/core';
import { ProductService } from '../../services/user.service';
import { AuthService } from '../../services/auth.service';
import { Product, ProductStatistics, User } from '../../models/user.model';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-dashboard',
  template: `
    <div class="dashboard-container">
      <div class="dashboard-header">
        <h1>📊 Inventory Dashboard</h1>
        <p class="subtitle">Welcome back, {{ currentUser?.firstName || 'User' }}!</p>
      </div>

      <!-- Stats Cards -->
      <div class="stats-grid" *ngIf="!loading">
        <div class="stat-card" *ngFor="let stat of statsCards">
          <div class="stat-icon">{{ stat.icon }}</div>
          <div class="stat-content">
            <h3>{{ stat.title }}</h3>
            <p class="stat-value">{{ stat.value }}</p>
          </div>
        </div>
      </div>

      <!-- Loading State -->
      <div *ngIf="loading" class="loading-container">
        <div class="spinner"></div>
        <p>Loading dashboard...</p>
      </div>

      <!-- Main Content Grid -->
      <div class="main-grid">
      </div>

      <!-- Inventory Health -->
      <div class="card inventory-health">
        <h2>Inventory Health</h2>
        <div class="health-metrics">
          <div class="metric">
            <span class="label">Total Inventory Value</span>
            <span class="value">₹{{ stats.totalValue | number:'1.0-0' }}</span>
          </div>
          <div class="metric">
            <span class="label">Total Products</span>
            <span class="value">{{ stats.totalProducts }}</span>
          </div>
          <div class="metric">
            <span class="label">Low Stock Count</span>
            <span class="value">{{ stats.lowStockCount }}</span>
          </div>
          <div class="metric">
            <span class="label">Out of Stock</span>
            <span class="value warning">{{ outOfStockCount }}</span>
          </div>
        </div>
      </div>

      <!-- Low Stock Alert -->
      <div *ngIf="lowStockProducts.length > 0" class="alert alert-warning">
        <h3>⚠️ Low Stock Alert</h3>
        <p>{{ lowStockProducts.length }} product(s) have low inventory:</p>
        <ul>
          <li *ngFor="let product of lowStockProducts.slice(0, 5)">
            {{ product.productName }} - {{ product.quantity }} units
          </li>
        </ul>
      </div>
    </div>
  `,
  styles: [`
    .dashboard-container {
      padding: 2rem;
      max-width: 1400px;
      margin: 0 auto;
    }

    .dashboard-header {
      margin-bottom: 2rem;
    }

    .dashboard-header h1 {
      color: #2c3e50;
      margin: 0;
      font-size: 2rem;
    }

    .subtitle {
      color: #7f8c8d;
      margin: 0.5rem 0 0;
    }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 1.5rem;
      margin-bottom: 2rem;
    }

    .stat-card {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 1.5rem;
      border-radius: 12px;
      display: flex;
      gap: 1rem;
      box-shadow: 0 4px 20px rgba(102, 126, 234, 0.2);
      transition: transform 0.3s ease;
    }

    .stat-card:hover {
      transform: translateY(-5px);
    }

    .stat-icon {
      font-size: 2.5rem;
    }

    .stat-content h3 {
      margin: 0;
      font-size: 0.9rem;
      opacity: 0.9;
    }

    .stat-value {
      margin: 0.5rem 0 0;
      font-size: 1.8rem;
      font-weight: bold;
    }

    .main-grid {
      display: grid;
      grid-template-columns: 2fr 1fr;
      gap: 1.5rem;
      margin-bottom: 2rem;
    }

    .card {
      background: white;
      border-radius: 12px;
      padding: 1.5rem;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }

    .card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1.5rem;
    }

    .card-header h2 {
      margin: 0;
      color: #2c3e50;
    }

    .data-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 0.9rem;
    }

    .data-table th {
      background-color: #ecf0f1;
      padding: 1rem;
      text-align: left;
      font-weight: 600;
      color: #2c3e50;
      border-bottom: 2px solid #bdc3c7;
    }

    .data-table td {
      padding: 0.75rem 1rem;
      border-bottom: 1px solid #ecf0f1;
    }

    .data-table tbody tr:hover {
      background-color: #f8f9fa;
    }

    .data-table tbody tr.low-stock {
      background-color: #fff3cd;
    }

    .badge-success {
      background-color: #d4edda;
      color: #155724;
      padding: 0.25rem 0.75rem;
      border-radius: 20px;
      font-size: 0.85rem;
      font-weight: 600;
    }

    .badge-danger {
      background-color: #f8d7da;
      color: #721c24;
      padding: 0.25rem 0.75rem;
      border-radius: 20px;
      font-size: 0.85rem;
      font-weight: 600;
    }

    .rating {
      color: #f39c12;
      font-weight: 600;
    }

    .btn, .btn-sm {
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-weight: 600;
      transition: all 0.3s ease;
    }

    .btn {
      padding: 0.75rem 1.5rem;
      font-size: 1rem;
    }

    .btn-sm {
      padding: 0.4rem 0.8rem;
      font-size: 0.85rem;
      margin-right: 0.5rem;
    }

    .btn-primary {
      background-color: #3498db;
      color: white;
    }

    .btn-primary:hover {
      background-color: #2980b9;
    }

    .btn-edit {
      background-color: #27ae60;
      color: white;
    }

    .btn-edit:hover {
      background-color: #229954;
    }

    .btn-delete {
      background-color: #e74c3c;
      color: white;
    }

    .btn-delete:hover {
      background-color: #c0392b;
    }

    .empty-state {
      text-align: center;
      padding: 2rem;
      color: #7f8c8d;
    }

    .product-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
      gap: 1rem;
    }

    .product-card {
      border: 1px solid #ecf0f1;
      border-radius: 8px;
      overflow: hidden;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .product-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }

    .product-image {
      width: 100%;
      height: 120px;
      background-color: #ecf0f1;
      overflow: hidden;
    }

    .product-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .product-info {
      padding: 0.75rem;
    }

    .product-info h4 {
      margin: 0 0 0.25rem;
      font-size: 0.9rem;
      color: #2c3e50;
    }

    .category {
      margin: 0;
      font-size: 0.8rem;
      color: #95a5a6;
    }

    .product-footer {
      margin-top: 0.5rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .price {
      font-weight: 700;
      color: #27ae60;
    }

    .discount {
      background-color: #e74c3c;
      color: white;
      padding: 0.2rem 0.5rem;
      border-radius: 4px;
      font-size: 0.8rem;
    }

    .inventory-health {
      margin-bottom: 2rem;
    }

    .inventory-health h2 {
      color: #2c3e50;
      margin-top: 0;
    }

    .health-metrics {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 1.5rem;
    }

    .metric {
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
    }

    .metric .label {
      color: #7f8c8d;
      font-size: 0.9rem;
    }

    .metric .value {
      font-size: 1.5rem;
      font-weight: 700;
      color: #2c3e50;
    }

    .metric .value.warning {
      color: #e74c3c;
    }

    .alert {
      padding: 1.5rem;
      border-radius: 8px;
      margin-bottom: 2rem;
    }

    .alert-warning {
      background-color: #fff3cd;
      border-left: 4px solid #f39c12;
      color: #856404;
    }

    .alert h3 {
      margin-top: 0;
    }

    .alert ul {
      margin: 1rem 0 0;
      padding-left: 1.5rem;
    }

    .alert li {
      margin: 0.5rem 0;
    }

    .loading-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 400px;
      gap: 1rem;
    }

    .spinner {
      border: 4px solid #ecf0f1;
      border-top: 4px solid #3498db;
      border-radius: 50%;
      width: 40px;
      height: 40px;
      animation: spin 1s linear infinite;
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    @media (max-width: 768px) {
      .main-grid {
        grid-template-columns: 1fr;
      }
      
      .stats-grid {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class DashboardComponent implements OnInit, OnDestroy {
  products: Product[] = [];
  featuredProducts: Product[] = [];
  lowStockProducts: Product[] = [];
  loading = true;
  currentUser: User | null = null;

  stats: ProductStatistics = {
    totalProducts: 0,
    totalValue: 0,
    lowStockCount: 0,
    outOfStockCount: 0,
    categories: []
  };

  statsCards: any[] = [];
  outOfStockCount = 0;

  private destroy$ = new Subject<void>();

  constructor(
    private productService: ProductService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.loadDashboard();
    this.authService.getCurrentUser$()
      .pipe(takeUntil(this.destroy$))
      .subscribe(user => {
        this.currentUser = user;
      });
  }

  loadDashboard(): void {
    this.loading = true;
    
    // Fetch all data in parallel
    this.productService.getAllProducts().pipe(takeUntil(this.destroy$)).subscribe({
      next: (products) => {
        console.log('✓ Products loaded:', products);
        this.products = products;
        this.lowStockProducts = products.filter(p => p.quantity! > 0 && p.quantity! < 10);
        
        // Calculate statistics locally from products
        this.calculateStatistics(products);
        this.updateStatsCards();
        this.loading = false;
      },
      error: (err) => {
        console.error('✗ Error loading products:', err);
        this.loading = false;
      }
    });

    this.productService.getFeaturedProducts().pipe(takeUntil(this.destroy$)).subscribe({
      next: (products: Product[]) => {
        console.log('✓ Featured products loaded:', products);
        this.featuredProducts = products;
      },
      error: (err: any) => console.error('✗ Error loading featured:', err)
    });

    this.productService.getOutOfStockProducts().pipe(takeUntil(this.destroy$)).subscribe({
      next: (products) => {
        console.log('✓ Out of stock products loaded:', products);
        this.outOfStockCount = products.length;
      },
      error: (err) => console.error('✗ Error loading out of stock:', err)
    });
  }

  calculateStatistics(products: Product[]): void {
    const totalProducts = products.length;
    const totalValue = products.reduce((sum, p) => sum + (p.price || 0) * (p.quantity || 0), 0);
    const totalQuantity = products.reduce((sum, p) => sum + (p.quantity || 0), 0);
    const averagePrice = totalProducts > 0 ? products.reduce((sum, p) => sum + (p.price || 0), 0) / totalProducts : 0;
    const categories = [...new Set(products.map(p => p.category || 'Uncategorised'))];

    this.stats = {
      totalProducts,
      totalValue,
      lowStockCount: products.filter(p => (p.quantity || 0) < 10).length,
      outOfStockCount: products.filter(p => p.quantity === 0).length,
      categories: categories.filter(c => c !== '')
    };
  }

  updateStatsCards(): void {
    this.statsCards = [
      { 
        title: 'Total Products', 
        value: this.stats.totalProducts,
        icon: '📦'
      },
      { 
        title: 'Total Inventory Value', 
        value: '₹' + (this.stats.totalValue || 0).toLocaleString(),
        icon: '💰'
      },
      { 
        title: 'Low Stock Items', 
        value: this.stats.lowStockCount,
        icon: '📊'
      },
      { 
        title: 'Out of Stock', 
        value: this.stats.outOfStockCount,
        icon: '⚠️'
      },
    ];
  }

  deleteProduct(id: number): void {
    if (confirm('Delete this product?')) {
      this.productService.deleteProduct(id).pipe(takeUntil(this.destroy$)).subscribe({
        next: () => {
          this.loadDashboard();
        }
      });
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
