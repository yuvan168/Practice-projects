import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';
import { UserManagementService } from './user-management.service';

export interface AuthResponse {
  token: string;
  type: string;
  id: number;
  email: string;
  firstName: string;
  lastName: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = 'http://localhost:8080/api/auth';
  private currentUserSubject = new BehaviorSubject<any>(null);
  public currentUser$ = this.currentUserSubject.asObservable();

  // Mock users for development/testing
  private mockUsers = [
    { 
      id: 1, 
      email: 'admin@example.com', 
      password: 'password123',
      firstName: 'Admin', 
      lastName: 'User',
      token: 'mock-jwt-token-admin',
      type: 'ADMIN'
    },
    { 
      id: 2, 
      email: 'user@example.com', 
      password: 'password123',
      firstName: 'Test', 
      lastName: 'User',
      token: 'mock-jwt-token-user',
      type: 'USER'
    }
  ];

  constructor(private http: HttpClient, private userManagementService: UserManagementService) {
    this.loadUserFromStorage();
  }

  private loadUserFromStorage(): void {
    const user = localStorage.getItem('currentUser');
    if (user) {
      this.currentUserSubject.next(JSON.parse(user));
    }
  }

  login(email: string, password: string): Observable<AuthResponse> {
    // Try backend first
    return this.http.post<AuthResponse>(`${this.apiUrl}/login`, { email, password }).pipe(
      tap((response: AuthResponse) => {
        if (response && response.token) {
          localStorage.setItem('token', response.token);
          localStorage.setItem('currentUser', JSON.stringify(response));
          this.currentUserSubject.next(response);
        }
      }),
      catchError(error => {
        // Fallback to mock and managed users for development
        console.log('Backend login failed, checking mock and managed users');
        
        // First try mock users
        let mockUser = this.mockUsers.find(u => u.email === email && u.password === password);
        
        // Then try managed users from UserManagementService
        if (!mockUser) {
          const managedUsers = this.userManagementService.getAllUsersSync();
          mockUser = managedUsers.find((u: any) => {
            // Check if email matches
            if (u.email !== email) return false;
            // Check password - support both users with passwords and without (backward compatibility)
            if (u.password) {
              return u.password === password;
            }
            // For users without password field, accept any password (backward compatibility)
            return true;
          }) as any;
        }
        
        if (mockUser) {
          const { password: _, ...userWithoutPassword } = mockUser;
          localStorage.setItem('token', mockUser.token || 'mock-jwt-token-' + mockUser.id);
          localStorage.setItem('currentUser', JSON.stringify(userWithoutPassword));
          this.currentUserSubject.next(userWithoutPassword);
          console.log('Login successful for:', email);
          return of(userWithoutPassword as AuthResponse);
        }
        console.error('Login error - Invalid credentials. Email not found:', email);
        throw new Error('Invalid email or password');
      })
    );
  }

  register(user: any): Observable<AuthResponse> {
    // Try backend first
    return this.http.post<AuthResponse>(`${this.apiUrl}/register`, user).pipe(
      tap((response: AuthResponse) => {
        if (response && response.token) {
          localStorage.setItem('token', response.token);
          localStorage.setItem('currentUser', JSON.stringify(response));
          this.currentUserSubject.next(response);
        }
      }),
      catchError(error => {
        // Fallback to mock registration for development
        console.log('Backend registration failed, using mock registration');
        const newUser: AuthResponse = {
          id: Math.max(...this.mockUsers.map(u => u.id), 0) + 1,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          token: 'mock-jwt-token-' + Math.random().toString(36).substr(2, 9),
          type: 'USER'
        };
        localStorage.setItem('token', newUser.token);
        localStorage.setItem('currentUser', JSON.stringify(newUser));
        this.currentUserSubject.next(newUser);
        return of(newUser);
      })
    );
  }

  logout(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('currentUser');
    this.currentUserSubject.next(null);
  }

  getCurrentUser$(): Observable<any> {
    return this.currentUser$;
  }

  getCurrentUserValue(): any {
    return this.currentUserSubject.value;
  }

  isLoggedIn(): boolean {
    return !!localStorage.getItem('token');
  }
}
