import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserManagementService } from '../../services/user-management.service';
import { User } from '../../models/user.model';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-user-edit',
  template: `
    <div class="form-container">
      <h2>Edit User</h2>
      
      <!-- Error Alert -->
      <div *ngIf="errorMessage" class="alert alert-error">
        <span>{{ errorMessage }}</span>
        <button class="close-btn" (click)="clearError()">&times;</button>
      </div>

      <!-- Success Alert -->
      <div *ngIf="successMessage" class="alert alert-success">
        {{ successMessage }}
      </div>

      <form (ngSubmit)="onSubmit()" [ngClass]="{'form-disabled': isLoading}" *ngIf="user">
        <div class="form-row">
          <div class="form-group">
            <label for="firstName">First Name: <span class="required">*</span></label>
            <input
              type="text"
              id="firstName"
              [(ngModel)]="user.firstName"
              name="firstName"
              class="form-control"
              required
              [disabled]="isLoading"
              (blur)="validateField('firstName')"
            />
            <span *ngIf="fieldErrors['firstName']" class="error-text">{{ fieldErrors['firstName'] }}</span>
          </div>

          <div class="form-group">
            <label for="lastName">Last Name: <span class="required">*</span></label>
            <input
              type="text"
              id="lastName"
              [(ngModel)]="user.lastName"
              name="lastName"
              class="form-control"
              required
              [disabled]="isLoading"
              (blur)="validateField('lastName')"
            />
            <span *ngIf="fieldErrors['lastName']" class="error-text">{{ fieldErrors['lastName'] }}</span>
          </div>
        </div>

        <div class="form-group">
          <label for="email">Email: <span class="required">*</span></label>
          <input
            type="email"
            id="email"
            [(ngModel)]="user.email"
            name="email"
            class="form-control"
            required
            [disabled]="isLoading"
            (blur)="validateField('email')"
          />
          <span *ngIf="fieldErrors['email']" class="error-text">{{ fieldErrors['email'] }}</span>
        </div>

        <div class="form-group">
          <label for="type">User Type: <span class="required">*</span></label>
          <select
            id="type"
            [(ngModel)]="user.type"
            name="type"
            class="form-control"
            required
            [disabled]="isLoading"
          >
            <option value="">Select Type</option>
            <option value="ADMIN">Administrator</option>
            <option value="USER">User</option>
            <option value="MANAGER">Manager</option>
          </select>
          <span *ngIf="fieldErrors['type']" class="error-text">{{ fieldErrors['type'] }}</span>
        </div>

        <div class="button-group">
          <button 
            type="submit" 
            class="btn btn-primary"
            [disabled]="isLoading || !isFormValid()"
          >
            <span *ngIf="!isLoading">Update User</span>
            <span *ngIf="isLoading">Updating...</span>
          </button>
          <button 
            type="button" 
            class="btn btn-secondary" 
            (click)="onCancel()"
            [disabled]="isLoading"
          >
            Cancel
          </button>
        </div>
      </form>
    </div>
  `,
  styles: [`
    .form-container {
      max-width: 600px;
      margin: 2rem auto;
      padding: 2rem;
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }

    h2 {
      margin-bottom: 2rem;
      color: #2c3e50;
    }

    .alert {
      padding: 1rem;
      margin-bottom: 1.5rem;
      border-radius: 4px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .alert-error {
      background-color: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }

    .alert-success {
      background-color: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }

    .close-btn {
      background: none;
      border: none;
      font-size: 1.5rem;
      cursor: pointer;
      color: inherit;
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 1.5rem;
    }

    form.form-disabled {
      opacity: 0.6;
      pointer-events: none;
    }

    .form-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1rem;
    }

    .form-group {
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
    }

    label {
      font-weight: 600;
      color: #2c3e50;
      font-size: 0.95rem;
    }

    .required {
      color: #e74c3c;
    }

    .form-control {
      padding: 0.75rem;
      border: 1px solid #bdc3c7;
      border-radius: 4px;
      font-size: 1rem;
      font-family: inherit;
      transition: border-color 0.2s;
    }

    .form-control:focus {
      outline: none;
      border-color: #3498db;
      box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.1);
    }

    .form-control:disabled {
      background-color: #ecf0f1;
      cursor: not-allowed;
      color: #95a5a6;
    }

    .error-text {
      color: #e74c3c;
      font-size: 0.85rem;
      margin-top: 0.25rem;
    }

    .button-group {
      display: flex;
      gap: 1rem;
      margin-top: 1rem;
    }

    .btn {
      padding: 0.75rem 1.5rem;
      border: none;
      border-radius: 4px;
      font-size: 1rem;
      font-weight: bold;
      cursor: pointer;
      transition: background-color 0.2s;
    }

    .btn-primary {
      background-color: #3498db;
      color: white;
    }

    .btn-primary:hover:not(:disabled) {
      background-color: #2980b9;
    }

    .btn-primary:disabled {
      background-color: #bdc3c7;
      cursor: not-allowed;
      opacity: 0.6;
    }

    .btn-secondary {
      background-color: #95a5a6;
      color: white;
    }

    .btn-secondary:hover:not(:disabled) {
      background-color: #7f8c8d;
    }

    .btn-secondary:disabled {
      cursor: not-allowed;
      opacity: 0.6;
    }

    @media (max-width: 600px) {
      .form-row {
        grid-template-columns: 1fr;
      }

      .button-group {
        flex-direction: column;
      }
    }
  `]
})
export class UserEditComponent implements OnInit, OnDestroy {
  user: User | null = null;
  userId: number | null = null;

  isLoading = false;
  errorMessage = '';
  successMessage = '';
  fieldErrors: { [key: string]: string } = {};

  private destroy$ = new Subject<void>();

  constructor(
    private userManagementService: UserManagementService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.route.params.pipe(takeUntil(this.destroy$)).subscribe((params: any) => {
      if (params['id']) {
        this.userId = +params['id'];
        if (this.userId) {
          this.loadUser(this.userId);
        }
      }
    });
  }

  loadUser(id: number): void {
    this.isLoading = true;
    const user = this.userManagementService.getUserById(id);
    if (user) {
      this.user = { ...user };
      this.isLoading = false;
    } else {
      this.errorMessage = 'User not found';
      this.isLoading = false;
      setTimeout(() => this.router.navigate(['/users']), 1500);
    }
  }

  validateField(fieldName: string): void {
    if (!this.user) return;
    this.fieldErrors[fieldName] = '';

    switch (fieldName) {
      case 'firstName':
        if (!this.user.firstName || this.user.firstName.trim().length === 0) {
          this.fieldErrors[fieldName] = 'First name is required';
        }
        break;
      case 'lastName':
        if (!this.user.lastName || this.user.lastName.trim().length === 0) {
          this.fieldErrors[fieldName] = 'Last name is required';
        }
        break;
      case 'email':
        if (!this.user.email || this.user.email.trim().length === 0) {
          this.fieldErrors[fieldName] = 'Email is required';
        } else if (!this.isValidEmail(this.user.email)) {
          this.fieldErrors[fieldName] = 'Invalid email format';
        }
        break;
      case 'type':
        if (!this.user.type) {
          this.fieldErrors[fieldName] = 'User type is required';
        }
        break;
    }
  }

  isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  isFormValid(): boolean {
    if (!this.user) return false;
    return this.user.firstName?.trim().length > 0 &&
           this.user.lastName?.trim().length > 0 &&
           this.user.email?.trim().length > 0 &&
           this.isValidEmail(this.user.email) &&
           (this.user.type?.length || 0) > 0;
  }

  onSubmit(): void {
    if (!this.user || !this.userId) return;

    // Validate all fields
    this.validateField('firstName');
    this.validateField('lastName');
    this.validateField('email');
    this.validateField('type');

    if (!this.isFormValid()) {
      const missingFields = [];
      if (!this.user.firstName?.trim()) missingFields.push('First Name');
      if (!this.user.lastName?.trim()) missingFields.push('Last Name');
      if (!this.user.email?.trim() || !this.isValidEmail(this.user.email)) missingFields.push('Email');
      if (!this.user.type) missingFields.push('User Type');

      this.errorMessage = 'Please fill in all required fields: ' + missingFields.join(', ');
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';

    // Update user
    try {
      this.userManagementService.updateUser(this.userId, this.user);
      this.successMessage = 'User updated successfully!';
      this.isLoading = false;
      setTimeout(() => this.router.navigate(['/users']), 1500);
    } catch (error) {
      this.errorMessage = 'Failed to update user. Please try again.';
      this.isLoading = false;
    }
  }

  clearError(): void {
    this.errorMessage = '';
  }

  onCancel(): void {
    this.router.navigate(['/users']);
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
