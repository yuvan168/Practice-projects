import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { UserManagementService } from '../../services/user-management.service';
import { User } from '../../models/user.model';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-user-list',
  template: `
    <div class="user-list-container">
      <div class="header">
        <h2>Users Management</h2>
        <button class="btn btn-add" (click)="addUser()">+ Add User</button>
      </div>

      <!-- Error Alert -->
      <div *ngIf="errorMessage" class="alert alert-error">
        <span>{{ errorMessage }}</span>
        <button class="close-btn" (click)="clearError()">&times;</button>
      </div>

      <!-- Success Alert -->
      <div *ngIf="successMessage" class="alert alert-success">
        {{ successMessage }}
      </div>

      <!-- Loading Spinner -->
      <div *ngIf="loading" class="loading">
        <div class="spinner"></div>
        <p>Loading users...</p>
      </div>

      <!-- Users Table -->
      <div *ngIf="!loading" class="table-wrapper">
        <div class="table-info">
          <span>Total Users: {{ users.length }}</span>
        </div>

        <table class="user-table" *ngIf="users.length > 0">
          <thead>
            <tr>
              <th>ID</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Email</th>
              <th>Type</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let user of users">
              <td>{{ user.id }}</td>
              <td>{{ user.firstName }}</td>
              <td>{{ user.lastName }}</td>
              <td>{{ user.email }}</td>
              <td>
                <span [class]="'badge badge-' + (user.type?.toLowerCase() || 'user')">
                  {{ user.type || 'USER' }}
                </span>
              </td>
              <td>
                <button class="btn-sm btn-edit" (click)="editUser(user.id!)">Edit</button>
                <button class="btn-sm btn-delete" (click)="deleteUser(user.id!)">Delete</button>
              </td>
            </tr>
          </tbody>
        </table>

        <div *ngIf="users.length === 0" class="empty-state">
          <p>No users yet</p>
          <button class="btn btn-primary" (click)="addUser()">Add First User</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .user-list-container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 2rem;
    }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2rem;
    }

    .header h2 {
      margin: 0;
      color: #2c3e50;
      font-size: 2rem;
    }

    .btn-add {
      background-color: #27ae60;
      color: white;
      padding: 0.75rem 1.5rem;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-weight: bold;
      transition: background-color 0.2s;
    }

    .btn-add:hover {
      background-color: #229954;
    }

    .alert {
      padding: 1rem;
      margin-bottom: 1.5rem;
      border-radius: 4px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .alert-error {
      background-color: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }

    .alert-success {
      background-color: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }

    .close-btn {
      background: none;
      border: none;
      font-size: 1.5rem;
      cursor: pointer;
      color: inherit;
    }

    .loading {
      text-align: center;
      padding: 2rem;
    }

    .spinner {
      border: 4px solid #f3f3f3;
      border-top: 4px solid #3498db;
      border-radius: 50%;
      width: 40px;
      height: 40px;
      animation: spin 1s linear infinite;
      margin: 0 auto 1rem;
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    .table-wrapper {
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      overflow: hidden;
    }

    .table-info {
      padding: 1rem;
      background-color: #f8f9fa;
      border-bottom: 1px solid #e9ecef;
      font-weight: bold;
      color: #2c3e50;
    }

    .user-table {
      width: 100%;
      border-collapse: collapse;
    }

    .user-table thead {
      background-color: #34495e;
      color: white;
    }

    .user-table th {
      padding: 1rem;
      text-align: left;
      font-weight: bold;
    }

    .user-table td {
      padding: 1rem;
      border-bottom: 1px solid #e9ecef;
      color: #2c3e50;
    }

    .user-table tbody tr:hover {
      background-color: #f8f9fa;
    }

    .badge {
      display: inline-block;
      padding: 0.25rem 0.75rem;
      border-radius: 20px;
      font-size: 0.875rem;
      font-weight: bold;
    }

    .badge-admin {
      background-color: #e74c3c;
      color: white;
    }

    .badge-manager {
      background-color: #f39c12;
      color: white;
    }

    .badge-user {
      background-color: #3498db;
      color: white;
    }

    .btn-sm {
      padding: 0.5rem 1rem;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 0.875rem;
      font-weight: bold;
      transition: background-color 0.2s;
      margin-right: 0.5rem;
    }

    .btn-edit {
      background-color: #3498db;
      color: white;
    }

    .btn-edit:hover {
      background-color: #2980b9;
    }

    .btn-delete {
      background-color: #e74c3c;
      color: white;
    }

    .btn-delete:hover {
      background-color: #c0392b;
    }

    .empty-state {
      text-align: center;
      padding: 3rem;
      color: #7f8c8d;
    }

    .empty-state p {
      margin: 0 0 1rem 0;
      font-size: 1.1rem;
    }

    .btn-primary {
      background-color: #3498db;
      color: white;
      padding: 0.75rem 1.5rem;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-weight: bold;
      transition: background-color 0.2s;
    }

    .btn-primary:hover {
      background-color: #2980b9;
    }

    @media (max-width: 768px) {
      .header {
        flex-direction: column;
        align-items: flex-start;
        gap: 1rem;
      }

      .user-table {
        font-size: 0.875rem;
      }

      .user-table th,
      .user-table td {
        padding: 0.75rem 0.5rem;
      }
    }
  `]
})
export class UserListComponent implements OnInit, OnDestroy {
  users: User[] = [];

  loading = false;
  errorMessage = '';
  successMessage = '';

  private destroy$ = new Subject<void>();

  constructor(
    private router: Router,
    private userManagementService: UserManagementService
  ) { }

  ngOnInit(): void {
    this.loadUsers();
  }

  loadUsers(): void {
    this.loading = true;
    // Load users from service
    this.userManagementService.getAllUsers()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (users) => {
          this.users = users;
          this.loading = false;
          console.log('Users loaded:', this.users);
        },
        error: (error) => {
          this.errorMessage = 'Failed to load users';
          this.loading = false;
          console.error('Error loading users:', error);
        }
      });
  }

  addUser(): void {
    this.router.navigate(['/users/add']);
  }

  editUser(id: number): void {
    this.router.navigate(['/users/edit', id]);
  }

  deleteUser(id: number): void {
    if (confirm('Are you sure you want to delete this user?')) {
      const deleted = this.userManagementService.deleteUser(id);
      if (deleted) {
        this.users = this.users.filter(u => u.id !== id);
        this.successMessage = 'User deleted successfully!';
        setTimeout(() => {
          this.successMessage = '';
        }, 3000);
      } else {
        this.errorMessage = 'Failed to delete user';
      }
    }
  }

  clearError(): void {
    this.errorMessage = '';
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
