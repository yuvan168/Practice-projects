import { Component, OnInit, OnDestroy } from '@angular/core';
import { ProductService } from '../../services/user.service';
import { Product, ProductStatistics } from '../../models/user.model';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-reports',
  template: `
    <div class="reports-container">
      <div class="reports-header">
        <h1>📈 Reports & Analytics</h1>
      </div>

      <!-- Loading State -->
      <div *ngIf="loading" class="loading-container">
        <div class="spinner"></div>
        <p>Loading reports...</p>
      </div>

      <!-- Reports Content -->
      <div *ngIf="!loading" class="reports-grid">
        
        <!-- Statistics Cards -->
        <div class="card stats-card">
          <h2>Product Statistics</h2>
          <div class="stat-item">
            <span class="stat-label">Total Products</span>
            <span class="stat-value">{{ stats?.totalProducts || 0 }}</span>
          </div>
          <div class="stat-item">
            <span class="stat-label">Active Products</span>
            <span class="stat-value">{{ stats?.activeProducts || 0 }}</span>
          </div>
          <div class="stat-item">
            <span class="stat-label">Out of Stock</span>
            <span class="stat-value">{{ stats?.outOfStockProducts || 0 }}</span>
          </div>
          <div class="stat-item">
            <span class="stat-label">Discounted Items</span>
            <span class="stat-value">{{ stats?.productsWithDiscount || 0 }}</span>
          </div>
          <div class="stat-item highlight">
            <span class="stat-label">Total Inventory Value</span>
            <span class="stat-value">₹{{ stats?.totalInventoryValue | number:'1.2-2' || '0.00' }}</span>
          </div>
        </div>

        <!-- Low Stock Products -->
        <div class="card">
          <h2>Low Stock Products (< 10)</h2>
          <div *ngIf="lowStockProducts.length > 0">
            <table class="report-table">
              <thead>
                <tr>
                  <th>Product Name</th>
                  <th>SKU</th>
                  <th>Stock</th>
                  <th>Price</th>
                </tr>
              </thead>
              <tbody>
                <tr *ngFor="let product of lowStockProducts">
                  <td>{{ product.productName }}</td>
                  <td>{{ product.sku }}</td>
                  <td><span class="badge-warning">{{ product.quantity }}</span></td>
                  <td>₹{{ product.price | number:'1.2-2' }}</td>
                </tr>
              </tbody>
            </table>
          </div>
          <div *ngIf="lowStockProducts.length === 0" class="empty-state">
            <p>No low stock products</p>
          </div>
        </div>

        <!-- Discounted Products -->
        <div class="card">
          <h2>Discounted Products</h2>
          <div *ngIf="discountedProducts.length > 0">
            <table class="report-table">
              <thead>
                <tr>
                  <th>Product Name</th>
                  <th>Original Price</th>
                  <th>Discount</th>
                  <th>Final Price</th>
                </tr>
              </thead>
              <tbody>
                <tr *ngFor="let product of discountedProducts">
                  <td>{{ product.productName }}</td>
                  <td>₹{{ product.price | number:'1.2-2' }}</td>
                  <td><span class="badge-success">-{{ product.discount }}%</span></td>
                  <td>₹{{ (product.price! * (1 - (product.discount || 0) / 100)) | number:'1.2-2' }}</td>
                </tr>
              </tbody>
            </table>
          </div>
          <div *ngIf="discountedProducts.length === 0" class="empty-state">
            <p>No discounted products</p>
          </div>
        </div>

        <!-- Out of Stock Products -->
        <div class="card">
          <h2>Out of Stock Products</h2>
          <div *ngIf="outOfStockProducts.length > 0">
            <table class="report-table">
              <thead>
                <tr>
                  <th>Product Name</th>
                  <th>SKU</th>
                  <th>Price</th>
                  <th>Product Code</th>
                </tr>
              </thead>
              <tbody>
                <tr *ngFor="let product of outOfStockProducts">
                  <td>{{ product.productName }}</td>
                  <td>{{ product.sku }}</td>
                  <td>₹{{ product.price | number:'1.2-2' }}</td>
                  <td>{{ product.productCode }}</td>
                </tr>
              </tbody>
            </table>
          </div>
          <div *ngIf="outOfStockProducts.length === 0" class="empty-state">
            <p>No out of stock products</p>
          </div>
        </div>

        <!-- Price Analysis -->
        <div class="card">
          <h2>Price Analysis</h2>
          <div class="price-stats">
            <div class="price-item">
              <span class="label">Highest Price</span>
              <span class="value">₹{{ maxPrice | number:'1.2-2' }}</span>
            </div>
            <div class="price-item">
              <span class="label">Lowest Price</span>
              <span class="value">₹{{ minPrice | number:'1.2-2' }}</span>
            </div>
            <div class="price-item">
              <span class="label">Average Price</span>
              <span class="value">₹{{ avgPrice | number:'1.2-2' }}</span>
            </div>
            <div class="price-item">
              <span class="label">Total SKUs</span>
              <span class="value">{{ allProducts.length }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .reports-container {
      padding: 20px;
      max-width: 1400px;
      margin: 0 auto;
    }

    .reports-header {
      margin-bottom: 30px;
    }

    .reports-header h1 {
      margin: 0;
      font-size: 2.5em;
      color: #333;
    }

    .loading-container {
      text-align: center;
      padding: 60px 20px;
    }

    .spinner {
      width: 50px;
      height: 50px;
      border: 4px solid #f3f3f3;
      border-top: 4px solid #007bff;
      border-radius: 50%;
      animation: spin 1s linear infinite;
      margin: 0 auto 20px;
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    .reports-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
      gap: 20px;
    }

    .card {
      background: white;
      border-radius: 8px;
      padding: 20px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .card h2 {
      margin-top: 0;
      margin-bottom: 20px;
      color: #333;
      border-bottom: 2px solid #007bff;
      padding-bottom: 10px;
    }

    .stats-card {
      grid-column: 1 / -1;
    }

    .stat-item {
      display: flex;
      justify-content: space-between;
      padding: 12px 0;
      border-bottom: 1px solid #eee;
    }

    .stat-item.highlight {
      background: #f0f8ff;
      padding: 12px;
      border-radius: 4px;
      border: none;
      font-weight: bold;
    }

    .stat-label {
      font-weight: 500;
      color: #666;
    }

    .stat-value {
      font-weight: bold;
      font-size: 1.1em;
      color: #007bff;
    }

    .report-table {
      width: 100%;
      border-collapse: collapse;
    }

    .report-table thead {
      background: #f5f5f5;
    }

    .report-table th,
    .report-table td {
      padding: 12px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }

    .report-table th {
      font-weight: bold;
      color: #333;
    }

    .report-table tbody tr:hover {
      background: #f9f9f9;
    }

    .badge-warning {
      background: #ffc107;
      color: #333;
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 0.9em;
      font-weight: bold;
    }

    .badge-success {
      background: #28a745;
      color: white;
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 0.9em;
      font-weight: bold;
    }

    .empty-state {
      text-align: center;
      padding: 40px 20px;
      color: #999;
    }

    .price-stats {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 15px;
    }

    .price-item {
      padding: 15px;
      background: #f9f9f9;
      border-radius: 6px;
      border-left: 4px solid #007bff;
    }

    .price-item .label {
      display: block;
      font-size: 0.9em;
      color: #666;
      margin-bottom: 5px;
    }

    .price-item .value {
      display: block;
      font-size: 1.5em;
      font-weight: bold;
      color: #007bff;
    }
  `]
})
export class ReportsComponent implements OnInit, OnDestroy {
  loading = true;
  stats: any;
  allProducts: Product[] = [];
  lowStockProducts: Product[] = [];
  discountedProducts: Product[] = [];
  outOfStockProducts: Product[] = [];
  
  maxPrice = 0;
  minPrice = 0;
  avgPrice = 0;

  private destroy$ = new Subject<void>();

  constructor(private productService: ProductService) {}

  ngOnInit(): void {
    this.loadReports();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  loadReports(): void {
    this.loading = true;

    // Get all products
    this.productService.getAllProducts().pipe(takeUntil(this.destroy$)).subscribe({
      next: (products: Product[]) => {
        this.allProducts = products;
        this.calculateMetrics();
        
        // Calculate statistics locally from all products
        this.stats = this.calculateStatistics(products);
        this.loading = false;
      },
      error: (err: any) => {
        console.error('Error loading products:', err);
        this.loading = false;
      }
    });

    // Get low stock products
    this.productService.getLowStockProducts(10).pipe(takeUntil(this.destroy$)).subscribe({
      next: (products: Product[]) => {
        this.lowStockProducts = products;
      },
      error: (err: any) => console.error('Error loading low stock:', err)
    });

    // Get discounted products (using low stock as fallback)
    this.productService.getLowStockProducts(100).pipe(takeUntil(this.destroy$)).subscribe({
      next: (products: Product[]) => {
        this.discountedProducts = products;
      },
      error: (err: any) => console.error('Error loading discounted:', err)
    });

    // Get out of stock products
    this.productService.getOutOfStockProducts().pipe(takeUntil(this.destroy$)).subscribe({
      next: (products: Product[]) => {
        this.outOfStockProducts = products;
      },
      error: (err: any) => console.error('Error loading out of stock:', err)
    });
  }

  private calculateMetrics(): void {
    if (this.allProducts.length === 0) {
      this.maxPrice = 0;
      this.minPrice = 0;
      this.avgPrice = 0;
      return;
    }

    const prices = this.allProducts.map(p => p.price || 0);
    this.maxPrice = Math.max(...prices);
    this.minPrice = Math.min(...prices);
    this.avgPrice = prices.reduce((a, b) => a + b, 0) / prices.length;
  }

  private calculateStatistics(products: Product[]): any {
    const totalProducts = products.length;
    const totalValue = products.reduce((sum, p) => sum + (p.price || 0) * (p.quantity || 0), 0);
    const totalQuantity = products.reduce((sum, p) => sum + (p.quantity || 0), 0);
    const averagePrice = totalProducts > 0 ? products.reduce((sum, p) => sum + (p.price || 0), 0) / totalProducts : 0;
    const productsWithDiscount = products.filter(p => p.discount && p.discount > 0).length;
    
    // Calculate total inventory value (price * quantity for all products)
    const totalInventoryValue = products.reduce((sum, p) => {
      return sum + ((p.price || 0) * (p.quantity || 0));
    }, 0);

    return {
      totalProducts,
      totalValue: totalInventoryValue,
      totalInventoryValue,
      totalQuantity,
      averagePrice,
      activeProducts: products.filter(p => p.quantity! > 0).length,
      outOfStockProducts: products.filter(p => p.quantity === 0).length,
      productsWithDiscount
    };
  }
}
