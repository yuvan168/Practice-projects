import { Component, OnInit, OnDestroy } from '@angular/core';
import { ProductService } from '../../services/user.service';
import { Product, ProductFilters } from '../../models/user.model';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-product-list',
  template: `
    <div class="product-list-container">
      <div class="header">
        <h2>Product Inventory</h2>
        <button class="btn btn-add" (click)="addProduct()" [disabled]="loading">+ Add Product</button>
      </div>

      <!-- Search and Filter Section -->
      <div class="search-filter">
        <div class="search-box">
          <input
            type="text"
            [(ngModel)]="searchKeyword"
            placeholder="Search products..."
            class="search-input"
            (keyup.enter)="search()"
          />
          <button class="btn btn-search" (click)="search()" [disabled]="loading">Search</button>
        </div>
        
        <div class="filter-box">
          <select [(ngModel)]="selectedCategory" class="filter-select" (change)="applyFilters()">
            <option value="">All Categories</option>
            <option *ngFor="let cat of categories" [value]="cat">{{ cat }}</option>
          </select>
          <button class="btn btn-reset" (click)="resetFilters()">Reset</button>
        </div>
      </div>

      <!-- Error Alert -->
      <div *ngIf="errorMessage" class="alert alert-error">
        <span>{{ errorMessage }}</span>
        <button class="close-btn" (click)="clearError()">&times;</button>
      </div>

      <!-- Success Alert -->
      <div *ngIf="successMessage" class="alert alert-success">
        {{ successMessage }}
      </div>

      <!-- Loading Spinner -->
      <div *ngIf="loading" class="loading">
        <div class="spinner"></div>
        <p>Loading products...</p>
      </div>

      <!-- Products Display -->
      <div *ngIf="!loading" class="products-wrapper">
        <div class="products-info">
          <span>{{ filteredProducts.length }} of {{ totalProducts }} products</span>
          <div class="view-controls">
            <label><input type="checkbox" [(ngModel)]="gridView" /> Grid View</label>
          </div>
        </div>

        <!-- Grid View (Cards) -->
        <div *ngIf="gridView && filteredProducts.length > 0" class="products-grid">
          <div *ngFor="let product of filteredProducts" class="product-card" [class.low-stock]="product.quantity < 10">
            <div class="card-header">
              <h3>{{ product.productName }}</h3>
              <span *ngIf="product.discount && product.discount > 0" class="discount-badge">
                -{{ product.discount }}%
              </span>
              <span *ngIf="product.quantity === 0" class="stock-badge out-of-stock">Out of Stock</span>
              <span *ngIf="product.quantity > 0 && product.quantity < 10" class="stock-badge low-stock">Low Stock</span>
              <span *ngIf="product.quantity >= 10" class="stock-badge in-stock">In Stock</span>
            </div>

            <div class="card-body">
              <div class="info-row">
                <span class="label">Category:</span>
                <span class="value">{{ product.category || 'Uncategorized' }}</span>
              </div>
              <div class="info-row">
                <span class="label">SKU:</span>
                <span class="value">{{ product.sku }}</span>
              </div>
              <div class="info-row">
                <span class="label">Price:</span>
                <span class="value price">₹{{ product.price | number:'1.2-2' }}</span>
              </div>
              <div class="info-row">
                <span class="label">Quantity:</span>
                <span class="value" [class.warning]="product.quantity < 10">{{ product.quantity }} units</span>
              </div>
              <div class="info-row" *ngIf="product.description">
                <span class="label">Description:</span>
                <span class="value description">{{ product.description | slice:0:50 }}{{ product.description.length > 50 ? '...' : '' }}</span>
              </div>
            </div>

            <div class="card-footer">
              <button class="btn btn-sm btn-edit" (click)="editProduct(product.id!)" 
                      title="Edit product" [disabled]="loading">
                ✏️ Edit
              </button>
              <button class="btn btn-sm btn-delete" (click)="deleteProduct(product.id!)" 
                      title="Delete product" [disabled]="loading">
                🗑️ Delete
              </button>
            </div>
          </div>
        </div>

        <!-- Table View -->
        <table class="product-table" *ngIf="!gridView && filteredProducts.length > 0">
          <thead>
            <tr>
              <th (click)="sortBy('id')" class="sortable">
                ID
                <span class="sort-icon" *ngIf="sortColumn === 'id'">
                  {{ sortDirection === 'asc' ? '▲' : '▼' }}
                </span>
              </th>
              <th (click)="sortBy('productName')" class="sortable">
                Product Name
                <span class="sort-icon" *ngIf="sortColumn === 'productName'">
                  {{ sortDirection === 'asc' ? '▲' : '▼' }}
                </span>
              </th>
              <th (click)="sortBy('category')" class="sortable">
                Category
                <span class="sort-icon" *ngIf="sortColumn === 'category'">
                  {{ sortDirection === 'asc' ? '▲' : '▼' }}
                </span>
              </th>
              <th>SKU</th>
              <th (click)="sortBy('price')" class="sortable">
                Price
                <span class="sort-icon" *ngIf="sortColumn === 'price'">
                  {{ sortDirection === 'asc' ? '▲' : '▼' }}
                </span>
              </th>
              <th (click)="sortBy('quantity')" class="sortable">
                Quantity
                <span class="sort-icon" *ngIf="sortColumn === 'quantity'">
                  {{ sortDirection === 'asc' ? '▲' : '▼' }}
                </span>
              </th>
              <th>Discount</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let product of filteredProducts" 
                [class.low-stock]="product.quantity < 10"
                [class.out-of-stock]="product.quantity === 0">
              <td>{{ product.id }}</td>
              <td class="product-name">{{ product.productName }}</td>
              <td>{{ product.category || '—' }}</td>
              <td class="sku">{{ product.sku }}</td>
              <td class="price">₹{{ product.price | number:'1.2-2' }}</td>
              <td>
                <span [class.quantity-warning]="product.quantity < 10">
                  {{ product.quantity }}
                </span>
              </td>
              <td>
                <span *ngIf="product.discount && product.discount > 0" class="badge-success">
                  -{{ product.discount }}%
                </span>
                <span *ngIf="!product.discount || product.discount === 0">—</span>
              </td>
              <td class="actions">
                <button class="btn btn-sm btn-edit" (click)="editProduct(product.id!)" 
                        title="Edit product" [disabled]="loading">
                  ✏️ Edit
                </button>
                <button class="btn btn-sm btn-delete" (click)="deleteProduct(product.id!)" 
                        title="Delete product" [disabled]="loading">
                  🗑️ Delete
                </button>
              </td>
            </tr>
          </tbody>
        </table>

        <!-- No Products Message -->
        <div *ngIf="filteredProducts.length === 0" class="no-data">
          <p>No products found</p>
          <button class="btn btn-primary" (click)="addProduct()">Add your first product</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .product-list-container {
      padding: 2rem;
      max-width: 1200px;
      margin: 0 auto;
    }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2rem;
    }

    h2 {
      color: #2c3e50;
      margin: 0;
    }

    .btn-add {
      background-color: #27ae60;
      color: white;
      padding: 0.75rem 1.5rem;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-weight: bold;
      transition: background-color 0.2s;
    }

    .btn-add:hover:not(:disabled) {
      background-color: #229954;
    }

    .btn-add:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }

    .search-filter {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1rem;
      margin-bottom: 2rem;
    }

    .search-box, .filter-box {
      display: flex;
      gap: 0.5rem;
    }

    .search-input, .filter-select {
      flex: 1;
      padding: 0.75rem;
      border: 1px solid #bdc3c7;
      border-radius: 4px;
      font-size: 1rem;
    }

    .btn-search, .btn-reset {
      padding: 0.75rem 1.5rem;
      background-color: #3498db;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-weight: bold;
    }

    .btn-reset {
      background-color: #95a5a6;
    }

    .alert {
      padding: 1rem;
      margin-bottom: 1.5rem;
      border-radius: 4px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .alert-error {
      background-color: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }

    .alert-success {
      background-color: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }

    .close-btn {
      background: none;
      border: none;
      font-size: 1.5rem;
      cursor: pointer;
      color: inherit;
    }

    .loading {
      text-align: center;
      padding: 3rem 2rem;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 1rem;
    }

    .spinner {
      border: 4px solid #f3f3f3;
      border-top: 4px solid #3498db;
      border-radius: 50%;
      width: 40px;
      height: 40px;
      animation: spin 1s linear infinite;
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    .table-wrapper {
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      overflow: hidden;
    }

    .table-info, .products-info {
      padding: 1rem;
      background-color: #ecf0f1;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 0.875rem;
      color: #2c3e50;
      border-bottom: 1px solid #bdc3c7;
    }

    .view-controls {
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }

    .view-controls label {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      cursor: pointer;
    }

    .view-controls input {
      cursor: pointer;
      width: 16px;
      height: 16px;
    }

    .products-wrapper {
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      overflow: hidden;
    }

    .products-grid {
      padding: 2rem;
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
      gap: 1.5rem;
    }

    .product-card {
      background: white;
      border: 1px solid #e0e0e0;
      border-radius: 8px;
      overflow: hidden;
      transition: all 0.3s ease;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      display: flex;
      flex-direction: column;
    }

    .product-card:hover {
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      transform: translateY(-2px);
    }

    .product-card.low-stock {
      border-left: 4px solid #f39c12;
    }

    .card-header {
      padding: 1rem;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      position: relative;
    }

    .card-header h3 {
      margin: 0 0 0.5rem 0;
      font-size: 1.1rem;
      word-break: break-word;
    }

    .discount-badge, .stock-badge {
      display: inline-block;
      padding: 0.25rem 0.5rem;
      border-radius: 3px;
      font-size: 0.75rem;
      font-weight: bold;
      margin-right: 0.25rem;
      margin-top: 0.25rem;
    }

    .discount-badge {
      background-color: rgba(255, 255, 255, 0.3);
      color: white;
    }

    .stock-badge {
      padding: 0.3rem 0.6rem;
      font-size: 0.7rem;
    }

    .stock-badge.in-stock {
      background-color: #27ae60;
      color: white;
    }

    .stock-badge.low-stock {
      background-color: #f39c12;
      color: white;
    }

    .stock-badge.out-of-stock {
      background-color: #e74c3c;
      color: white;
    }

    .card-body {
      padding: 1rem;
      flex-grow: 1;
    }

    .info-row {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      padding: 0.5rem 0;
      border-bottom: 1px solid #f0f0f0;
    }

    .info-row:last-child {
      border-bottom: none;
    }

    .info-row .label {
      font-weight: 600;
      color: #34495e;
      min-width: 80px;
    }

    .info-row .value {
      text-align: right;
      color: #555;
      flex: 1;
      padding-left: 1rem;
      word-break: break-word;
    }

    .info-row .price {
      font-weight: bold;
      color: #27ae60;
      font-size: 1.1rem;
    }

    .info-row .value.warning {
      color: #e74c3c;
      font-weight: bold;
    }

    .info-row .description {
      color: #7f8c8d;
      font-size: 0.9rem;
    }

    .card-footer {
      padding: 0.75rem 1rem;
      background-color: #f8f9fa;
      display: flex;
      gap: 0.5rem;
      border-top: 1px solid #e0e0e0;
    }

    .product-table {
      width: 100%;
      border-collapse: collapse;
    }

    .product-table th {
      background-color: #34495e;
      color: white;
      padding: 1rem;
      text-align: left;
      font-weight: bold;
      user-select: none;
    }

    .product-table th.sortable {
      cursor: pointer;
      position: relative;
      white-space: nowrap;
    }

    .product-table th.sortable:hover {
      background-color: #2c3e50;
    }

    .sort-icon {
      margin-left: 0.5rem;
      font-size: 0.75rem;
    }

    .checkbox-col {
      width: 40px;
      text-align: center;
    }

    .product-table td {
      padding: 1rem;
      border-bottom: 1px solid #ecf0f1;
    }

    .product-table tbody tr {
      transition: background-color 0.2s;
    }

    .product-table tbody tr:hover {
      background-color: #f8f9fa;
    }

    .product-table tbody tr.selected {
      background-color: #e8f4f8;
    }

    .product-table tbody tr.low-stock {
      background-color: #fff3cd;
    }

    .product-table tbody tr.out-of-stock {
      background-color: #f8d7da;
    }

    .product-name {
      font-weight: 500;
      color: #2c3e50;
    }

    .category-badge {
      display: inline-block;
      padding: 0.25rem 0.75rem;
      background-color: #ecf0f1;
      color: #2c3e50;
      border-radius: 20px;
      font-size: 0.875rem;
    }

    .sku {
      font-family: monospace;
      color: #7f8c8d;
    }

    .price {
      font-weight: bold;
      color: #27ae60;
    }

    .quantity-warning {
      color: #e74c3c;
      font-weight: bold;
    }

    .description {
      max-width: 200px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      color: #7f8c8d;
    }

    .actions {
      display: flex;
      gap: 0.25rem;
      white-space: nowrap;
    }

    .btn-sm {
      padding: 0.4rem 0.6rem;
      font-size: 0.75rem;
      border: none;
      border-radius: 3px;
      cursor: pointer;
      transition: background-color 0.2s;
      flex: 1;
      text-align: center;
    }

    .btn-edit {
      background-color: #3498db;
      color: white;
    }

    .btn-edit:hover:not(:disabled) {
      background-color: #2980b9;
    }

    .btn-delete {
      background-color: #e74c3c;
      color: white;
    }

    .btn-delete:hover:not(:disabled) {
      background-color: #c0392b;
    }

    .btn:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }

    .no-data {
      text-align: center;
      padding: 3rem 2rem;
      color: #7f8c8d;
    }

    .no-data p {
      margin-bottom: 1rem;
      font-size: 1.1rem;
    }

    input[type="checkbox"] {
      cursor: pointer;
      width: 18px;
      height: 18px;
    }

    .badge-success {
      background-color: #d4edda;
      color: #155724;
      padding: 0.25rem 0.5rem;
      border-radius: 3px;
      font-size: 0.875rem;
      font-weight: bold;
    }

    @media (max-width: 1024px) {
      .products-grid {
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      }
    }

    @media (max-width: 768px) {
      .search-filter {
        grid-template-columns: 1fr;
      }

      .products-grid {
        grid-template-columns: 1fr;
        padding: 1rem;
        gap: 1rem;
      }

      .product-table {
        font-size: 0.875rem;
      }

      .product-table th, .product-table td {
        padding: 0.75rem 0.5rem;
      }

      .actions {
        flex-direction: column;
        gap: 0.25rem;
      }

      .btn-sm {
        width: auto;
      }
    }

  `]
})
export class ProductListComponent implements OnInit, OnDestroy {
  products: Product[] = [];
  filteredProducts: Product[] = [];
  loading = true;
  errorMessage = '';
  successMessage = '';
  gridView = true; // Default to grid view

  // Search and filtering
  searchKeyword = '';
  selectedCategory = '';
  categories = ['Electronics', 'Clothing', 'Food', 'Books', 'Furniture', 'Other'];

  // Sorting
  sortColumn = 'id';
  sortDirection: 'asc' | 'desc' = 'asc';

  // Selection
  selectedProducts = new Set<number>();
  allSelected = false;

  get totalProducts(): number {
    return this.products.length;
  }

  private destroy$ = new Subject<void>();

  constructor(
    private productService: ProductService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.loadProducts();
    this.loadCategories();
    
    this.productService.products$.pipe(takeUntil(this.destroy$)).subscribe(products => {
      this.products = products;
      this.loadCategories();
      this.applyFilters();
    });

    this.productService.error$.pipe(takeUntil(this.destroy$)).subscribe(error => {
      if (error) {
        this.errorMessage = error;
      }
    });
  }

  loadCategories(): void {
    this.productService.getCategories().pipe(takeUntil(this.destroy$)).subscribe({
      next: (cats) => {
        this.categories = cats;
      },
      error: () => {
        // Fallback to hardcoded categories if getCategories fails
        this.categories = ['Electronics', 'Clothing', 'Food', 'Books', 'Furniture', 'Lighting', 'Other'];
      }
    });
  }

  loadProducts(): void {
    this.loading = true;
    this.productService.getAllProducts().pipe(takeUntil(this.destroy$)).subscribe({
      next: (data) => {
        this.products = data;
        this.applyFilters();
        this.loading = false;
      },
      error: () => {
        this.errorMessage = 'Failed to load products';
        this.loading = false;
      }
    });
  }

  search(): void {
    this.applyFilters();
  }

  applyFilters(): void {
    this.filteredProducts = this.products.filter(product => {
      const matchesKeyword = !this.searchKeyword || 
        product.productName.toLowerCase().includes(this.searchKeyword.toLowerCase()) ||
        product.sku.toLowerCase().includes(this.searchKeyword.toLowerCase());

      const matchesCategory = !this.selectedCategory || this.selectedCategory === '' || 
        product.category === this.selectedCategory;

      return matchesKeyword && matchesCategory;
    });

    this.sortProducts();
    this.selectedProducts.clear();
    this.allSelected = false;
  }

  resetFilters(): void {
    this.searchKeyword = '';
    this.selectedCategory = '';
    this.applyFilters();
  }

  sortBy(column: string): void {
    if (this.sortColumn === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumn = column;
      this.sortDirection = 'asc';
    }
    this.sortProducts();
  }

  private sortProducts(): void {
    this.filteredProducts.sort((a, b) => {
      let aVal = (a as any)[this.sortColumn];
      let bVal = (b as any)[this.sortColumn];

      if (typeof aVal === 'string') {
        aVal = aVal.toLowerCase();
        bVal = bVal.toLowerCase();
      }

      const comparison = aVal < bVal ? -1 : aVal > bVal ? 1 : 0;
      return this.sortDirection === 'asc' ? comparison : -comparison;
    });
  }

  toggleSelect(id: number, event: any): void {
    if (event.target.checked) {
      this.selectedProducts.add(id);
    } else {
      this.selectedProducts.delete(id);
    }
    this.updateAllSelectedState();
  }

  toggleSelectAll(event: any): void {
    if (event.target.checked) {
      this.filteredProducts.forEach(p => this.selectedProducts.add(p.id!));
    } else {
      this.selectedProducts.clear();
    }
    this.updateAllSelectedState();
  }

  private updateAllSelectedState(): void {
    this.allSelected = this.filteredProducts.length > 0 && 
                       this.selectedProducts.size === this.filteredProducts.length;
  }

  addProduct(): void {
    this.router.navigate(['/products/add']);
  }

  editProduct(id: number): void {
    this.router.navigate(['/products/edit', id]);
  }

  deleteProduct(id: number): void {
    if (confirm('Are you sure you want to delete this product?')) {
      this.loading = true;
      this.productService.deleteProduct(id).pipe(takeUntil(this.destroy$)).subscribe({
        next: () => {
          this.successMessage = 'Product deleted successfully!';
          this.loading = false;
          setTimeout(() => this.successMessage = '', 3000);
        },
        error: () => {
          this.errorMessage = 'Failed to delete product';
          this.loading = false;
        }
      });
    }
  }

  deleteBulk(): void {
    const count = this.selectedProducts.size;
    if (confirm(`Delete ${count} selected product(s)?`)) {
      this.loading = true;
      const ids = Array.from(this.selectedProducts);
      this.productService.deleteMultiple(ids).pipe(takeUntil(this.destroy$)).subscribe({
        next: () => {
          this.successMessage = `${count} product(s) deleted successfully!`;
          this.loading = false;
          this.selectedProducts.clear();
          setTimeout(() => this.successMessage = '', 3000);
        },
        error: () => {
          this.errorMessage = 'Failed to delete products';
          this.loading = false;
        }
      });
    }
  }

  clearError(): void {
    this.errorMessage = '';
    this.productService.clearError();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
