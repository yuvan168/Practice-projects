import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

// Components
import { ProductListComponent } from './components/user-list/user-list.component';
import { UserListComponent } from './components/user-list/user-list-management.component';
import { ProductFormComponent } from './components/user-form/user-form.component';
import { UserAddComponent } from './components/user-form/user-add.component';
import { UserEditComponent } from './components/user-form/user-edit.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { ProductDetailComponent } from './pages/product-detail/product-detail.component';
import { LoginComponent } from './pages/login/login.component';
import { RegisterComponent } from './pages/register/register.component';
import { ReportsComponent } from './pages/reports/reports.component';

// Services
import { ProductService } from './services/user.service';

@NgModule({
  declarations: [
    AppComponent,
    ProductListComponent,
    UserListComponent,
    ProductFormComponent,
    UserAddComponent,
    UserEditComponent,
    NavbarComponent,
    DashboardComponent,
    ProductDetailComponent,
    LoginComponent,
    RegisterComponent,
    ReportsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [
    ProductService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
