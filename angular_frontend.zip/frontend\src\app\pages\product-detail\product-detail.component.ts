import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../../services/user.service';
import { Product } from '../../models/user.model';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-product-detail',
  template: `
    <div class="product-detail-container">
      <button class="btn-back" (click)="goBack()">← Back</button>

      <div *ngIf="!loading && product" class="product-detail">
        <!-- Product Images -->
        <div class="product-images">
          <div class="main-image">
            <img [src]="product.imageUrl || 'assets/placeholder.png'" [alt]="product.productName">
          </div>
          <div *ngIf="product.discount" class="discount-badge">
            -{{ product.discount }}%
          </div>
        </div>

        <!-- Product Info -->
        <div class="product-info">
          <h1>{{ product.productName }}</h1>

          <div class="product-meta">
            <div class="meta-item">
              <span class="label">Product Code:</span>
              <span>{{ product.productCode }}</span>
            </div>
            <div class="meta-item">
              <span class="label">SKU:</span>
              <span>{{ product.sku }}</span>
            </div>
            <div class="meta-item">
              <span class="label">Status:</span>
              <span [class]="'status-' + (product.status || 'active')">
                {{ product.status || 'Active' }}
              </span>
            </div>
          </div>

          <div class="description">
            <h3>Description</h3>
            <p>{{ product.description || 'No description available' }}</p>
          </div>

          <!-- Pricing -->
          <div class="pricing-section">
            <div class="price-group">
              <span *ngIf="product.discount" class="original-price">₹{{ product.price | number:'1.2-2' }}</span>
              <span class="final-price">₹{{ product.price * (1 - (product.discount || 0) / 100) | number:'1.2-2' }}</span>
            </div>
          </div>

          <!-- Stock Info -->
          <div class="stock-section">
            <span [class]="product.inStock ? 'in-stock' : 'out-of-stock'">
              {{ product.inStock ? '✓ In Stock' : '✗ Out of Stock' }}
            </span>
            <p class="quantity-info">{{ product.quantity }} units available</p>
          </div>

          <!-- Action Buttons -->
          <div class="action-buttons">
            <button class="btn btn-primary" [disabled]="!product.inStock">
              Add to Cart
            </button>
            <button class="btn btn-secondary" [routerLink]="['/products/edit', product.id]">
              Edit Product
            </button>
            <button class="btn btn-danger" (click)="deleteProduct()">
              Delete Product
            </button>
          </div>
        </div>
      </div>

      <!-- Loading State -->
      <div *ngIf="loading" class="loading-container">
        <div class="spinner"></div>
        <p>Loading product details...</p>
      </div>
    </div>
  `,
  styles: [`
    .product-detail-container {
      padding: 2rem;
      max-width: 1200px;
      margin: 0 auto;
    }

    .btn-back {
      background: none;
      border: none;
      color: #3498db;
      font-size: 1rem;
      cursor: pointer;
      margin-bottom: 1.5rem;
      padding: 0;
      font-weight: 600;
    }

    .btn-back:hover {
      color: #2980b9;
    }

    .product-detail {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 2rem;
      background: white;
      padding: 2rem;
      border-radius: 12px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      margin-bottom: 2rem;
    }

    .product-images {
      position: relative;
    }

    .main-image {
      width: 100%;
      aspect-ratio: 1;
      background-color: #ecf0f1;
      border-radius: 8px;
      overflow: hidden;
    }

    .main-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .discount-badge {
      position: absolute;
      top: 1rem;
      right: 1rem;
      background-color: #e74c3c;
      color: white;
      padding: 0.5rem 1rem;
      border-radius: 6px;
      font-weight: 700;
      font-size: 1.1rem;
    }

    .product-info h1 {
      color: #2c3e50;
      margin: 0 0 1rem;
      font-size: 2rem;
    }

    .rating-section {
      margin-bottom: 1.5rem;
      font-size: 1.1rem;
      color: #f39c12;
    }

    .no-rating {
      color: #7f8c8d;
    }

    .product-meta {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 1rem;
      margin-bottom: 1.5rem;
      padding-bottom: 1.5rem;
      border-bottom: 1px solid #ecf0f1;
    }

    .meta-item {
      display: flex;
      flex-direction: column;
      gap: 0.25rem;
    }

    .meta-item .label {
      color: #7f8c8d;
      font-size: 0.9rem;
      font-weight: 600;
    }

    .status-active {
      background-color: #d4edda;
      color: #155724;
      padding: 0.25rem 0.75rem;
      border-radius: 4px;
      font-size: 0.9rem;
    }

    .status-discontinued {
      background-color: #f8d7da;
      color: #721c24;
      padding: 0.25rem 0.75rem;
      border-radius: 4px;
      font-size: 0.9rem;
    }

    .description {
      margin-bottom: 1.5rem;
    }

    .description h3 {
      color: #2c3e50;
      margin: 0 0 0.75rem;
    }

    .description p {
      color: #555;
      line-height: 1.6;
      margin: 0;
    }

    .pricing-section {
      margin-bottom: 1.5rem;
      padding: 1.5rem;
      background-color: #ecf0f1;
      border-radius: 8px;
    }

    .price-group {
      display: flex;
      align-items: baseline;
      gap: 1rem;
    }

    .original-price {
      color: #7f8c8d;
      text-decoration: line-through;
      font-size: 1.1rem;
    }

    .final-price {
      font-size: 2rem;
      font-weight: 700;
      color: #27ae60;
    }

    .stock-section {
      margin-bottom: 1.5rem;
    }

    .in-stock {
      color: #27ae60;
      font-weight: 600;
      font-size: 1.1rem;
    }

    .out-of-stock {
      color: #e74c3c;
      font-weight: 600;
      font-size: 1.1rem;
    }

    .quantity-info {
      color: #7f8c8d;
      margin: 0.5rem 0 0;
    }

    .action-buttons {
      display: flex;
      gap: 1rem;
      flex-wrap: wrap;
    }

    .btn {
      padding: 0.75rem 1.5rem;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-weight: 600;
      transition: all 0.3s ease;
      flex: 1;
      min-width: 150px;
    }

    .btn-primary {
      background-color: #3498db;
      color: white;
    }

    .btn-primary:hover:not(:disabled) {
      background-color: #2980b9;
    }

    .btn-primary:disabled {
      background-color: #bdc3c7;
      cursor: not-allowed;
    }

    .btn-secondary {
      background-color: #95a5a6;
      color: white;
    }

    .btn-secondary:hover {
      background-color: #7f8c8d;
    }

    .btn-danger {
      background-color: #e74c3c;
      color: white;
    }

    .btn-danger:hover {
      background-color: #c0392b;
    }

    .reviews-section {
      background: white;
      padding: 2rem;
      border-radius: 12px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }

    .reviews-section h2 {
      color: #2c3e50;
      margin-top: 0;
    }

    .add-review-form {
      background-color: #f8f9fa;
      padding: 1.5rem;
      border-radius: 8px;
      margin-bottom: 2rem;
    }

    .add-review-form h3 {
      color: #2c3e50;
      margin-top: 0;
    }

    .form-group {
      margin-bottom: 1rem;
    }

    .form-group label {
      display: block;
      margin-bottom: 0.5rem;
      font-weight: 600;
      color: #2c3e50;
    }

    .form-control {
      width: 100%;
      padding: 0.75rem;
      border: 1px solid #bdc3c7;
      border-radius: 6px;
      font-size: 1rem;
      font-family: inherit;
    }

    .form-control:focus {
      outline: none;
      border-color: #3498db;
      box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.1);
    }

    .reviews-list {
      margin-top: 1.5rem;
    }

    .no-reviews {
      text-align: center;
      padding: 2rem;
      color: #7f8c8d;
    }

    .review-item {
      padding: 1.5rem;
      border: 1px solid #ecf0f1;
      border-radius: 8px;
      margin-bottom: 1rem;
    }

    .review-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 1rem;
    }

    .reviewer-info h4 {
      margin: 0 0 0.25rem;
      color: #2c3e50;
    }

    .rating-stars {
      color: #f39c12;
      font-weight: 600;
    }

    .verified-badge {
      background-color: #d4edda;
      color: #155724;
      padding: 0.25rem 0.75rem;
      border-radius: 4px;
      font-size: 0.85rem;
      margin-left: 0.5rem;
    }

    .review-date {
      color: #7f8c8d;
      font-size: 0.9rem;
    }

    .review-text {
      color: #555;
      line-height: 1.6;
      margin: 0 0 1rem;
    }

    .review-footer {
      display: flex;
      gap: 1rem;
    }

    .btn-helpful, .btn-delete {
      background: none;
      border: none;
      color: #3498db;
      cursor: pointer;
      font-weight: 600;
      transition: color 0.3s ease;
    }

    .btn-helpful:hover {
      color: #2980b9;
    }

    .btn-delete:hover {
      color: #e74c3c;
    }

    .loading-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 400px;
      gap: 1rem;
    }

    .spinner {
      border: 4px solid #ecf0f1;
      border-top: 4px solid #3498db;
      border-radius: 50%;
      width: 40px;
      height: 40px;
      animation: spin 1s linear infinite;
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    @media (max-width: 768px) {
      .product-detail {
        grid-template-columns: 1fr;
      }

      .product-meta {
        grid-template-columns: 1fr;
      }

      .action-buttons {
        flex-direction: column;
      }

      .btn {
        min-width: auto;
      }
    }
  `]
})
export class ProductDetailComponent implements OnInit, OnDestroy {
  product: Product | null = null;
  loading = true;

  private destroy$ = new Subject<void>();

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private productService: ProductService
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id && id !== 'NaN' && !isNaN(Number(id))) {
      this.loadProduct(parseInt(id));
    } else {
      this.router.navigate(['/dashboard']);
    }
  }

  loadProduct(id: number): void {
    this.productService.getProductById(id).pipe(takeUntil(this.destroy$)).subscribe({
      next: (product) => {
        this.product = product;
      }
    });
  }

  deleteProduct(): void {
    if (confirm('Delete this product?') && this.product) {
      this.productService.deleteProduct(this.product.id!).pipe(takeUntil(this.destroy$)).subscribe({
        next: () => {
          this.router.navigate(['/products']);
        }
      });
    }
  }

  goBack(): void {
    this.router.navigate(['/products']);
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
