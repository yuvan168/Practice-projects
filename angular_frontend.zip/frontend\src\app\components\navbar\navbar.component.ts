import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { AuthService } from '../../services/auth.service';
import { DarkModeService } from '../../services/dark-mode.service';

@Component({
  selector: 'app-navbar',
  template: `
    <nav class="navbar">
      <div class="navbar-container">
        <!-- Logo & Brand -->
        <div class="navbar-brand">
          <a [routerLink]="['/dashboard']" class="logo">
            📦 Product Manager
          </a>
        </div>

        <!-- Navigation Links (Desktop) -->
        <div class="navbar-menu" [class.active]="menuOpen">
          <div class="navbar-links">
            <a [routerLink]="['/dashboard']" routerLinkActive="active" class="nav-link">
              📊 Dashboard
            </a>
            <a [routerLink]="['/products']" routerLinkActive="active" class="nav-link">
              📦 Products
            </a>
            <a [routerLink]="['/users']" routerLinkActive="active" class="nav-link">
              👥 Users
            </a>
            <a [routerLink]="['/reports']" routerLinkActive="active" class="nav-link">
              📈 Reports
            </a>
          </div>

          <!-- User Menu -->
          <div class="user-menu">
            <div class="user-info" (click)="toggleUserMenu()">
              <div class="user-avatar">{{ userInitials }}</div>
              <div class="user-details">
                <div class="user-name">{{ currentUser?.firstName }} {{ currentUser?.lastName }}</div>
                <div class="user-role">Administrator</div>
              </div>
              <span class="dropdown-icon" [class.open]="userMenuOpen">▼</span>
            </div>

            <!-- User Dropdown Menu -->
            <div class="user-dropdown" [class.show]="userMenuOpen">
              <a [routerLink]="['/profile']" class="dropdown-item" (click)="closeUserMenu()">
                👤 My Profile
              </a>
              <a [routerLink]="['/settings']" class="dropdown-item" (click)="closeUserMenu()">
                ⚙️ Settings
              </a>
              <button class="dropdown-item" (click)="toggleTheme(); closeUserMenu()" type="button" style="width: 100%; text-align: left; border: none; background: none; cursor: pointer; padding: 0.75rem 1rem;">
                {{ isDarkMode ? '☀️' : '🌙' }} {{ isDarkMode ? 'Light Mode' : 'Dark Mode' }}
              </button>
              <div class="dropdown-divider"></div>
              <button class="dropdown-item logout-btn" (click)="logout()">
                🚪 Logout
              </button>
            </div>
          </div>
        </div>

        <!-- Mobile Menu Toggle -->
        <button class="mobile-toggle" (click)="toggleMenu()" [class.active]="menuOpen">
          <span></span>
          <span></span>
          <span></span>
        </button>
      </div>
    </nav>
  `,
  styles: [`
    .navbar {
      background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
      position: sticky;
      top: 0;
      z-index: 1000;
    }

    .navbar-container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 1.5rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      height: 70px;
    }

    .navbar-brand {
      display: flex;
      align-items: center;
    }

    .logo {
      color: white;
      font-size: 1.5rem;
      font-weight: 700;
      text-decoration: none;
      letter-spacing: 0.5px;
      transition: color 0.3s ease;
    }

    .logo:hover {
      color: #3498db;
    }

    .navbar-menu {
      display: flex;
      align-items: center;
      gap: 3rem;
    }

    .navbar-links {
      display: flex;
      gap: 2rem;
    }

    .nav-link {
      color: #ecf0f1;
      text-decoration: none;
      font-weight: 500;
      padding: 0.5rem 0.75rem;
      border-radius: 4px;
      transition: all 0.3s ease;
      position: relative;
    }

    .nav-link::after {
      content: '';
      position: absolute;
      bottom: -2px;
      left: 0;
      width: 0;
      height: 2px;
      background-color: #3498db;
      transition: width 0.3s ease;
    }

    .nav-link:hover {
      color: #3498db;
    }

    .nav-link:hover::after {
      width: 100%;
    }

    .nav-link.active {
      color: #3498db;
      background-color: rgba(52, 152, 219, 0.1);
    }

    .nav-link.active::after {
      width: 100%;
    }

    .user-menu {
      position: relative;
    }

    .user-info {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      padding: 0.5rem 1rem;
      background-color: rgba(255, 255, 255, 0.1);
      border-radius: 8px;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .user-info:hover {
      background-color: rgba(255, 255, 255, 0.15);
    }

    .user-avatar {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-weight: 700;
      font-size: 1rem;
    }

    .user-details {
      display: flex;
      flex-direction: column;
      gap: 0.25rem;
    }

    .user-name {
      color: white;
      font-weight: 600;
      font-size: 0.95rem;
    }

    .user-role {
      color: #bdc3c7;
      font-size: 0.8rem;
    }

    .dropdown-icon {
      color: #bdc3c7;
      font-size: 0.7rem;
      transition: transform 0.3s ease;
      margin-left: 0.5rem;
    }

    .dropdown-icon.open {
      transform: rotate(180deg);
    }

    .user-dropdown {
      position: absolute;
      top: 100%;
      right: 0;
      min-width: 200px;
      background: white;
      border-radius: 8px;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
      margin-top: 0.5rem;
      opacity: 0;
      visibility: hidden;
      transform: translateY(-10px);
      transition: all 0.3s ease;
    }

    .user-dropdown.show {
      opacity: 1;
      visibility: visible;
      transform: translateY(0);
    }

    .dropdown-item {
      display: block;
      width: 100%;
      padding: 0.75rem 1.25rem;
      color: #2c3e50;
      text-decoration: none;
      border: none;
      background: none;
      cursor: pointer;
      text-align: left;
      font-size: 0.95rem;
      transition: all 0.3s ease;
    }

    .dropdown-item:first-child {
      border-radius: 8px 8px 0 0;
    }

    .dropdown-item:hover {
      background-color: #ecf0f1;
      padding-left: 1.5rem;
    }

    .logout-btn {
      color: #e74c3c;
      font-weight: 600;
    }

    .logout-btn:last-child {
      border-radius: 0 0 8px 8px;
    }

    .dropdown-divider {
      height: 1px;
      background-color: #ecf0f1;
      margin: 0.5rem 0;
    }

    .mobile-toggle {
      display: none;
      flex-direction: column;
      gap: 5px;
      background: none;
      border: none;
      cursor: pointer;
    }

    .mobile-toggle span {
      width: 25px;
      height: 3px;
      background-color: white;
      border-radius: 2px;
      transition: all 0.3s ease;
    }

    .mobile-toggle.active span:nth-child(1) {
      transform: rotate(45deg) translate(8px, 8px);
    }

    .mobile-toggle.active span:nth-child(2) {
      opacity: 0;
    }

    .mobile-toggle.active span:nth-child(3) {
      transform: rotate(-45deg) translate(7px, -7px);
    }

    @media (max-width: 768px) {
      .navbar-container {
        height: auto;
        padding: 1rem 1.5rem;
      }

      .mobile-toggle {
        display: flex;
      }

      .navbar-menu {
        display: none;
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        flex-direction: column;
        gap: 0;
        background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
        padding: 1.5rem;
        border-top: 1px solid rgba(255, 255, 255, 0.1);
      }

      .navbar-menu.active {
        display: flex;
      }

      .navbar-links {
        flex-direction: column;
        gap: 0.5rem;
        width: 100%;
        margin-bottom: 1.5rem;
        padding-bottom: 1.5rem;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      }

      .nav-link {
        padding: 0.75rem 0;
      }

      .user-info {
        width: 100%;
      }

      .user-dropdown {
        position: static;
        opacity: 1;
        visibility: visible;
        transform: none;
        background: rgba(255, 255, 255, 0.1);
        margin-top: 1rem;
        box-shadow: none;
      }

      .user-dropdown.show {
        display: block;
      }

      .dropdown-item {
        color: #ecf0f1;
      }

      .dropdown-item:hover {
        background-color: rgba(255, 255, 255, 0.15);
      }
    }
  `]
})
export class NavbarComponent implements OnInit, OnDestroy {
  currentUser: any = null;
  userInitials = '';
  menuOpen = false;
  userMenuOpen = false;
  isDarkMode = false;

  private destroy$ = new Subject<void>();

  constructor(
    private authService: AuthService,
    private router: Router,
    private darkModeService: DarkModeService
  ) {
    // Initialize dark mode from service
    this.isDarkMode = this.darkModeService.isDarkMode();
  }

  ngOnInit(): void {
    this.authService.getCurrentUser$()
      .pipe(takeUntil(this.destroy$))
      .subscribe((user: any) => {
        if (user) {
          this.currentUser = user;
          this.userInitials = (user.firstName?.[0] || 'U') + (user.lastName?.[0] || '');
        }
      });

    // Subscribe to dark mode changes
    this.darkModeService.darkMode$.pipe(takeUntil(this.destroy$)).subscribe(isDark => {
      this.isDarkMode = isDark;
    });
  }

  toggleMenu(): void {
    this.menuOpen = !this.menuOpen;
  }

  toggleUserMenu(): void {
    this.userMenuOpen = !this.userMenuOpen;
  }

  closeUserMenu(): void {
    this.userMenuOpen = false;
    this.menuOpen = false;
  }

  toggleTheme(): void {
    this.darkModeService.toggleDarkMode();
  }

  logout(): void {
    if (confirm('Are you sure you want to logout?')) {
      this.authService.logout();
      this.router.navigate(['/login']);
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
