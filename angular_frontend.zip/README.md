# Inventory Management System

## Project Structure

```
angular_frontend/
├── backend/                 # Spring Boot Backend
│   ├── src/main/java/
│   │   └── com/example/fullstack/
│   │       ├── entity/      # JPA Entities
│   │       ├── repository/  # Spring Data Repositories
│   │       ├── controller/  # REST Controllers
│   │       └── FullStackAppApplication.java
│   ├── src/main/resources/
│   │   └── application.properties
│   └── pom.xml
└── frontend/                # Angular Frontend
    ├── src/
    │   ├── app/
    │   │   ├── components/  # Angular Components
    │   │   ├── services/    # Angular Services
    │   │   ├── models/      # TypeScript Models
    │   │   └── app.module.ts
    │   └── index.html
    ├── package.json
    └── tsconfig.json
```

## Features

- **Product Inventory Management** - Create, Read, Update, Delete products
- **RESTful API** with Spring Boot
- **Angular Frontend** with Routing
- **CORS Enabled** for frontend-backend communication
- **H2 In-memory Database** for development
- **No Spring Security** - Simple backend setup
- **Product Tracking** - Monitor product quantity, price, and SKU

## Prerequisites

- Java 17+
- Node.js 18+
- npm or yarn

## Backend Setup

### 1. Navigate to backend directory
```bash
cd backend
```

### 2. Build the project
```bash
mvn clean install
```

### 3. Run the application
```bash
mvn spring-boot:run
```

The backend will start on `http://localhost:8080`

### 4. Access H2 Console (Optional)
```
http://localhost:8080/h2-console
```

## Frontend Setup

### 1. Navigate to frontend directory
```bash
cd frontend
```

### 2. Install dependencies
```bash
npm install
```

### 3. Run the development server
```bash
npm start
```

The frontend will be available on `http://localhost:4200`

## API Endpoints

- `GET /api/products` - Get all products
- `GET /api/products/{id}` - Get product by ID
- `POST /api/products` - Create new product
- `PUT /api/products/{id}` - Update product
- `DELETE /api/products/{id}` - Delete product

## Example Request

### Create Product
```bash
curl -X POST http://localhost:8080/api/products \
  -H "Content-Type: application/json" \
  -d '{
    "productName": "Laptop",
    "category": "Electronics",
    "sku": "SKU-001",
    "price": 999.99,
    "quantity": 10,
    "description": "High performance laptop"
  }'
```

## Running Both Services

**Terminal 1 - Backend:**
```bash
cd backend
mvn spring-boot:run
```

**Terminal 2 - Frontend:**
```bash
cd frontend
npm start
```

Then open `http://localhost:4200` in your browser.

## Product Fields

- **Product Name** - Name of the product
- **Category** - Product category (e.g., Electronics, Furniture, etc.)
- **SKU** - Stock Keeping Unit for inventory tracking
- **Price** - Unit price of the product
- **Quantity** - Available stock quantity
- **Description** - Optional product description

## Technology Stack

### Backend
- Spring Boot 3.2.0
- Spring Data JPA
- H2 Database
- Lombok
- Maven

### Frontend
- Angular 17
- TypeScript
- RxJS
- Angular Routing
- HttpClientModule

## Notes

- This is a basic inventory management system without Spring Security
- Database is in-memory (H2), data will be lost on server restart
- CORS is configured to allow requests from `http://localhost:4200`
- Perfect for learning full-stack development
