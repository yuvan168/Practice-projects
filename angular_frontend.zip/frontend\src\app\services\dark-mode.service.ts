import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DarkModeService {
  private readonly STORAGE_KEY = 'darkMode';
  private darkModeSubject = new BehaviorSubject<boolean>(this.loadDarkMode());
  public darkMode$ = this.darkModeSubject.asObservable();

  constructor() {
    // Apply dark mode on service initialization
    this.applyDarkMode(this.darkModeSubject.value);
  }

  private loadDarkMode(): boolean {
    // Try to get from localStorage, default to false
    const stored = localStorage.getItem(this.STORAGE_KEY);
    return stored === 'true';
  }

  isDarkMode(): boolean {
    return this.darkModeSubject.value;
  }

  toggleDarkMode(): void {
    const newValue = !this.darkModeSubject.value;
    this.setDarkMode(newValue);
  }

  setDarkMode(isDark: boolean): void {
    this.darkModeSubject.next(isDark);
    localStorage.setItem(this.STORAGE_KEY, isDark.toString());
    this.applyDarkMode(isDark);
  }

  private applyDarkMode(isDark: boolean): void {
    if (isDark) {
      document.body.classList.add('dark-mode');
    } else {
      document.body.classList.remove('dark-mode');
    }
  }
}
