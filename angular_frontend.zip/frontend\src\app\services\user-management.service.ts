import { Injectable } from '@angular/core';
import { User } from '../models/user.model';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserManagementService {
  private readonly STORAGE_KEY = 'users';
  private usersSubject = new BehaviorSubject<User[]>([]);
  public users$ = this.usersSubject.asObservable();

  // Default users
  private defaultUsers: User[] = [
    {
      id: 1,
      firstName: 'Admin',
      lastName: 'User',
      email: 'admin@example.com',
      password: 'password123',
      type: 'ADMIN'
    },
    {
      id: 2,
      firstName: 'John',
      lastName: 'Manager',
      email: 'john@example.com',
      password: 'password123',
      type: 'MANAGER'
    },
    {
      id: 3,
      firstName: 'Jane',
      lastName: 'Doe',
      email: 'jane@example.com',
      password: 'password123',
      type: 'USER'
    }
  ];

  constructor() {
    this.loadUsers();
  }

  private loadUsers(): void {
    const stored = localStorage.getItem(this.STORAGE_KEY);
    if (stored) {
      try {
        const users = JSON.parse(stored);
        // Migrate users to ensure they have password field
        const migratedUsers = users.map((user: User) => {
          // If user doesn't have password, add default password
          if (!user.password) {
            return { ...user, password: 'password123' };
          }
          return user;
        });
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(migratedUsers));
        this.usersSubject.next(migratedUsers);
      } catch {
        this.initializeDefaultUsers();
      }
    } else {
      this.initializeDefaultUsers();
    }
  }

  private initializeDefaultUsers(): void {
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this.defaultUsers));
    this.usersSubject.next(this.defaultUsers);
  }

  getAllUsers(): Observable<User[]> {
    return this.users$;
  }

  getAllUsersSync(): User[] {
    return this.usersSubject.value;
  }

  getUserById(id: number): User | undefined {
    return this.usersSubject.value.find(u => u.id === id);
  }

  createUser(user: User): User {
    const users = this.usersSubject.value;
    const newUser: User = {
      ...user,
      id: Math.max(...users.map(u => u.id || 0), 0) + 1
    };
    const updatedUsers = [...users, newUser];
    this.usersSubject.next(updatedUsers);
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(updatedUsers));
    return newUser;
  }

  updateUser(id: number, user: User): User | null {
    const users = this.usersSubject.value;
    const index = users.findIndex(u => u.id === id);
    if (index !== -1) {
      const updatedUser = { ...user, id };
      users[index] = updatedUser;
      this.usersSubject.next([...users]);
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(users));
      return updatedUser;
    }
    return null;
  }

  deleteUser(id: number): boolean {
    const users = this.usersSubject.value;
    const filtered = users.filter(u => u.id !== id);
    if (filtered.length < users.length) {
      this.usersSubject.next(filtered);
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(filtered));
      return true;
    }
    return false;
  }
}
