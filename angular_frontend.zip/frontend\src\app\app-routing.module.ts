import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

// Components
import { ProductListComponent } from './components/user-list/user-list.component';
import { UserListComponent } from './components/user-list/user-list-management.component';
import { ProductFormComponent } from './components/user-form/user-form.component';
import { UserAddComponent } from './components/user-form/user-add.component';
import { UserEditComponent } from './components/user-form/user-edit.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { ProductDetailComponent } from './pages/product-detail/product-detail.component';
import { LoginComponent } from './pages/login/login.component';
import { RegisterComponent } from './pages/register/register.component';
import { ReportsComponent } from './pages/reports/reports.component';

const routes: Routes = [
  // Public Routes
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },

  // Routes (No Auth Required)
  { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  
  {
    path: 'dashboard',
    component: DashboardComponent
  },

  {
    path: 'products/add',
    component: ProductFormComponent
  },

  {
    path: 'users/add',
    component: UserAddComponent
  },

  {
    path: 'users/edit/:id',
    component: UserEditComponent
  },

  {
    path: 'users',
    component: UserListComponent
  },

  {
    path: 'products/edit/:id',
    component: ProductFormComponent
  },

  {
    path: 'products',
    component: ProductListComponent
  },

  {
    path: 'products/:id',
    component: ProductDetailComponent
  },

  {
    path: 'reports',
    component: ReportsComponent
  },

  // Wildcard Route (must be last)
  { path: '**', redirectTo: '/dashboard' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    scrollPositionRestoration: 'top'
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
