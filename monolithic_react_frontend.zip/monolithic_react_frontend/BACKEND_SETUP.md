# Spring Boot Backend Setup & Login Integration

## 📋 Overview

This guide explains how to set up your Spring Boot backend to work with the React frontend. The backend handles authentication (JWT), user management, products, and sales data.

---

## 🚀 Quick Setup

### Prerequisites
- Java 17+ installed
- MySQL server running
- Maven installed
- Spring Boot 3.3.0

### 1. Database Setup

Create MySQL database:
```sql
CREATE DATABASE inventory_db;
USE inventory_db;
```

The backend will auto-create tables via JPA/Hibernate when it starts.

### 2. Configure Application Properties

Edit `application.properties`:
```properties
# MySQL Database Configuration
spring.datasource.url=jdbc:mysql://localhost:3306/inventory_db?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true
spring.datasource.username=root
spring.datasource.password=yuvan
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver

# JPA/Hibernate Configuration
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQL8Dialect

# Server Configuration
server.port=8088

# JWT Configuration
app.jwtSecret=MySuperSecretKeyForJWTTokenGenerationInSpringBootApplication12345
app.jwtExpirationMs=86400000

# Logging
logging.level.com.example=DEBUG
logging.level.org.springframework.security=DEBUG
logging.level.org.springframework.web.cors=DEBUG
```

### 3. Build & Run

```bash
# Build
mvn clean install

# Run
mvn spring-boot:run

# Or run JAR directly
java -jar target/inventory-backend.jar
```

The backend will start on `http://localhost:8088`

---

## 🔐 Login Process

### Frontend (React)

**File**: `src/Pages/Auth/Login.jsx`

1. User enters email & password
2. Form is submitted via POST to backend
3. Backend validates credentials and returns JWT token
4. Token is stored in React Context & localStorage
5. Redirects to dashboard

### Backend (Spring Boot)

**File**: `controller/AuthController.java`

#### Login Endpoint

```
POST /api/auth/login
Content-Type: application/json

{
  "email": "test@test.com",
  "password": "password123"
}
```

**Request Body Structure**:
```json
{
  "email": "string (required)",
  "password": "string (required)"
}
```

---

## 📤 Login JSON Examples

### Request 1: User Login

```bash
curl -X POST http://localhost:8088/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@test.com",
    "password": "password123"
  }'
```

**Request JSON**:
```json
{
  "email": "test@test.com",
  "password": "password123"
}
```

**Response (Success - 200)**:
```json
{
  "token": "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJ0ZXN0QHRlc3QuY29tIiwiaWF0IjoxNzAyNjM5ODc2LCJleHAiOjE3MDI3MjYyNzZ9.abc123xyz...",
  "email": "test@test.com",
  "firstName": "Test",
  "lastName": "User"
}
```

**Response (Failure - 401)**:
```json
{
  "message": "Invalid credentials"
}
```

---

### Request 2: Admin Login

```bash
curl -X POST http://localhost:8088/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@test.com",
    "password": "admin123"
  }'
```

**Request JSON**:
```json
{
  "email": "admin@test.com",
  "password": "admin123"
}
```

**Response (Success - 200)**:
```json
{
  "token": "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhZG1pbkB0ZXN0LmNvbSIsImlhdCI6MTcwMjYzOTg3NiwiZXhwIjoxNzAyNzI2Mjc2fQ.xyz789abc...",
  "email": "admin@test.com",
  "firstName": "Admin",
  "lastName": "User"
}
```

---

## 📝 User Registration

### Register Endpoint

```
POST /api/auth/register
Content-Type: application/json

{
  "email": "newuser@example.com",
  "password": "SecurePassword123",
  "firstName": "John",
  "lastName": "Doe"
}
```

**Example**:
```bash
curl -X POST http://localhost:8088/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "newuser@example.com",
    "password": "SecurePassword123",
    "firstName": "John",
    "lastName": "Doe"
  }'
```

**Request JSON**:
```json
{
  "email": "newuser@example.com",
  "password": "SecurePassword123",
  "firstName": "John",
  "lastName": "Doe"
}
```

**Response (Success - 200)**:
```json
{
  "message": "User registered successfully"
}
```

**Response (Failure - 400)**:
```json
{
  "message": "Email already exists"
}
```

---

## 🔑 JWT Token Usage

After login, the token is used in all subsequent requests:

```bash
curl -X GET http://localhost:8088/api/products \
  -H "Authorization: Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJ0ZXN0QHRlc3QuY29tIiwiaWF0IjoxNzAyNjM5ODc2LCJleXAiOjE3MDI3MjYyNzZ9.abc123xyz..."
```

**Header Format**:
```
Authorization: Bearer {token}
```

The React frontend automatically adds this header via axios interceptor in `src/api/axios.js`.

---

## 📊 All API Endpoints

### Authentication
| Method | Endpoint | Auth | Purpose |
|--------|----------|------|---------|
| POST | `/api/auth/login` | ❌ | User login |
| POST | `/api/auth/register` | ❌ | User registration |
| GET | `/api/auth/profile` | ✅ | Get current user profile |
| PUT | `/api/auth/profile` | ✅ | Update profile |
| GET | `/api/auth/users` | ✅ | List all users |
| POST | `/api/auth/users` | ✅ | Create user |
| PUT | `/api/auth/users/{id}` | ✅ | Update user |
| DELETE | `/api/auth/users/{id}` | ✅ | Delete user |

### Products
| Method | Endpoint | Auth | Purpose |
|--------|----------|------|---------|
| GET | `/api/products` | ✅ | List all products |
| GET | `/api/products/{id}` | ✅ | Get product details |
| POST | `/api/products` | ✅ | Create product |
| PUT | `/api/products/{id}` | ✅ | Update product |
| DELETE | `/api/products/{id}` | ✅ | Delete product |

### Sales
| Method | Endpoint | Auth | Purpose |
|--------|----------|------|---------|
| GET | `/api/sales` | ✅ | List all sales |
| POST | `/api/sales` | ✅ | Create sales entry |
| PUT | `/api/sales/{id}` | ✅ | Update sales |
| DELETE | `/api/sales/{id}` | ✅ | Delete sales |

---

## 🧪 Test Credentials

These users are created automatically after first login with new credentials:

```
User Login:
- Email: test@test.com
- Password: password123

Admin Login:
- Email: admin@test.com
- Password: admin123
```

Or register new users via the register endpoint.

---

## 📦 Create Initial Test Data

### Option 1: Using Frontend Registration

1. Start backend: `mvn spring-boot:run`
2. Start frontend: `npm run dev`
3. Go to Register page
4. Create test accounts

### Option 2: Direct Database Insert

```sql
INSERT INTO roles (name) VALUES ('ROLE_USER');
INSERT INTO roles (name) VALUES ('ROLE_ADMIN');

INSERT INTO users (email, password, first_name, last_name) VALUES 
('test@test.com', '$2a$10$YourBCryptHashHere', 'Test', 'User'),
('admin@test.com', '$2a$10$YourBCryptHashHere', 'Admin', 'User');

INSERT INTO user_roles (user_id, role_id) VALUES (1, 1), (2, 2);
```

**Generate BCrypt Password Hash**:

```java
// In any Spring Boot app context
BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
String hash = encoder.encode("password123");
System.out.println(hash); // Use this in SQL
```

Or use online BCrypt generator: https://bcrypt-generator.com/

Example hashes:
```
password123 → $2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcg7b3XeKeJklskkskeKeJklskks
admin123 → $2a$10$dXJ3SW6G7P50eS7DlH.O.e.aaOoMg3WD3jZjJ9JGXjZnJkljkljk
```

---

## 🔒 Security Configuration

### CORS Configuration

The backend allows requests from React frontend on `http://localhost:3000`:

```java
// In SecurityConfig.java
configuration.setAllowedOrigins(Arrays.asList("http://localhost:3000"));
configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"));
configuration.setAllowedHeaders(Arrays.asList("*"));
configuration.setAllowCredentials(true);
```

### JWT Token

- **Secret Key**: `MySuperSecretKeyForJWTTokenGenerationInSpringBootApplication12345`
- **Expiration**: 24 hours (86400000 ms)
- **Algorithm**: HS512

Change in `application.properties`:
```properties
app.jwtSecret=YourNewSecretKeyHere
app.jwtExpirationMs=86400000
```

### Public Endpoints

These don't require authentication:
- `POST /api/auth/login`
- `POST /api/auth/register`
- `GET /error`

All other endpoints require valid JWT token.

---

## 🐛 Debugging

### Check Backend Logs

Watch for these log messages:

**Successful Login**:
```
Login successful for user: test@test.com
JWT validated successfully for user: test@test.com
```

**Failed Login**:
```
JWT extraction error: ...
Authentication error: ...
ERROR in getAllUsers: ...
```

### Enable Debug Logging

Add to `application.properties`:
```properties
logging.level.com.example=DEBUG
logging.level.org.springframework.security=DEBUG
logging.level.org.springframework.web.cors=DEBUG
logging.level.org.springframework.web.filter=DEBUG
```

### Check Database Connection

```bash
# Test MySQL connection
mysql -h localhost -u root -p -e "USE inventory_db; SHOW TABLES;"
```

### Test Endpoints with Postman

1. Open Postman
2. Import collection or create requests manually
3. Test each endpoint
4. Copy token from login response
5. Add to Authorization header for protected endpoints

---

## 🔄 Frontend Integration

### How React Communicates with Backend

1. **Login Request**:
   ```javascript
   // Frontend sends login credentials
   POST /api/auth/login
   {
     "email": "test@test.com",
     "password": "password123"
   }
   ```

2. **Receive Token**:
   ```javascript
   // Backend returns JWT token
   {
     "token": "eyJhbGciOiJIUzUxMiJ9...",
     "email": "test@test.com",
     "firstName": "Test",
     "lastName": "User"
   }
   ```

3. **Store Token**:
   ```javascript
   // React stores in localStorage & context
   localStorage.setItem("token", response.token);
   AuthContext.login(response.token, userData);
   ```

4. **Use Token**:
   ```javascript
   // Axios interceptor adds token to all requests
   Authorization: Bearer {token}
   ```

### Axios Configuration

**File**: `src/api/axios.js`

```javascript
const api = axios.create({
  baseURL: "http://localhost:8088/api",
});

// Add JWT token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");
  if (token) {
    config.headers["Authorization"] = `Bearer ${token}`;
  }
  return config;
});

// Handle 401 errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem("token");
      window.location.href = "/login";
    }
    return Promise.reject(error);
  }
);
```

---

## 🚨 Common Issues & Solutions

### Issue 1: CORS Error
```
Access to XMLHttpRequest blocked by CORS policy
```

**Solution**:
- Ensure `@CrossOrigin(origins = "http://localhost:3000")` is on controllers
- Check SecurityConfig has CORS configuration
- Verify frontend URL is correct

### Issue 2: Invalid Token Error
```
JWT token is malformed/expired/unsupported
```

**Solution**:
- Token format: `Bearer {token}`
- Token expired: Re-login to get new token
- Secret key mismatch: Check `app.jwtSecret` in both frontend & backend

### Issue 3: User Not Found
```
User not found with email: test@test.com
```

**Solution**:
- Create user via register endpoint first
- Check database has user: `SELECT * FROM users WHERE email='test@test.com';`
- Verify password is BCrypt encoded

### Issue 4: Connection Refused
```
java.net.ConnectException: Connection refused: localhost:3306
```

**Solution**:
- Start MySQL: `mysql.server start` (macOS) or `net start MySQL` (Windows)
- Check MySQL is running: `mysql -u root -p`
- Verify credentials in `application.properties`

### Issue 5: Port 8088 Already in Use
```
Port 8088 is already in use
```

**Solution**:
- Find process: `lsof -i :8088` (macOS/Linux) or `netstat -ano | findstr :8088` (Windows)
- Kill process or change port in `application.properties`:
  ```properties
  server.port=8089
  ```

---

## 📝 Complete Login Flow Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    REACT FRONTEND                           │
│ ┌──────────────────────────────────────────────────────┐   │
│ │  Login Page (src/Pages/Auth/Login.jsx)               │   │
│ │  - Email input                                        │   │
│ │  - Password input                                     │   │
│ │  - Submit button                                      │   │
│ └──────────────────────────────────────────────────────┘   │
└──────────────┬───────────────────────────────────────────────┘
               │
               │ POST /api/auth/login
               │ { email, password }
               │
               ▼
┌─────────────────────────────────────────────────────────────┐
│                  SPRING BOOT BACKEND                        │
│ ┌──────────────────────────────────────────────────────┐   │
│ │  AuthController.login()                              │   │
│ │  1. Find user by email                               │   │
│ │  2. Check password with BCryptPasswordEncoder        │   │
│ │  3. Generate JWT token with JwtUtil                  │   │
│ │  4. Return token + user data                         │   │
│ └──────────────────────────────────────────────────────┘   │
└──────────────┬───────────────────────────────────────────────┘
               │
               │ Response: { token, email, firstName, lastName }
               │
               ▼
┌─────────────────────────────────────────────────────────────┐
│                    REACT FRONTEND                           │
│ ┌──────────────────────────────────────────────────────┐   │
│ │  Login.jsx handleSubmit()                            │   │
│ │  1. Store token in localStorage                      │   │
│ │  2. Save user in AuthContext                         │   │
│ │  3. Redirect to /dashboard                           │   │
│ └──────────────────────────────────────────────────────┘   │
│                                                              │
│ ┌──────────────────────────────────────────────────────┐   │
│ │  All Subsequent Requests                             │   │
│ │  - Axios interceptor adds: Authorization: Bearer X   │   │
│ │  - Protected routes check token exists               │   │
│ │  - If 401: Auto-logout & redirect to login           │   │
│ └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

---

## ✅ Verification Checklist

- [ ] MySQL database created: `inventory_db`
- [ ] Backend dependencies installed: `mvn clean install`
- [ ] Backend running on port 8088: `mvn spring-boot:run`
- [ ] Frontend running on port 3000: `npm run dev`
- [ ] Can access backend: `http://localhost:8088/api/auth/login`
- [ ] Can access frontend: `http://localhost:3000`
- [ ] User created (register or manual insert)
- [ ] Login successful with test credentials
- [ ] Token received in response
- [ ] Dashboard loads after login
- [ ] Can fetch products, users, sales
- [ ] Dark mode works
- [ ] Logout works

---

## 🎉 Next Steps

1. **Start Backend**:
   ```bash
   cd path/to/backend
   mvn spring-boot:run
   ```

2. **Start Frontend**:
   ```bash
   cd path/to/frontend
   npm run dev
   ```

3. **Create Test User** (Option A):
   - Go to Register page: http://localhost:3000/register
   - Create new account

4. **Login**:
   - Email: test@test.com
   - Password: password123

5. **Explore App**:
   - Dashboard
   - Products
   - Users
   - Reports
   - Settings

---

**Backend Ready!** 🚀
