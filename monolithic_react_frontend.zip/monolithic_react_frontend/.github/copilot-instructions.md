# Inventory Management System - React Frontend

## Project Overview
This is a modern React-based frontend for an Inventory Management System that connects to a Spring Boot backend. The application is built with Vite, Material-UI, React Router, Formik, and Recharts for data visualization.

## Technology Stack
- **Framework**: React 19.2 with Vite 7.2
- **UI Library**: Material-UI (MUI 5)
- **Styling**: Emotion CSS-in-JS
- **Routing**: React Router 6
- **Forms**: Formik + Yup validation
- **API**: Axios with JWT interceptors
- **Charts**: Recharts
- **Animations**: Framer Motion
- **Notifications**: React Toastify

## Project Structure

### Source Files
```
src/
├── api/axios.js                 # Axios instance with interceptors & JWT handling
├── components/
│   ├── Header.jsx               # Header navigation component
│   ├── Navbar.jsx               # Top navbar with user profile dropdown
│   ├── ProtectedRoute.jsx       # Route protection wrapper
│   └── Sidebar.jsx              # Side navigation menu
├── Context/
│   └── AuthContext.jsx          # Authentication context with login/logout
├── Pages/
│   ├── Auth/Login.jsx           # Login form page
│   ├── Auth/Register.jsx        # Registration form page
│   ├── Dashboard/Dashboard.jsx  # Main dashboard with stats & charts
│   ├── Product/ProductList.jsx  # Product listing & management
│   ├── Product/AddProduct.jsx   # Add product form
│   ├── Product/EditProduct.jsx  # Edit product form
│   ├── Users/UserList.jsx       # User management page
│   ├── Reports/Reports.jsx      # Analytics & reports page
│   └── Settings/Settings.jsx    # User settings & preferences
├── services/
│   ├── AuthService.js           # useAuth custom hook
│   └── ProductService.js        # Product API service methods
├── Routes/AppRoutes.jsx         # Route definitions
├── App.jsx                      # Main App with theme provider
├── main.jsx                     # Entry point
├── index.css                    # Global styles
└── App.css                      # App-specific styles
```

## Key Features

### Authentication
- JWT token-based authentication
- Secure password handling
- Protected routes with context-based access control
- User session management in localStorage
- Automatic token attachment to API requests

### Product Management
- Full CRUD operations for products
- Search and filter functionality
- Form validation with Formik & Yup
- Real-time product listing

### User Management (Admin)
- Create, read, update, delete users
- Role-based access control
- User information management

### Dashboard
- Real-time statistics (products, users, revenue, low stock)
- Interactive bar charts for sales trends
- Sales data CRUD operations
- Recent products & users overview

### Reports & Analytics
- Sales trend visualization (line charts)
- Stock distribution by manufacturer (pie charts)
- Detailed inventory report with totals
- Export-ready product information

### Settings
- User profile management
- Dark mode toggle with persistence
- Theme customization

## API Endpoints

### Authentication
- `POST /auth/login` - Login user
- `POST /auth/signup` - Register new user
- `GET /auth/profile` - Get current user profile
- `PUT /auth/profile` - Update user profile

### Products
- `GET /products` - List all products
- `GET /products/:id` - Get single product
- `POST /products` - Create new product
- `PUT /products/:id` - Update product
- `DELETE /products/:id` - Delete product

### Users
- `GET /auth/users` - List all users
- `POST /auth/users` - Create user
- `PUT /auth/users/:id` - Update user
- `DELETE /auth/users/:id` - Delete user

### Sales
- `GET /sales` - Get sales data
- `POST /sales` - Create sales record
- `PUT /sales/:id` - Update sales record
- `DELETE /sales/:id` - Delete sales record

### Other
- `GET /revenue/current` - Get current revenue
- `POST /revenue` - Save revenue data

## Development Instructions

### Setup & Installation
1. Install dependencies: `npm install`
2. Configure backend URL in `src/api/axios.js` if different from `http://localhost:8088`
3. Ensure Spring Boot backend is running before starting dev server

### Running Development Server
```bash
npm run dev
```
- Starts at http://localhost:3000
- Hot Module Replacement (HMR) enabled
- Auto-reload on file changes

### Building for Production
```bash
npm run build
```
- Creates optimized build in `dist/` folder
- Minified and tree-shaken code
- Code splitting enabled

### Code Style Guidelines
- Use React hooks (useState, useEffect, useContext, useCallback)
- Components should be functional components
- Prop names use camelCase
- CSS-in-JS with Material-UI sx prop for styling
- Use meaningful variable/function names
- Add comments for complex logic

### Adding New Pages
1. Create component in `src/Pages/{Category}/ComponentName.jsx`
2. Add route in `src/Routes/AppRoutes.jsx`
3. Wrap with `<ProtectedRoute>` if authentication required
4. Import and use Material-UI components for consistency

### Adding New API Services
1. Create methods in `src/services/ServiceName.js`
2. Use axios instance from `src/api/axios.js`
3. Handle errors with try-catch blocks
4. Show toast notifications for user feedback

### Form Implementation
1. Use Formik for form state management
2. Define Yup schema for validation
3. Display field-level error messages
4. Disable submit button until form is valid

### Error Handling
- Network errors: Check backend connection in browser console
- 401 errors: User auto-redirected to login
- 403 errors: Access denied notification shown
- Form errors: Field-level validation messages displayed

## Testing Credentials

- **User Account**: test@test.com / password123
- **Admin Account**: admin@test.com / admin123

## Common Tasks

### Fix Build Errors
```bash
rm -rf node_modules package-lock.json
npm install
npm run build
```

### Change Backend URL
Edit `src/api/axios.js` and update the baseURL:
```javascript
const api = axios.create({
  baseURL: "http://your-backend:port/api",
  ...
});
```

### Add Dark Mode Support
All components use Material-UI theme which automatically supports dark mode. Theme is in `src/App.jsx`.

### Modify Theme Colors
Edit the `palette` object in `src/App.jsx` createTheme() function.

## Debugging Tips

1. **Check Network Tab**: View API requests and responses
2. **Check Console**: Look for JavaScript errors and warnings
3. **Check Redux DevTools**: If using Redux (currently using Context API)
4. **Check localStorage**: Verify token is present: `localStorage.getItem('token')`
5. **Check Network Requests**: Ensure backend is running and accessible

## Performance Considerations

- Code splitting enabled (Vite automatically handles this)
- Dynamic imports for large components
- Lazy loading of routes can be implemented if needed
- Memoization with useMemo/useCallback for expensive calculations
- Image optimization recommended

## Browser Support

- Chrome/Edge: Latest 2 versions
- Firefox: Latest 2 versions
- Safari: Latest 2 versions
- Mobile browsers: Latest iOS Safari and Chrome for Android

## Dependencies Overview

| Package | Purpose |
|---------|---------|
| react | Core framework |
| react-router-dom | Client-side routing |
| @mui/material | UI components |
| axios | HTTP client |
| formik | Form state management |
| yup | Schema validation |
| recharts | Charts & graphs |
| framer-motion | Animations |
| react-toastify | Notifications |

## Folder Naming Conventions

- **Pages**: Folder per feature/section, components in CamelCase
- **Components**: Reusable components, named with CamelCase
- **Services**: API/business logic in camelCase
- **Context**: Context providers in PascalCase ending with Context

## File Naming Conventions

- Components: `ComponentName.jsx` (PascalCase)
- Services: `serviceName.js` (camelCase)
- Styles: Inline with sx prop or separate .css files
- Assets: lowercase with hyphens (my-image.png)

## Important Notes

1. **Backend Dependency**: Application requires Spring Boot backend on http://localhost:8088
2. **JWT Tokens**: Stored in localStorage, automatically attached to requests
3. **CORS**: Backend must have CORS enabled for frontend origin
4. **Environment Variables**: Currently using hardcoded URLs (can be moved to .env)

## Future Enhancements

- Add environment variable support (.env files)
- Implement code splitting for large pages
- Add unit tests with Jest & React Testing Library
- Add E2E tests with Cypress or Playwright
- Implement PWA features
- Add TypeScript for type safety
- Implement Redux/Zustand for complex state

---

**Last Updated**: December 2025  
**Version**: 1.0.0
