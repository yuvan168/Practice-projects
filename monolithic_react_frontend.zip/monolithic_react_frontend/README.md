# Inventory Management System - React Frontend

A modern, responsive React-based frontend for an Inventory Management System built with Material-UI, Vite, and Redux. This application provides a complete user interface for managing products, users, sales, and generating reports.

## Features

### 🔐 Authentication
- **User Login & Registration**: Secure JWT-based authentication
- **Protected Routes**: Role-based access control
- **Session Management**: Automatic token refresh and logout

### 📦 Product Management
- **View Products**: Browse all products with search and filter
- **Add Product**: Create new products with details (name, description, manufacturer, quantity, price)
- **Edit Product**: Modify existing product information
- **Delete Product**: Remove products with confirmation

### 👥 User Management
- **View Users**: List all registered users
- **Add User**: Create new user accounts (Admin feature)
- **Edit User**: Modify user information
- **Delete User**: Remove user accounts

### 📊 Dashboard
- **Statistics Overview**: Display total products, low stock items, users, and revenue
- **Sales Trend**: Interactive bar chart showing monthly sales
- **Product Summary**: Quick view of recent products
- **User Summary**: Quick view of recent users

### 📈 Reports & Analytics
- **Sales Chart**: Line chart of monthly sales trends
- **Stock Distribution**: Pie chart showing stock by manufacturer
- **Inventory Report**: Detailed table with product values and totals

### ⚙️ Settings
- **Profile Management**: Edit user profile
- **Dark Mode**: Toggle between light and dark themes
- **Persistent Settings**: Theme preference saved locally

## Tech Stack

- **React 19.2** - Latest React
- **Vite 7.2** - Lightning-fast build tool
- **Material-UI (MUI 5)** - Component library
- **React Router 6** - Routing
- **Axios** - HTTP client
- **Formik & Yup** - Form management
- **Recharts** - Data visualization
- **Framer Motion** - Animations
- **React Toastify** - Notifications

## Installation & Setup

### Prerequisites
- Node.js 16+ and npm 8+
- Spring Boot backend running on http://localhost:8088

### Installation

```bash
# Install dependencies
npm install

# Configure API endpoint (if needed)
# Edit src/api/axios.js and update baseURL
```

## Running the Application

```bash
# Development mode (starts on http://localhost:3000)
npm run dev

# Production build
npm run build

# Preview production build
npm run preview
```

## Project Structure

```
src/
├── api/              # API client configuration
├── components/       # Reusable components
├── Context/          # React Context providers
├── Pages/            # Page components
│   ├── Auth/         # Login/Register pages
│   ├── Dashboard/    # Dashboard page
│   ├── Product/      # Product management
│   ├── Users/        # User management
│   ├── Reports/      # Reports page
│   └── Settings/     # Settings page
├── services/         # API services
├── Routes/           # Route configuration
├── App.jsx           # Main component
└── main.jsx          # Entry point
```

## API Integration

### Authentication
- `POST /auth/login` - User login
- `POST /auth/signup` - User registration
- `GET /auth/profile` - Get user profile
- `PUT /auth/profile` - Update profile

### Products
- `GET /products` - List all products
- `GET /products/:id` - Get single product
- `POST /products` - Create product
- `PUT /products/:id` - Update product
- `DELETE /products/:id` - Delete product

### Users (Admin)
- `GET /auth/users` - List users
- `POST /auth/users` - Create user
- `PUT /auth/users/:id` - Update user
- `DELETE /auth/users/:id` - Delete user

### Sales
- `GET /sales` - Get sales data
- `POST /sales` - Create sales record
- `PUT /sales/:id` - Update sales
- `DELETE /sales/:id` - Delete sales

## Testing Credentials

- **User**: test@test.com / password123
- **Admin**: admin@test.com / admin123

## Troubleshooting

### Build Issues
```bash
rm -rf node_modules package-lock.json
npm install
npm run build
```

### Backend Connection Issues
1. Ensure Spring Boot is running on http://localhost:8088
2. Check CORS configuration in backend
3. Verify token in localStorage
4. Check browser console for errors

## License

This project is part of an Inventory Management System.

---

**Version**: 1.0.0  
**Last Updated**: December 2025
