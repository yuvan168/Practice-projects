# Setup Guide - Inventory Management System React Frontend

## Quick Start

### 1. Prerequisites
- Node.js 16+ and npm 8+
- Spring Boot backend running on `http://localhost:8088`
- MySQL/PostgreSQL database running

### 2. Installation

```bash
# Navigate to project directory
cd monolithic_react_frontend

# Install dependencies (if not already done)
npm install
```

### 3. Database Setup

Before running the application, set up your database:

1. **Start your MySQL/PostgreSQL database server**

2. **Create the database** (Spring Boot will create tables):
   ```sql
   CREATE DATABASE inventory_management;
   ```

3. **Run the Spring Boot backend** - This will auto-create tables via Hibernate

4. **Load sample data** (optional):
   - Open `DATABASE_SETUP.sql` file
   - Execute it in your database to load test data

### 4. Start the Development Server

```bash
npm run dev
```

The application will:
- Start on `http://localhost:3000`
- Automatically open in your default browser
- Enable Hot Module Replacement (HMR) for instant updates

### 5. Login with Test Credentials

**User Account:**
- Email: `test@test.com`
- Password: `password123`

**Admin Account:**
- Email: `admin@test.com`
- Password: `admin123`

## Backend Configuration

### Default Backend URL
```
http://localhost:8088/api
```

### Change Backend URL

If your backend runs on a different port or host:

1. Edit `src/api/axios.js`
2. Update the `baseURL`:
   ```javascript
   const api = axios.create({
     baseURL: "http://your-host:your-port/api",
     // ...
   });
   ```

### Ensure CORS is Enabled

Your Spring Boot backend must have CORS enabled for the frontend origin:

```java
@Configuration
public class CorsConfig implements WebMvcConfigurer {
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/**")
            .allowedOrigins("http://localhost:3000")
            .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
            .allowedHeaders("*")
            .allowCredentials(true);
    }
}
```

## Available Scripts

### Development
```bash
npm run dev
```
Starts development server with HMR

### Production Build
```bash
npm run build
```
Creates optimized production build in `dist/` folder

### Preview Production Build
```bash
npm run preview
```
Previews the production build locally

### Lint
```bash
npm run lint
```
Checks code quality with ESLint

## Project Features

### ✅ Implemented
- ✓ Authentication (Login/Register with JWT)
- ✓ Product Management (CRUD operations)
- ✓ User Management (Admin features)
- ✓ Dashboard with Statistics & Charts
- ✓ Sales Data Management
- ✓ Reports & Analytics
- ✓ Settings & Profile Management
- ✓ Dark Mode Support
- ✓ Responsive Design
- ✓ Form Validation

### 🚀 Ready for Enhancement
- [ ] Unit Tests (Jest + React Testing Library)
- [ ] E2E Tests (Cypress/Playwright)
- [ ] TypeScript Migration
- [ ] PWA Features
- [ ] Advanced Filtering & Sorting
- [ ] Data Export (CSV/PDF)
- [ ] Real-time Notifications
- [ ] Advanced Charts & Analytics

## Project Structure

```
monolithic_react_frontend/
├── src/
│   ├── api/               # API configuration
│   ├── components/        # Reusable components
│   ├── Context/           # React Context (Auth, Theme)
│   ├── Pages/             # Page components
│   ├── services/          # API services
│   ├── Routes/            # Routing configuration
│   ├── App.jsx            # Main App component
│   ├── main.jsx           # Entry point
│   ├── index.css          # Global styles
│   └── App.css            # App styles
├── public/                # Static assets
├── dist/                  # Production build
├── .github/               # GitHub configs
├── node_modules/          # Dependencies
├── .env.example           # Environment variables template
├── DATABASE_SETUP.sql     # Database setup script
├── package.json           # Dependencies & scripts
├── vite.config.js         # Vite configuration
├── eslint.config.js       # ESLint configuration
├── README.md              # Project documentation
└── index.html             # HTML entry point
```

## Troubleshooting

### Issue: Backend connection error
**Error:** `Backend server is not running`

**Solution:**
1. Ensure Spring Boot is running: `java -jar application.jar`
2. Verify backend is accessible: `http://localhost:8088/api`
3. Check browser console for detailed errors
4. Verify CORS configuration in backend

### Issue: Build fails with missing dependencies
**Error:** `Cannot find module...`

**Solution:**
```bash
rm -rf node_modules package-lock.json
npm install
npm run build
```

### Issue: Port 3000 already in use
**Error:** `Port 3000 is already in use`

**Solution:**
1. Change port in `vite.config.js`:
   ```javascript
   server: {
     port: 3001,
     open: true,
   }
   ```
2. Or kill process on port 3000:
   ```bash
   # On Windows
   netstat -ano | findstr :3000
   taskkill /PID <PID> /F
   ```

### Issue: Token not persisting
**Error:** User gets logged out immediately

**Solution:**
1. Check browser localStorage: `localStorage.getItem('token')`
2. Verify token has `Bearer ` prefix in API calls
3. Check browser console for JWT errors
4. Ensure backend is returning valid JWT token

### Issue: Dark mode not working
**Error:** Dark mode toggle doesn't change theme

**Solution:**
1. Clear browser cache and localStorage
2. Verify Theme Context is properly wrapped in App.jsx
3. Check MUI theme object in App.jsx

## Development Tips

### Adding a New Feature

1. **Create Page Component**
   ```bash
   mkdir src/Pages/Feature
   touch src/Pages/Feature/FeatureComponent.jsx
   ```

2. **Add Route**
   - Edit `src/Routes/AppRoutes.jsx`
   - Add route with `<ProtectedRoute>` if needed

3. **Connect to API**
   - Create service in `src/services/featureService.js`
   - Use axios instance from `src/api/axios.js`

4. **Add to Navigation**
   - Update `src/components/Sidebar.jsx`
   - Add menu item with route

### Debugging in Browser

1. **Network Tab**: Check API requests/responses
2. **Console Tab**: View errors and logs
3. **Application Tab**: 
   - Check localStorage for token
   - View cookies if any
   - Check sessionStorage
4. **React DevTools**: Inspect components and state

### Code Style

- Use functional components with hooks
- Use Material-UI `sx` prop for styling
- Keep components under 500 lines
- Separate logic into custom hooks
- Add comments for complex code

## Production Deployment

### Build for Production
```bash
npm run build
```

### Deploy to Server
```bash
# Copy dist folder to your web server
scp -r dist/* user@host:/var/www/html/
```

### Environment Configuration
Create `.env` file with production values:
```
VITE_API_BASE_URL=https://api.yourdomain.com/api
```

### Web Server Configuration (Nginx)
```nginx
location / {
    try_files $uri $uri/ /index.html;
}
```

## Support & Resources

### Useful Links
- React Documentation: https://react.dev
- Material-UI: https://mui.com
- Vite: https://vitejs.dev
- React Router: https://reactrouter.com
- Formik: https://formik.org

### Getting Help
1. Check browser console for error messages
2. Review README.md in project root
3. Check `.github/copilot-instructions.md` for detailed guidelines
4. Review DATABASE_SETUP.sql for database setup
5. Check Spring Boot backend logs

---

**Version**: 1.0.0  
**Last Updated**: December 2025

Good luck with your Inventory Management System! 🎉
