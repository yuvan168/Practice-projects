-- Inventory Management System - Database Setup Script
-- This script sets up the database with sample data for testing

-- ============================================
-- 1. ADD ROLES
-- ============================================

INSERT INTO roles (id, name) 
VALUES (1, 'ROLE_USER')
ON DUPLICATE KEY UPDATE name = 'ROLE_USER';

INSERT INTO roles (id, name) 
VALUES (2, 'ROLE_ADMIN')
ON DUPLICATE KEY UPDATE name = 'ROLE_ADMIN';

-- ============================================
-- 2. ADD TEST USERS
-- ============================================

-- Password: "password123" (BCrypt hashed)
INSERT INTO users (email, password, first_name, last_name)
VALUES ('test@test.com', '$2a$10$dXJ3SW6G7P50lGmMkkmwe.20cQQubK3.HZWzG3YB1tlRy.fqvM/BG', 'Test', 'User')
ON DUPLICATE KEY UPDATE email = 'test@test.com';

-- Password: "admin123" (BCrypt hashed)
INSERT INTO users (email, password, first_name, last_name)
VALUES ('admin@test.com', '$2a$10$5iyM7LJeJBBqJrN5p8z1zeOGhfJvHXYjEXuJZnBJl9wZ5qL3Q8cFW', 'Admin', 'User')
ON DUPLICATE KEY UPDATE email = 'admin@test.com';

-- ============================================
-- 3. LINK USERS TO ROLES
-- ============================================

INSERT INTO user_roles (user_id, role_id)
SELECT u.id, r.id 
FROM users u, roles r
WHERE u.email = 'test@test.com' AND r.name = 'ROLE_USER'
ON DUPLICATE KEY UPDATE user_id = user_id;

INSERT INTO user_roles (user_id, role_id)
SELECT u.id, r.id 
FROM users u, roles r
WHERE u.email = 'admin@test.com' AND r.name = 'ROLE_ADMIN'
ON DUPLICATE KEY UPDATE user_id = user_id;

-- ============================================
-- 4. ADD TEST PRODUCTS
-- ============================================

INSERT INTO products (name, description, manufacturer, quantity, price)
VALUES 
  ('Laptop', 'High performance laptop with 16GB RAM', 'Dell', 15, 55000),
  ('Mouse', 'Wireless optical mouse', 'Logitech', 50, 500),
  ('Keyboard', 'Mechanical RGB keyboard', 'Corsair', 30, 3500),
  ('Monitor', '27 inch 4K display', 'Samsung', 20, 25000),
  ('Headphones', 'Noise cancelling headphones', 'Sony', 40, 8000),
  ('USB Cable', 'Type-C charging cable', 'Anker', 100, 200),
  ('Power Bank', '20000mAh power bank', 'Xiaomi', 25, 1500),
  ('SSD', '1TB NVMe SSD', 'Samsung', 35, 8000),
  ('RAM', '8GB DDR4 Memory', 'Corsair', 45, 2500),
  ('Motherboard', 'B450 Chipset Motherboard', 'ASUS', 12, 12000);

-- ============================================
-- 5. ADD TEST SALES DATA
-- ============================================

INSERT INTO sales (name, sales, revenue)
VALUES 
  ('January', 120, 150000),
  ('February', 90, 110000),
  ('March', 140, 180000),
  ('April', 180, 220000),
  ('May', 160, 200000),
  ('June', 200, 250000),
  ('July', 175, 220000),
  ('August', 195, 240000);

-- ============================================
-- VERIFICATION QUERIES
-- ============================================

-- Check roles
SELECT * FROM roles;

-- Check users
SELECT id, email, first_name, last_name FROM users;

-- Check user roles
SELECT u.email, r.name as role
FROM users u
JOIN user_roles ur ON u.id = ur.user_id
JOIN roles r ON ur.role_id = r.id;

-- Check products count
SELECT COUNT(*) as total_products FROM products;

-- Check sales records
SELECT COUNT(*) as total_sales FROM sales;

-- ============================================
-- LOGIN CREDENTIALS FOR TESTING
-- ============================================

-- User Account:
-- Email: test@test.com
-- Password: password123

-- Admin Account:
-- Email: admin@test.com
-- Password: admin123

-- ============================================
-- IF TABLES DON'T EXIST
-- ============================================

-- If you get "table doesn't exist" errors, your Spring Boot
-- application needs to create tables first.

-- Make sure application.properties has:
-- spring.jpa.hibernate.ddl-auto=update
-- OR
-- spring.jpa.hibernate.ddl-auto=create

-- Steps:
-- 1. Start Spring Boot application (it will create tables)
-- 2. Stop Spring Boot
-- 3. Run this SQL script in your database
-- 4. Start Spring Boot again

-- ============================================
-- FOR POSTGRESQL (if using PostgreSQL)
-- ============================================

-- Replace "ON DUPLICATE KEY UPDATE" with:
-- ON CONFLICT (email) DO UPDATE SET ...

-- Example:
-- INSERT INTO users (email, password, first_name, last_name)
-- VALUES ('test@test.com', '$2a$10$...', 'Test', 'User')
-- ON CONFLICT (email) DO NOTHING;
