import React, { useState } from "react";
import { Formik, Form } from "formik";
import * as Yup from "yup";
import API from "../../api/axios";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";
import { Button, TextField, Box, Paper, Typography, IconButton } from "@mui/material";
import { KeyboardArrowUp, KeyboardArrowDown } from "@mui/icons-material";

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

const schema = Yup.object({
  name: Yup.string().required("Name is required"),
  description: Yup.string(),
  manufacturer: Yup.string(),
  quantity: Yup.number().min(1, "Minimum 1").required("Quantity is required"),
  price: Yup.number().positive("Must be positive").required("Price is required"),
});

export default function AddProduct() {
  const navigate = useNavigate();
  const [selectedMonth, setSelectedMonth] = useState("");
  const [showMonthSuggestions, setShowMonthSuggestions] = useState(false);

  const getMonthSuggestions = () => {
    if (!selectedMonth) return MONTHS;
    return MONTHS.filter(month => 
      month.toLowerCase().startsWith(selectedMonth.toLowerCase())
    );
  };

  const handleMonthChange = (e) => {
    const value = e.target.value;
    setSelectedMonth(value);
    setShowMonthSuggestions(value.length > 0);
  };

  const handleSelectMonth = (month) => {
    setSelectedMonth(month);
    setShowMonthSuggestions(false);
  };

  const handleMonthNavigation = (direction) => {
    const currentIndex = MONTHS.findIndex(m => m === selectedMonth);
    let newIndex = direction === "up" ? currentIndex - 1 : currentIndex + 1;
    
    if (newIndex < 0) newIndex = MONTHS.length - 1;
    if (newIndex >= MONTHS.length) newIndex = 0;
    
    setSelectedMonth(MONTHS[newIndex]);
  };

  return (
    <Paper sx={{ padding: 3, margin: 3 }}>
      <Typography variant="h5" sx={{ marginBottom: 3, fontWeight: "bold" }}>
        Add New Product
      </Typography>
      <Formik
        initialValues={{ name: "", description: "", manufacturer: "", quantity: "", price: "" }}
        validationSchema={schema}
        onSubmit={async (values, { resetForm }) => {
          try {
            console.log("Adding product with data:", values);
            const response = await API.post("/products", values);
            console.log("Product added successfully:", response.data);
            
            // Use selected month or current month
            const monthToUse = selectedMonth || new Date().toLocaleString('default', { month: 'short' });
            
            try {
              // Try to get all sales to check if month exists
              const salesRes = await API.get("/sales");
              const existingSales = salesRes.data.find(s => s.name === monthToUse);
              
              if (!existingSales) {
                // Add month if it doesn't exist
                await API.post("/sales", {
                  name: monthToUse,
                  sales: 1,
                  revenue: values.price * values.quantity
                });
              } else {
                // Update month with new product
                await API.put(`/sales/${existingSales.id}`, {
                  name: existingSales.name,
                  sales: (existingSales.sales || 0) + 1,
                  revenue: (existingSales.revenue || 0) + (values.price * values.quantity)
                });
              }
            } catch (salesErr) {
              console.log("Could not update sales data:", salesErr.message);
            }
            
            toast.success("Product added successfully!");
            resetForm();
            setSelectedMonth("");
            navigate("/products");
          } catch (err) {
            console.error("Error adding product:");
            console.error("Status:", err.response?.status);
            console.error("Data:", err.response?.data);
            console.error("Message:", err.message);
            toast.error("Error adding product: " + (err.response?.data?.message || err.message));
          }
        }}
      >
        {({ values, errors, touched, handleChange, handleSubmit }) => (
          <Form onSubmit={handleSubmit}>
            <Box display="flex" flexDirection="column" gap={2} mt={2}>
              <TextField
                label="Product Name"
                name="name"
                value={values.name}
                onChange={handleChange}
                error={touched.name && Boolean(errors.name)}
                helperText={touched.name && errors.name}
                fullWidth
              />

              <TextField
                label="Description"
                name="description"
                value={values.description}
                onChange={handleChange}
                error={touched.description && Boolean(errors.description)}
                helperText={touched.description && errors.description}
                fullWidth
                multiline
                rows={3}
              />

              <TextField
                label="Manufacturer"
                name="manufacturer"
                value={values.manufacturer}
                onChange={handleChange}
                error={touched.manufacturer && Boolean(errors.manufacturer)}
                helperText={touched.manufacturer && errors.manufacturer}
                fullWidth
              />

              <TextField
                label="Quantity"
                name="quantity"
                type="number"
                value={values.quantity}
                onChange={handleChange}
                error={touched.quantity && Boolean(errors.quantity)}
                helperText={touched.quantity && errors.quantity}
                fullWidth
              />

              <TextField
                label="Price"
                name="price"
                type="number"
                value={values.price}
                onChange={handleChange}
                error={touched.price && Boolean(errors.price)}
                helperText={touched.price && errors.price}
                fullWidth
              />

              <Box sx={{ position: "relative" }}>
                <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: "500" }}>Sales Month (Optional)</Typography>
                <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                  <IconButton
                    size="small"
                    onClick={() => handleMonthNavigation("up")}
                    sx={{ padding: "2px" }}
                  >
                    <KeyboardArrowUp fontSize="small" />
                  </IconButton>
                  <input
                    type="text"
                    placeholder="Select Month"
                    value={selectedMonth}
                    onChange={handleMonthChange}
                    onFocus={() => selectedMonth && setShowMonthSuggestions(true)}
                    style={{ width: "100px", padding: "8px", fontSize: "14px", textAlign: "center", border: "1px solid #ccc", borderRadius: "4px" }}
                  />
                  <IconButton
                    size="small"
                    onClick={() => handleMonthNavigation("down")}
                    sx={{ padding: "2px" }}
                  >
                    <KeyboardArrowDown fontSize="small" />
                  </IconButton>
                </Box>
                {showMonthSuggestions && getMonthSuggestions().length > 0 && (
                  <Paper sx={{ 
                    position: "absolute",
                    top: "100%",
                    left: 0,
                    backgroundColor: "white",
                    border: "1px solid #ccc",
                    borderRadius: "4px",
                    maxHeight: "140px", 
                    overflowY: "auto",
                    zIndex: 1000,
                    width: "120px",
                    boxShadow: "0 2px 8px rgba(0,0,0,0.15)"
                  }}>
                    {getMonthSuggestions().map((month) => (
                      <Box
                        key={month}
                        onClick={() => handleSelectMonth(month)}
                        sx={{
                          p: "6px 8px",
                          cursor: "pointer",
                          fontSize: "13px",
                          whiteSpace: "nowrap",
                          "&:hover": { backgroundColor: "#e8f4f8", fontWeight: "500" }
                        }}
                      >
                        {month}
                      </Box>
                    ))}
                  </Paper>
                )}
                {!selectedMonth && (
                  <Typography variant="caption" sx={{ display: "block", mt: 0.5, color: "text.secondary" }}>
                    (Defaults to current month if not selected)
                  </Typography>
                )}
              </Box>

              <Box display="flex" justifyContent="flex-end" gap={1}>
                <Button onClick={() => navigate("/products")}>Cancel</Button>
                <Button type="submit" variant="contained" color="success">
                  Save Product
                </Button>
              </Box>
            </Box>
          </Form>
        )}
      </Formik>
    </Paper>
  );
}
