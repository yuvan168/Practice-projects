import React, { useEffect, useState, useCallback } from "react";
import { Button, TextField, Box, Paper, Typography } from "@mui/material";
import { Formik, Form } from "formik";
import * as Yup from "yup";
import API from "../../api/axios";
import { toast } from "react-toastify";
import { useParams, useNavigate } from "react-router-dom";

const schema = Yup.object({
  name: Yup.string().required("Name is required"),
  description: Yup.string(),
  manufacturer: Yup.string(),
  quantity: Yup.number().min(1, "At least 1 item").required(),
  price: Yup.number().positive("Must be positive").required(),
});

export default function EditProduct() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState(null);

  const loadProduct = useCallback(async () => {
    try {
      const res = await API.get(`/products/${id}`);
      setProduct(res.data);
    } catch (err) {
      toast.error("Failed to load product!");
      navigate("/products");
    }
  }, [id, navigate]);

  useEffect(() => {
    loadProduct();
  }, [loadProduct]);

  if (!product) return <Paper sx={{ padding: 3, margin: 3 }}><Typography>Loading product...</Typography></Paper>;

  return (
    <Paper sx={{ padding: 3, margin: 3 }}>
      <Typography variant="h5" sx={{ marginBottom: 3, fontWeight: "bold" }}>
        Edit Product
      </Typography>
      <Formik
        initialValues={{
          name: product.name,
          description: product.description || "",
          manufacturer: product.manufacturer || "",
          quantity: product.quantity,
          price: product.price,
        }}
        validationSchema={schema}
        onSubmit={async (values) => {
          try {
            await API.put(`/products/${id}`, values);
            toast.success("Product updated successfully!");
            navigate("/products");
          } catch (err) {
            console.error("Error updating product:", err);
            toast.error("Error updating product: " + (err.response?.data?.message || err.message));
          }
        }}
      >
        {({ values, errors, touched, handleChange, handleSubmit }) => (
          <Form onSubmit={handleSubmit}>
            <Box display="flex" flexDirection="column" gap={2} mt={2}>
              <TextField
                label="Product Name"
                name="name"
                value={values.name}
                onChange={handleChange}
                error={touched.name && Boolean(errors.name)}
                helperText={touched.name && errors.name}
                fullWidth
              />

              <TextField
                label="Description"
                name="description"
                value={values.description}
                onChange={handleChange}
                error={touched.description && Boolean(errors.description)}
                helperText={touched.description && errors.description}
                multiline
                rows={3}
                fullWidth
              />

              <TextField
                label="Manufacturer"
                name="manufacturer"
                value={values.manufacturer}
                onChange={handleChange}
                error={touched.manufacturer && Boolean(errors.manufacturer)}
                helperText={touched.manufacturer && errors.manufacturer}
                fullWidth
              />

              <TextField
                label="Quantity"
                name="quantity"
                type="number"
                value={values.quantity}
                onChange={handleChange}
                error={touched.quantity && Boolean(errors.quantity)}
                helperText={touched.quantity && errors.quantity}
                fullWidth
              />

              <TextField
                label="Price"
                name="price"
                type="number"
                value={values.price}
                onChange={handleChange}
                error={touched.price && Boolean(errors.price)}
                helperText={touched.price && errors.price}
                fullWidth
              />

              <Box display="flex" justifyContent="flex-end" gap={1}>
                <Button onClick={() => navigate("/products")}>Cancel</Button>
                <Button type="submit" variant="contained" color="success">
                  Update Product
                </Button>
              </Box>
            </Box>
          </Form>
        )}
      </Formik>
    </Paper>
  );
}
