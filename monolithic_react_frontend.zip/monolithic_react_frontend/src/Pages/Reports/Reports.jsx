import React, { useEffect, useState } from "react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar
} from "recharts";
import { Grid, Typography, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, IconButton, Button, Dialog, DialogTitle, DialogContent, DialogActions, TextField, Select, MenuItem, FormControl, InputLabel, Box } from "@mui/material";
import { Edit, Delete, Add } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";
import API from "../../api/axios";
import { toast } from "react-toastify";

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export default function Reports() {
  const [salesData, setSalesData] = useState([]);
  const [products, setProducts] = useState([]);
  const [stockData, setStockData] = useState([]);
  const [selectedMonth, setSelectedMonth] = useState("");
  const [editingSalesId, setEditingSalesId] = useState(null);
  const [editForm, setEditForm] = useState({ name: "", sales: "", revenue: "" });
  const [addSalesOpen, setAddSalesOpen] = useState(false);
  const [newSalesForm, setNewSalesForm] = useState({ name: "", sales: "", revenue: "" });
  const navigate = useNavigate();

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8"];

  useEffect(() => {
    fetchReportData();
  }, []);

  const fetchReportData = async () => {
    try {
      const res = await API.get("/products");
      const productData = res.data;
      setProducts(productData);

      try {
        const salesRes = await API.get("/sales");
        const salesApiData = salesRes.data;
        setSalesData(salesApiData);
        
        // Auto-select current month on first load
        if (salesApiData.length > 0 && !selectedMonth) {
          const currentMonth = new Date().getMonth();
          const currentMonthName = MONTHS[currentMonth];
          if (salesApiData.some(s => s.name === currentMonthName)) {
            setSelectedMonth(currentMonthName);
          } else {
            setSelectedMonth(salesApiData[0].name);
          }
        }
      } catch (err) {
        console.log("Sales endpoint not available");
      }

      const categoryMap = {};
      productData.forEach(p => {
        const category = p.manufacturer || "Other";
        categoryMap[category] = (categoryMap[category] || 0) + p.quantity;
      });

      const categoryData = Object.keys(categoryMap).map(key => ({
        name: key,
        value: categoryMap[key]
      }));
      setStockData(categoryData);
    } catch (error) {
      console.error("Error fetching report data:", error);
      toast.error("Failed to load report data");
    }
  };

  const handleEditSales = (item) => {
    setEditingSalesId(item.id);
    setEditForm({ name: item.name, sales: item.sales, revenue: item.revenue || "" });
  };

  const handleSaveSales = async (id) => {
    try {
      await API.put(`/sales/${id}`, {
        name: editForm.name,
        sales: parseInt(editForm.sales),
        revenue: editForm.revenue ? parseFloat(editForm.revenue) : null
      });
      setEditingSalesId(null);
      toast.success("Sales data updated successfully!");
      fetchReportData();
    } catch (error) {
      console.error("Error updating sales:", error);
      toast.error("Failed to update sales data: " + (error.response?.data?.message || error.message));
    }
  };

  const handleDeleteSales = async (id) => {
    if (!window.confirm("Are you sure you want to delete this sales entry?")) return;

    try {
      await API.delete(`/sales/${id}`);
      toast.success("Sales data deleted successfully!");
      fetchReportData();
    } catch (error) {
      console.error("Error deleting sales:", error);
      toast.error("Failed to delete sales data: " + (error.response?.data?.message || error.message));
    }
  };

  const handleAddSales = async () => {
    if (!newSalesForm.name || !newSalesForm.sales) {
      toast.error("Month and Sales are required");
      return;
    }

    try {
      await API.post("/sales", {
        name: newSalesForm.name,
        sales: parseInt(newSalesForm.sales),
        revenue: newSalesForm.revenue ? parseFloat(newSalesForm.revenue) : null
      });
      toast.success("Sales data added successfully!");
      setAddSalesOpen(false);
      setNewSalesForm({ name: "", sales: "", revenue: "" });
      fetchReportData();
    } catch (error) {
      console.error("Error adding sales:", error);
      toast.error("Failed to add sales data: " + (error.response?.data?.message || error.message));
    }
  };

  const handleEdit = (id) => {
    navigate(`/products/edit/${id}`);
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this product?")) return;

    try {
      await API.delete(`/products/${id}`);
      toast.success("Product deleted successfully!");
      fetchReportData();
    } catch (error) {
      console.error("Error deleting product:", error);
      toast.error("Failed to delete product");
    }
  };

  return (
    <div style={{ padding: "20px" }}>
      <Typography variant="h5" gutterBottom>Reports & Analytics</Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" sx={{ mb: 2 }}>Monthly Sales Trend</Typography>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={selectedMonth ? salesData.filter(s => s.name === selectedMonth) : salesData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="sales" stroke="#8884d8" strokeWidth={2} name="Sales Count" />
                <Line type="monotone" dataKey="revenue" stroke="#82ca9d" strokeWidth={2} name="Revenue" />
              </LineChart>
            </ResponsiveContainer>
            <Box sx={{ display: "flex", justifyContent: "center", mt: 2 }}>
              <FormControl sx={{ minWidth: 120 }} size="small">
                <InputLabel>Month</InputLabel>
                <Select
                  value={selectedMonth}
                  onChange={(e) => setSelectedMonth(e.target.value)}
                  label="Month"
                >
                  {salesData.map((sale) => (
                    <MenuItem key={sale.id || sale.name} value={sale.name}>
                      {sale.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Box>
          </Paper>
        </Grid>

        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6">Stock by Manufacturer</Typography>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={stockData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {stockData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </Paper>
        </Grid>

        <Grid item xs={12}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6">Annual Sales Trend (All Months)</Typography>
            <ResponsiveContainer width="100%" height={350}>
              <BarChart data={salesData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis yAxisId="left" label={{ value: "Sales Count", angle: -90, position: "insideLeft" }} />
                <YAxis yAxisId="right" orientation="right" label={{ value: "Revenue (₹)", angle: 90, position: "insideRight" }} />
                <Tooltip formatter={(value) => typeof value === 'number' ? value.toLocaleString() : value} />
                <Legend />
                <Bar yAxisId="left" dataKey="sales" fill="#8884d8" name="Sales Count" radius={[8, 8, 0, 0]} />
                <Bar yAxisId="right" dataKey="revenue" fill="#82ca9d" name="Revenue (₹)" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Paper>
        </Grid>

        <Grid item xs={12}>
          <Paper sx={{ p: 2 }}>
            <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 2 }}>
              <Typography variant="h6">Sales Management</Typography>
            </Box>

            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow sx={{ backgroundColor: "#1976d2" }}>
                    <TableCell sx={{ color: "white" }}>Month</TableCell>
                    <TableCell sx={{ color: "white" }} align="right">Sales Count</TableCell>
                    <TableCell sx={{ color: "white" }} align="right">Revenue (₹)</TableCell>
                    <TableCell sx={{ color: "white" }} align="center">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {salesData.map((item) => (
                    <TableRow key={item.id}>
                      {editingSalesId === item.id ? (
                        <>
                          <TableCell>
                            <TextField
                              size="small"
                              value={editForm.name}
                              onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                              fullWidth
                            />
                          </TableCell>
                          <TableCell align="right">
                            <TextField
                              size="small"
                              type="number"
                              value={editForm.sales}
                              onChange={(e) => setEditForm({ ...editForm, sales: e.target.value })}
                              fullWidth
                            />
                          </TableCell>
                          <TableCell align="right">
                            <TextField
                              size="small"
                              type="number"
                              value={editForm.revenue}
                              onChange={(e) => setEditForm({ ...editForm, revenue: e.target.value })}
                              fullWidth
                            />
                          </TableCell>
                          <TableCell align="center">
                            <Button
                              size="small"
                              variant="contained"
                              color="success"
                              onClick={() => handleSaveSales(item.id)}
                              sx={{ mr: 1 }}
                            >
                              Save
                            </Button>
                            <Button
                              size="small"
                              variant="outlined"
                              onClick={() => setEditingSalesId(null)}
                            >
                              Cancel
                            </Button>
                          </TableCell>
                        </>
                      ) : (
                        <>
                          <TableCell>{item.name}</TableCell>
                          <TableCell align="right">{item.sales}</TableCell>
                          <TableCell align="right">₹{item.revenue ? item.revenue.toLocaleString() : "N/A"}</TableCell>
                          <TableCell align="center">
                            <IconButton
                              color="primary"
                              size="small"
                              onClick={() => handleEditSales(item)}
                            >
                              <Edit />
                            </IconButton>
                            <IconButton
                              color="error"
                              size="small"
                              onClick={() => handleDeleteSales(item.id)}
                            >
                              <Delete />
                            </IconButton>
                          </TableCell>
                        </>
                      )}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Paper>
        </Grid>

        <Grid item xs={12}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" mb={2}>Product Inventory Report</Typography>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow sx={{ backgroundColor: "#1976d2" }}>
                    <TableCell sx={{ color: "white" }}>ID</TableCell>
                    <TableCell sx={{ color: "white" }}>Name</TableCell>
                    <TableCell sx={{ color: "white" }}>Manufacturer</TableCell>
                    <TableCell sx={{ color: "white" }}>Quantity</TableCell>
                    <TableCell sx={{ color: "white" }}>Price (₹)</TableCell>
                    <TableCell sx={{ color: "white" }}>Total Value (₹)</TableCell>
                    <TableCell sx={{ color: "white" }} align="center">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {products.map((product) => (
                    <TableRow key={product.id}>
                      <TableCell>{product.id}</TableCell>
                      <TableCell>{product.name}</TableCell>
                      <TableCell>{product.manufacturer || "N/A"}</TableCell>
                      <TableCell>{product.quantity}</TableCell>
                      <TableCell>₹{product.price}</TableCell>
                      <TableCell>₹{(product.price * product.quantity).toLocaleString()}</TableCell>
                      <TableCell align="center">
                        <IconButton color="primary" size="small" onClick={() => handleEdit(product.id)}>
                          <Edit />
                        </IconButton>
                        <IconButton color="error" size="small" onClick={() => handleDelete(product.id)}>
                          <Delete />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Paper>
        </Grid>
      </Grid>

      {/* Add Sales Dialog */}
      <Dialog open={addSalesOpen} onClose={() => setAddSalesOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Add New Sales Entry</DialogTitle>
        <DialogContent sx={{ pt: 2 }}>
          <FormControl fullWidth sx={{ mb: 2 }}>
            <InputLabel>Month</InputLabel>
            <Select
              value={newSalesForm.name}
              onChange={(e) => setNewSalesForm({ ...newSalesForm, name: e.target.value })}
              label="Month"
            >
              {MONTHS.map((month) => (
                <MenuItem key={month} value={month}>
                  {month}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          <TextField
            label="Sales Count"
            type="number"
            fullWidth
            margin="normal"
            value={newSalesForm.sales}
            onChange={(e) => setNewSalesForm({ ...newSalesForm, sales: e.target.value })}
          />
          <TextField
            label="Revenue (Optional)"
            type="number"
            fullWidth
            margin="normal"
            value={newSalesForm.revenue}
            onChange={(e) => setNewSalesForm({ ...newSalesForm, revenue: e.target.value })}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setAddSalesOpen(false)}>Cancel</Button>
          <Button onClick={handleAddSales} variant="contained" color="success">
            Add Sales
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
