import React, { useState, useContext, useEffect } from "react";
import {
  Typography, Switch, FormControlLabel, TextField,
  Button, Box, Paper, CircularProgress
} from "@mui/material";
import { toast } from "react-toastify";
import { ThemeContext } from "../../App";
import { AuthContext } from "../../Context/AuthContext";
import API from "../../api/axios";

export default function Settings() {
  const { darkMode, toggleDarkMode } = useContext(ThemeContext);
  const { user } = useContext(AuthContext);
  const [profile, setProfile] = useState({
    firstName: "",
    lastName: "",
    email: "",
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchUserProfile();
  }, []);

  const fetchUserProfile = async () => {
    try {
      const res = await API.get("/auth/profile");
      setProfile({
        firstName: res.data.firstName || "",
        lastName: res.data.lastName || "",
        email: res.data.email || "",
      });
      setLoading(false);
    } catch (error) {
      console.error("Error fetching profile:", error);
      if (user) {
        setProfile({
          firstName: user.firstName || "",
          lastName: user.lastName || "",
          email: user.email || "",
        });
      }
      setLoading(false);
    }
  };

  const handleSave = async () => {
    try {
      await API.put("/auth/profile", profile);
      localStorage.setItem("userProfile", JSON.stringify({
        name: `${profile.firstName} ${profile.lastName}`.trim(),
        email: profile.email
      }));
      toast.success("Profile updated successfully!");
    } catch (error) {
      console.error("Error updating profile:", error);
      toast.error("Failed to update profile");
    }
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '50vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Paper sx={{ p: 4, mt: 3 }}>
      <Typography variant="h5" gutterBottom>Settings</Typography>

      <FormControlLabel
        control={
          <Switch
            checked={darkMode}
            onChange={toggleDarkMode}
            color="primary"
          />
        }
        label="Enable Dark Mode"
      />

      <Box sx={{ mt: 3 }}>
        <Typography variant="h6">Profile Information</Typography>
        <TextField
          label="First Name"
          fullWidth
          margin="normal"
          value={profile.firstName}
          onChange={(e) => setProfile({ ...profile, firstName: e.target.value })}
        />
        <TextField
          label="Last Name"
          fullWidth
          margin="normal"
          value={profile.lastName}
          onChange={(e) => setProfile({ ...profile, lastName: e.target.value })}
        />
        <TextField
          label="Email"
          fullWidth
          margin="normal"
          value={profile.email}
          onChange={(e) => setProfile({ ...profile, email: e.target.value })}
          disabled
        />
        <Button variant="contained" sx={{ mt: 2 }} onClick={handleSave}>
          Save Changes
        </Button>
      </Box>
    </Paper>
  );
}
