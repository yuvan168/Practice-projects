import React, { useEffect, useState } from "react";
import API from "../../api/axios";
import {
  Table, TableHead, TableRow, TableCell,
  TableBody, Typography, Paper, TableContainer, IconButton,
  Dialog, DialogTitle, DialogContent, DialogActions,
  TextField, Button, Box
} from "@mui/material";
import { Edit, Delete } from "@mui/icons-material";
import { toast } from "react-toastify";

export default function UserList() {
  const [users, setUsers] = useState([]);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [editForm, setEditForm] = useState({
    firstName: "",
    lastName: "",
    email: ""
  });
  const [addForm, setAddForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: ""
  });

  const fetchUsers = async () => {
    try {
      console.log("Fetching users from /auth/users...");
      console.log("Token:", localStorage.getItem("token") ? "Present" : "Missing");
      const res = await API.get("/auth/users");
      console.log("Users loaded successfully:", res.data);
      console.log("Number of users:", res.data.length);
      setUsers(res.data);
      if (res.data.length === 0) {
        toast.info("No users found in database");
      }
    } catch (err) {
      console.error("Error fetching users:");
      console.error("Status:", err.response?.status);
      console.error("Data:", err.response?.data);
      console.error("Message:", err.message);
      if (err.response?.status === 403) {
        toast.error("Access denied. Admin privileges required.");
      } else if (err.response?.status === 401) {
        toast.error("Session expired. Please login again.");
      } else {
        toast.error("Failed to load users: " + (err.response?.data?.message || err.message));
      }
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleEditClick = (user) => {
    setSelectedUser(user);
    setEditForm({
      firstName: user.firstName || "",
      lastName: user.lastName || "",
      email: user.email || ""
    });
    setEditDialogOpen(true);
  };

  const handleEditClose = () => {
    setEditDialogOpen(false);
    setSelectedUser(null);
    setEditForm({ firstName: "", lastName: "", email: "" });
  };

  const handleEditSubmit = async () => {
    try {
      await API.put(`/auth/users/${selectedUser.id}`, editForm);
      toast.success("User updated successfully!");
      handleEditClose();
      fetchUsers();
    } catch (err) {
      console.error("Error updating user:", err);
      toast.error("Failed to update user: " + (err.response?.data?.message || err.message));
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this user?")) return;

    try {
      await API.delete(`/auth/users/${id}`);
      toast.success("User deleted successfully!");
      fetchUsers();
    } catch (err) {
      console.error("Error deleting user:", err);
      toast.error("Failed to delete user: " + (err.response?.data?.message || err.message));
    }
  };

  const handleAddClick = () => {
    setAddDialogOpen(true);
  };

  const handleAddClose = () => {
    setAddDialogOpen(false);
    setAddForm({ firstName: "", lastName: "", email: "", password: "" });
  };

  const handleAddSubmit = async () => {
    try {
      console.log("Adding user with data:", addForm);
      const response = await API.post("/auth/users", addForm);
      console.log("User added successfully:", response.data);
      toast.success("User added successfully!");
      handleAddClose();
      fetchUsers();
    } catch (err) {
      console.error("Error adding user:", err);
      console.error("Error response:", err.response?.data);
      console.error("Error status:", err.response?.status);
      toast.error("Failed to add user: " + (err.response?.data?.message || err.message));
    }
  };

  return (
    <>
      <Paper sx={{ p: 3, mt: 2 }}>
        <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
          <Typography variant="h5">Registered Users</Typography>
          <Button variant="contained" color="primary" onClick={handleAddClick}>
            Add User
          </Button>
        </Box>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow sx={{ backgroundColor: "#1976d2" }}>
                <TableCell sx={{ color: "white", fontWeight: "bold" }}>ID</TableCell>
                <TableCell sx={{ color: "white", fontWeight: "bold" }}>First Name</TableCell>
                <TableCell sx={{ color: "white", fontWeight: "bold" }}>Last Name</TableCell>
                <TableCell sx={{ color: "white", fontWeight: "bold" }}>Email</TableCell>
                <TableCell sx={{ color: "white", fontWeight: "bold" }}>Role</TableCell>
                <TableCell sx={{ color: "white", fontWeight: "bold" }} align="center">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {users.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} align="center" sx={{ py: 3, color: "text.secondary" }}>
                    No users found
                  </TableCell>
                </TableRow>
              ) : (
                users.map((u) => (
                  <TableRow key={u.id} hover>
                    <TableCell>{u.id}</TableCell>
                    <TableCell>{u.firstName || "N/A"}</TableCell>
                    <TableCell>{u.lastName || "N/A"}</TableCell>
                    <TableCell>{u.email}</TableCell>
                    <TableCell>{u.role || "USER"}</TableCell>
                    <TableCell align="center">
                      <IconButton color="primary" size="small" onClick={() => handleEditClick(u)}>
                        <Edit />
                      </IconButton>
                      <IconButton color="error" size="small" onClick={() => handleDelete(u.id)}>
                        <Delete />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      <Dialog open={editDialogOpen} onClose={handleEditClose} maxWidth="sm" fullWidth>
        <DialogTitle>Edit User</DialogTitle>
        <DialogContent>
          <TextField
            label="First Name"
            fullWidth
            margin="normal"
            value={editForm.firstName}
            onChange={(e) => setEditForm({ ...editForm, firstName: e.target.value })}
          />
          <TextField
            label="Last Name"
            fullWidth
            margin="normal"
            value={editForm.lastName}
            onChange={(e) => setEditForm({ ...editForm, lastName: e.target.value })}
          />
          <TextField
            label="Email"
            fullWidth
            margin="normal"
            type="email"
            value={editForm.email}
            onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleEditClose}>Cancel</Button>
          <Button onClick={handleEditSubmit} variant="contained" color="primary">
            Save Changes
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog open={addDialogOpen} onClose={handleAddClose} maxWidth="sm" fullWidth>
        <DialogTitle>Add New User</DialogTitle>
        <DialogContent>
          <TextField
            label="First Name"
            fullWidth
            margin="normal"
            value={addForm.firstName}
            onChange={(e) => setAddForm({ ...addForm, firstName: e.target.value })}
          />
          <TextField
            label="Last Name"
            fullWidth
            margin="normal"
            value={addForm.lastName}
            onChange={(e) => setAddForm({ ...addForm, lastName: e.target.value })}
          />
          <TextField
            label="Email"
            fullWidth
            margin="normal"
            type="email"
            value={addForm.email}
            onChange={(e) => setAddForm({ ...addForm, email: e.target.value })}
          />
          <TextField
            label="Password"
            fullWidth
            margin="normal"
            type="password"
            value={addForm.password}
            onChange={(e) => setAddForm({ ...addForm, password: e.target.value })}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleAddClose}>Cancel</Button>
          <Button onClick={handleAddSubmit} variant="contained" color="primary">
            Add User
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
}
