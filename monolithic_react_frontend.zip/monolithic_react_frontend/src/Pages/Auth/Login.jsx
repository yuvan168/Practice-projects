import React, { useState, useContext } from "react";
import API from "../../api/axios";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../../Context/AuthContext";
import {
  Box,
  Paper,
  TextField,
  Button,
  Typography,
  Alert,
  OutlinedInput,
  FormControl,
  InputLabel
} from "@mui/material";

export default function Login() {
  const [form, setForm] = useState({ email: "", password: "" });
  const [message, setMessage] = useState("");
  const navigate = useNavigate();
  const { login } = useContext(AuthContext);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await API.post("/auth/login", form);
      console.log("Login response:", res.data);

      login(res.data.token, {
        email: res.data.email || form.email,
        firstName: res.data.firstName,
        lastName: res.data.lastName
      });

      const fullName = `${res.data.firstName || ""} ${res.data.lastName || ""}`.trim();
      const profileData = {
        name: fullName || res.data.email || form.email,
        email: res.data.email || form.email
      };

      console.log("Saving profile to localStorage:", profileData);
      localStorage.setItem("userProfile", JSON.stringify(profileData));

      navigate("/dashboard");
    } catch (err) {
      console.error("Login error:", err.response?.data || err.message);
      setMessage(err.response?.data?.message || "Login failed!");
    }
  };

  return (
    <Box
      sx={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        minHeight: "100vh",
        background: (theme) => theme.palette.mode === 'dark'
          ? 'linear-gradient(135deg, #0a1929 0%, #1a2027 100%)'
          : 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      <Paper
        elevation={24}
        sx={{
          p: 5,
          maxWidth: 450,
          width: "100%",
          mx: 2,
          borderRadius: 4,
          background: (theme) => theme.palette.mode === 'dark'
            ? 'rgba(26, 32, 39, 0.95)'
            : 'rgba(255, 255, 255, 0.95)',
          backdropFilter: 'blur(20px)',
          border: (theme) => `1px solid ${theme.palette.divider}`,
        }}
      >
        <Box sx={{ textAlign: 'center', mb: 4 }}>
          <Box
            sx={{
              width: 70,
              height: 70,
              borderRadius: '20px',
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 20px',
              fontSize: '2rem',
              boxShadow: '0 8px 24px rgba(102, 126, 234, 0.4)',
            }}
          >
            📦
          </Box>
          <Typography
            variant="h4"
            component="h1"
            gutterBottom
            sx={{
              fontWeight: 700,
              background: (theme) => theme.palette.mode === 'dark'
                ? 'linear-gradient(135deg, #90caf9 0%, #f48fb1 100%)'
                : 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}
          >
            Welcome Back
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Sign in to your inventory account
          </Typography>
        </Box>

        <Box component="form" onSubmit={handleSubmit}>
          <TextField
            fullWidth
            label="Email Address"
            name="email"
            type="email"
            value={form.email}
            onChange={handleChange}
            margin="normal"
            required
            autoComplete="email"
            sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }}
          />

          <FormControl fullWidth margin="normal" variant="outlined">
            <InputLabel htmlFor="password">Password</InputLabel>
            <OutlinedInput
              id="password"
              name="password"
              type="password"
              value={form.password}
              onChange={handleChange}
              required
              autoComplete="current-password"
              label="Password"
              sx={{ borderRadius: 2 }}
            />
          </FormControl>

          <Button
            type="submit"
            fullWidth
            variant="contained"
            size="large"
            sx={{
              mt: 4,
              mb: 2,
              py: 1.5,
              borderRadius: 2,
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              boxShadow: '0 4px 20px rgba(102, 126, 234, 0.4)',
              '&:hover': {
                background: 'linear-gradient(135deg, #5568d3 0%, #6a3f8f 100%)',
                transform: 'translateY(-2px)',
              },
            }}
          >
            Sign In
          </Button>

          {message && (
            <Alert severity={message.includes("failed") ? "error" : "success"} sx={{ mt: 2, borderRadius: 2 }}>
              {message}
            </Alert>
          )}
        </Box>
      </Paper>
    </Box>
  );
}
