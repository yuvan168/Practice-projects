import React, { useEffect, useState } from "react";
import { Box, Grid, Card, CardContent, Typography, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, IconButton, Button, Dialog, DialogTitle, DialogContent, DialogActions, TextField, FormControl, InputLabel, Select, MenuItem } from "@mui/material";
import { motion } from "framer-motion";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { Edit, Delete, Add, KeyboardArrowUp, KeyboardArrowDown } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";
import API from "../../api/axios";
import { toast } from "react-toastify";

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

const Dashboard = () => {
  const [stats, setStats] = useState({
    totalProducts: 0,
    lowStockItems: 0,
    totalUsers: 0,
    revenue: 0
  });
  const [products, setProducts] = useState([]);
  const [users, setUsers] = useState([]);
  const [chartData, setChartData] = useState([]);
  const [editingSales, setEditingSales] = useState(null);
  const [editForm, setEditForm] = useState({ name: "", sales: "", revenue: "" });
  const [addSalesForm, setAddSalesForm] = useState({ name: "", sales: "", revenue: "" });
  const [showAddSales, setShowAddSales] = useState(false);
  const [monthSuggestionIndex, setMonthSuggestionIndex] = useState(0);
  const [showMonthSuggestions, setShowMonthSuggestions] = useState(false);
  const [addUserDialogOpen, setAddUserDialogOpen] = useState(false);
  const [addUserForm, setAddUserForm] = useState({ firstName: "", lastName: "", email: "", password: "" });
  const [editUserDialogOpen, setEditUserDialogOpen] = useState(false);
  const [editUserForm, setEditUserForm] = useState({ id: null, firstName: "", lastName: "", email: "" });
  const navigate = useNavigate();

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const productRes = await API.get("/products");
      const productData = productRes.data;
      setProducts(productData);

      let userData = [];
      try {
        const userRes = await API.get("/auth/users");
        userData = userRes.data;
        setUsers(userData);
      } catch (userErr) {
        console.log("Users endpoint not available");
      }

      const lowStock = productData.filter(p => p.quantity < 10).length;
      const calculatedRevenue = productData.reduce((sum, p) => sum + (p.price * p.quantity), 0);

      try {
        const revenueRes = await API.get("/revenue/current");
        setStats({
          totalProducts: productData.length,
          lowStockItems: lowStock,
          totalUsers: userData.length,
          revenue: revenueRes.data.amount
        });
      } catch (revenueErr) {
        try {
          await API.post("/revenue", { amount: calculatedRevenue });
        } catch (postErr) {
          console.log("Could not save revenue");
        }
        setStats({
          totalProducts: productData.length,
          lowStockItems: lowStock,
          totalUsers: userData.length,
          revenue: calculatedRevenue
        });
      }

      try {
        const salesRes = await API.get("/sales");
        setChartData(salesRes.data);
      } catch (salesErr) {
        console.log("Sales endpoint not available, using defaults");
        const defaultData = [
          { name: "Jan", sales: 120 },
          { name: "Feb", sales: 90 },
          { name: "Mar", sales: 140 },
          { name: "Apr", sales: 180 },
        ];
        setChartData(defaultData);
      }
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
      toast.error("Failed to load dashboard data");
    }
  };

  const handleEdit = (id) => {
    navigate(`/products/edit/${id}`);
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this product?")) return;

    try {
      await API.delete(`/products/${id}`);
      toast.success("Product deleted successfully!");
      fetchDashboardData();
    } catch (error) {
      console.error("Error deleting product:", error);
      toast.error("Failed to delete product");
    }
  };

  const handleDeleteUser = async (id) => {
    if (!window.confirm("Are you sure you want to delete this user?")) return;

    try {
      await API.delete(`/auth/users/${id}`);
      toast.success("User deleted successfully!");
      fetchDashboardData();
    } catch (error) {
      console.error("Error deleting user:", error);
      toast.error("Failed to delete user: " + (error.response?.data?.message || error.message));
    }
  };

  const handleEditSales = (item) => {
    setEditingSales(item.id);
    setEditForm({ name: item.name, sales: item.sales, revenue: item.revenue || "" });
  };

  const handleSaveSales = async (id) => {
    try {
      await API.put(`/sales/${id}`, {
        name: editForm.name,
        sales: parseInt(editForm.sales),
        revenue: editForm.revenue ? parseFloat(editForm.revenue) : null
      });
      setEditingSales(null);
      toast.success("Sales data updated successfully!");
      fetchDashboardData();
    } catch (error) {
      console.error("Error updating sales:", error);
      toast.error("Failed to update sales data: " + (error.response?.data?.message || error.message));
    }
  };

  const handleDeleteSales = async (id) => {
    if (!window.confirm("Are you sure you want to delete this sales entry?")) return;

    try {
      await API.delete(`/sales/${id}`);
      toast.success("Sales data deleted successfully!");
      fetchDashboardData();
    } catch (error) {
      console.error("Error deleting sales:", error);
      toast.error("Failed to delete sales data: " + (error.response?.data?.message || error.message));
    }
  };

  const handleCancelEdit = () => {
    setEditingSales(null);
    setEditForm({ name: "", sales: "", revenue: "" });
  };

  const handleAddSales = async () => {
    try {
      await API.post("/sales", {
        name: addSalesForm.name,
        sales: parseInt(addSalesForm.sales),
        revenue: addSalesForm.revenue ? parseFloat(addSalesForm.revenue) : null
      });
      toast.success("Sales data added successfully!");
      setShowAddSales(false);
      setAddSalesForm({ name: "", sales: "", revenue: "" });
      fetchDashboardData();
    } catch (error) {
      console.error("Error adding sales:", error);
      toast.error("Failed to add sales data: " + (error.response?.data?.message || error.message));
    }
  };

  const handleCancelAdd = () => {
    setShowAddSales(false);
    setAddSalesForm({ name: "", sales: "", revenue: "" });
    setMonthSuggestionIndex(0);
  };

  const handleMonthSuggestion = (direction) => {
    const currentIndex = MONTHS.findIndex(m => m === addSalesForm.name);
    let newIndex = direction === "up" ? currentIndex - 1 : currentIndex + 1;
    
    if (newIndex < 0) newIndex = MONTHS.length - 1;
    if (newIndex >= MONTHS.length) newIndex = 0;
    
    setAddSalesForm({ ...addSalesForm, name: MONTHS[newIndex] });
    setMonthSuggestionIndex(newIndex);
  };

  const handleMonthChange = (e) => {
    const value = e.target.value;
    setAddSalesForm({ ...addSalesForm, name: value });
    setShowMonthSuggestions(value.length > 0);
  };

  const getMonthSuggestions = () => {
    if (!addSalesForm.name) return MONTHS;
    return MONTHS.filter(month => 
      month.toLowerCase().startsWith(addSalesForm.name.toLowerCase())
    );
  };

  const handleSelectSuggestion = (month) => {
    setAddSalesForm({ ...addSalesForm, name: month });
    setShowMonthSuggestions(false);
  };

  // Auto-add current month sales when product is added
  const autoAddCurrentMonthSales = async () => {
    try {
      const currentMonth = new Date();
      const monthName = currentMonth.toLocaleString('default', { month: 'short' });
      
      // Check if current month already exists
      const existingSales = chartData.find(s => s.name === monthName);
      if (existingSales) {
        return; // Month already exists
      }

      // Add current month sales
      await API.post("/sales", {
        name: monthName,
        sales: 0,
        revenue: 0
      });
      
      fetchDashboardData();
    } catch (error) {
      console.log("Auto-add sales failed (might already exist):", error.message);
    }
  };

  const handleAddUserClick = () => {
    setAddUserDialogOpen(true);
  };

  const handleAddUserClose = () => {
    setAddUserDialogOpen(false);
    setAddUserForm({ firstName: "", lastName: "", email: "", password: "" });
  };

  const handleAddUserSubmit = async () => {
    try {
      console.log("Adding user from dashboard:", addUserForm);
      await API.post("/auth/users", addUserForm);
      toast.success("User added successfully!");
      handleAddUserClose();
      fetchDashboardData();
    } catch (error) {
      console.error("Error adding user:", error);
      toast.error("Failed to add user: " + (error.response?.data?.message || error.message));
    }
  };

  const handleEditUserClick = (user) => {
    setEditUserForm({ id: user.id, firstName: user.firstName || "", lastName: user.lastName || "", email: user.email || "" });
    setEditUserDialogOpen(true);
  };

  const handleEditUserClose = () => {
    setEditUserDialogOpen(false);
    setEditUserForm({ id: null, firstName: "", lastName: "", email: "" });
  };

  const handleEditUserSubmit = async () => {
    try {
      console.log("Updating user:", editUserForm);
      await API.put(`/auth/users/${editUserForm.id}`, {
        firstName: editUserForm.firstName,
        lastName: editUserForm.lastName,
        email: editUserForm.email
      });
      toast.success("User updated successfully!");
      handleEditUserClose();
      fetchDashboardData();
    } catch (error) {
      console.error("Error updating user:", error);
      toast.error("Failed to update user: " + (error.response?.data?.message || error.message));
    }
  };

  return (
    <Box p={4}>
      <Typography variant="h5" mb={2}>📈 Dashboard Overview</Typography>

      <Grid container spacing={3}>
        {[
          { title: "Total Products", value: stats.totalProducts },
          { title: "Low Stock Items", value: stats.lowStockItems },
          { title: "Users", value: stats.totalUsers },
          { title: "Revenue (₹)", value: `₹${stats.revenue.toLocaleString()}` },
        ].map((item, index) => (
          <Grid item xs={12} sm={6} md={3} key={index}>
            <motion.div whileHover={{ scale: 1.05 }}>
              <Card sx={{ textAlign: "center" }}>
                <CardContent>
                  <Typography variant="h6" color="text.primary">{item.title}</Typography>
                  <Typography variant="h4" color="primary">{item.value}</Typography>
                </CardContent>
              </Card>
            </motion.div>
          </Grid>
        ))}
      </Grid>

      <Box mt={5}>
        <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
          <Typography variant="h6">Sales Trend</Typography>
        </Box>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={chartData}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="sales" fill="#1976d2" />
          </BarChart>
        </ResponsiveContainer>

        <Box sx={{ display: "flex", gap: 2, alignItems: "center", mb: 2, mt: 2 }}>
          <Button
            variant="contained"
            color="success"
            startIcon={<Add />}
            onClick={() => setShowAddSales(true)}
            size="small"
          >
            Add Sales
          </Button>
        </Box>

        <TableContainer component={Paper} sx={{ mt: 3 }}>
          <Table size="small">
            <TableHead>
              <TableRow sx={{ backgroundColor: "#1976d2" }}>
                <TableCell sx={{ color: "white" }}>Month</TableCell>
                <TableCell sx={{ color: "white" }}>Sales</TableCell>
                <TableCell sx={{ color: "white" }}>Revenue (₹)</TableCell>
                <TableCell sx={{ color: "white" }} align="center">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {chartData.map((item) => (
                <TableRow key={item.id} hover>
                  <TableCell>
                    {editingSales === item.id ? (
                      <input
                        type="text"
                        value={editForm.name}
                        onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                        style={{ width: "100%", padding: "8px", fontSize: "14px" }}
                      />
                    ) : (
                      item.name
                    )}
                  </TableCell>
                  <TableCell>
                    {editingSales === item.id ? (
                      <input
                        type="number"
                        value={editForm.sales}
                        onChange={(e) => setEditForm({ ...editForm, sales: e.target.value })}
                        style={{ width: "100%", padding: "8px", fontSize: "14px" }}
                      />
                    ) : (
                      item.sales
                    )}
                  </TableCell>
                  <TableCell>
                    {editingSales === item.id ? (
                      <input
                        type="number"
                        placeholder="Revenue"
                        value={editForm.revenue}
                        onChange={(e) => setEditForm({ ...editForm, revenue: e.target.value })}
                        style={{ width: "100%", padding: "8px", fontSize: "14px" }}
                      />
                    ) : (
                      item.revenue ? `₹${item.revenue.toLocaleString()}` : "N/A"
                    )}
                  </TableCell>
                  <TableCell align="center">
                    {editingSales === item.id ? (
                      <>
                        <IconButton color="success" size="small" onClick={() => handleSaveSales(item.id)}>
                          ✓
                        </IconButton>
                        <IconButton color="error" size="small" onClick={handleCancelEdit}>
                          ✕
                        </IconButton>
                      </>
                    ) : (
                      <>
                        <IconButton color="primary" size="small" onClick={() => handleEditSales(item)}>
                          <Edit />
                        </IconButton>
                        <IconButton color="error" size="small" onClick={() => handleDeleteSales(item.id)}>
                          <Delete />
                        </IconButton>
                      </>
                    )}
                  </TableCell>
                </TableRow>
              ))}
              {showAddSales && (
                <TableRow sx={{ backgroundColor: "#f0f0f0" }}>
                  <TableCell sx={{ position: "relative", verticalAlign: "top", overflow: "visible" }}>
                    <Box sx={{ position: "relative", display: "inline-block" }}>
                      <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                        <IconButton
                          size="small"
                          onClick={() => handleMonthSuggestion("up")}
                          sx={{ padding: "2px" }}
                        >
                          <KeyboardArrowUp fontSize="small" />
                        </IconButton>
                        <input
                          type="text"
                          placeholder="Month"
                          value={addSalesForm.name}
                          onChange={handleMonthChange}
                          onFocus={() => addSalesForm.name && setShowMonthSuggestions(true)}
                          style={{ width: "55px", padding: "6px", fontSize: "13px", textAlign: "center", border: "1px solid #ccc", borderRadius: "4px" }}
                        />
                        <IconButton
                          size="small"
                          onClick={() => handleMonthSuggestion("down")}
                          sx={{ padding: "2px" }}
                        >
                          <KeyboardArrowDown fontSize="small" />
                        </IconButton>
                      </Box>
                      {showMonthSuggestions && getMonthSuggestions().length > 0 && (
                        <Box sx={{ 
                          position: "absolute",
                          top: "110%",
                          left: 0,
                          backgroundColor: "white",
                          border: "1px solid #ccc",
                          borderRadius: "4px",
                          maxHeight: "140px", 
                          overflowY: "auto",
                          zIndex: 1000,
                          width: "100%",
                          boxShadow: "0 2px 8px rgba(0,0,0,0.15)"
                        }}>
                          {getMonthSuggestions().map((month) => (
                            <Box
                              key={month}
                              onClick={() => handleSelectSuggestion(month)}
                              sx={{
                                p: "6px 8px",
                                cursor: "pointer",
                                fontSize: "13px",
                                whiteSpace: "nowrap",
                                "&:hover": { backgroundColor: "#e8f4f8", fontWeight: "500" }
                              }}
                            >
                              {month}
                            </Box>
                          ))}
                        </Box>
                      )}
                    </Box>
                  </TableCell>
                  <TableCell>
                    <input
                      type="number"
                      placeholder="Sales"
                      value={addSalesForm.sales}
                      onChange={(e) => setAddSalesForm({ ...addSalesForm, sales: e.target.value })}
                      style={{ width: "100%", padding: "8px", fontSize: "14px" }}
                    />
                  </TableCell>
                  <TableCell>
                    <input
                      type="number"
                      placeholder="Revenue"
                      value={addSalesForm.revenue}
                      onChange={(e) => setAddSalesForm({ ...addSalesForm, revenue: e.target.value })}
                      style={{ width: "100%", padding: "8px", fontSize: "14px" }}
                    />
                  </TableCell>
                  <TableCell align="center">
                    <IconButton color="success" size="small" onClick={handleAddSales}>
                      ✓
                    </IconButton>
                    <IconButton color="error" size="small" onClick={handleCancelAdd}>
                      ✕
                    </IconButton>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Box>

      <Grid container spacing={3} mt={3}>
        <Grid item xs={12} md={6}>
          <Typography variant="h6" mb={2}>Recent Products</Typography>
          <TableContainer component={Paper}>
            <Table>
              <TableHead>
                <TableRow sx={{ backgroundColor: "#1976d2" }}>
                  <TableCell sx={{ color: "white" }}>ID</TableCell>
                  <TableCell sx={{ color: "white" }}>Name</TableCell>
                  <TableCell sx={{ color: "white" }}>Quantity</TableCell>
                  <TableCell sx={{ color: "white" }}>Price</TableCell>
                  <TableCell sx={{ color: "white" }} align="center">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {products.slice(0, 5).map((product) => (
                  <TableRow key={product.id} hover>
                    <TableCell>{product.id}</TableCell>
                    <TableCell>{product.name}</TableCell>
                    <TableCell>{product.quantity}</TableCell>
                    <TableCell>₹{product.price}</TableCell>
                    <TableCell align="center">
                      <IconButton color="primary" size="small" onClick={() => handleEdit(product.id)}>
                        <Edit />
                      </IconButton>
                      <IconButton color="error" size="small" onClick={() => handleDelete(product.id)}>
                        <Delete />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
                {products.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={5} align="center" sx={{ py: 3, color: "text.secondary" }}>
                      No products found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </Grid>

        <Grid item xs={12} md={6}>
          <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
            <Typography variant="h6">Recent Users</Typography>
          </Box>
          <TableContainer component={Paper}>
            <Table>
              <TableHead>
                <TableRow sx={{ backgroundColor: "#1976d2" }}>
                  <TableCell sx={{ color: "white" }}>ID</TableCell>
                  <TableCell sx={{ color: "white" }}>Name</TableCell>
                  <TableCell sx={{ color: "white" }}>Email</TableCell>
                  <TableCell sx={{ color: "white" }} align="center">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {users.slice(0, 5).map((user) => (
                  <TableRow key={user.id} hover>
                    <TableCell>{user.id}</TableCell>
                    <TableCell>{`${user.firstName || ''} ${user.lastName || ''}`.trim() || 'N/A'}</TableCell>
                    <TableCell>{user.email}</TableCell>
                    <TableCell align="center">
                      <IconButton color="primary" size="small" onClick={() => handleEditUserClick(user)}>
                        <Edit />
                      </IconButton>
                      <IconButton color="error" size="small" onClick={() => handleDeleteUser(user.id)}>
                        <Delete />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
                {users.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={4} align="center" sx={{ py: 3, color: "text.secondary" }}>
                      No users found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </Grid>
      </Grid>

      <Dialog open={addUserDialogOpen} onClose={handleAddUserClose} maxWidth="sm" fullWidth>
        <DialogTitle>Add New User</DialogTitle>
        <DialogContent>
          <TextField
            label="First Name"
            fullWidth
            margin="normal"
            value={addUserForm.firstName}
            onChange={(e) => setAddUserForm({ ...addUserForm, firstName: e.target.value })}
          />
          <TextField
            label="Last Name"
            fullWidth
            margin="normal"
            value={addUserForm.lastName}
            onChange={(e) => setAddUserForm({ ...addUserForm, lastName: e.target.value })}
          />
          <TextField
            label="Email"
            fullWidth
            margin="normal"
            type="email"
            value={addUserForm.email}
            onChange={(e) => setAddUserForm({ ...addUserForm, email: e.target.value })}
          />
          <TextField
            label="Password"
            fullWidth
            margin="normal"
            type="password"
            value={addUserForm.password}
            onChange={(e) => setAddUserForm({ ...addUserForm, password: e.target.value })}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleAddUserClose}>Cancel</Button>
          <Button onClick={handleAddUserSubmit} variant="contained" color="primary">
            Add User
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog open={editUserDialogOpen} onClose={handleEditUserClose} maxWidth="sm" fullWidth>
        <DialogTitle>Edit User</DialogTitle>
        <DialogContent>
          <TextField
            label="First Name"
            fullWidth
            margin="normal"
            value={editUserForm.firstName}
            onChange={(e) => setEditUserForm({ ...editUserForm, firstName: e.target.value })}
          />
          <TextField
            label="Last Name"
            fullWidth
            margin="normal"
            value={editUserForm.lastName}
            onChange={(e) => setEditUserForm({ ...editUserForm, lastName: e.target.value })}
          />
          <TextField
            label="Email"
            fullWidth
            margin="normal"
            type="email"
            value={editUserForm.email}
            onChange={(e) => setEditUserForm({ ...editUserForm, email: e.target.value })}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleEditUserClose}>Cancel</Button>
          <Button onClick={handleEditUserSubmit} variant="contained" color="primary">
            Update User
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Dashboard;
