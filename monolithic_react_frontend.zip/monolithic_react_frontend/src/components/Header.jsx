import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../services/AuthService';

const Header = ({ showAuthNav }) => {
  const { isLoggedIn, logout } = useAuth();

  return (
    <header className="header">
      <nav className="nav">
        <Link to="/" className="nav-link">Products</Link>
        <Link to="/about" className="nav-link">About</Link>
        {!isLoggedIn || showAuthNav ? (
          <>
            <Link to="/login" className="nav-link">Sign In</Link>
            <Link to="/signup" className="nav-link">Register</Link>
          </>
        ) : (
          <button onClick={logout} className="logout-btn">Logout</button>
        )}
      </nav>
    </header>
  );
};

export default Header;
