import React, { useState, useEffect, useContext } from "react";
import { AppBar, Toolbar, Typography, IconButton, Menu, MenuItem, Box, Divider } from "@mui/material";
import { Logout, AccountCircle, Settings as SettingsIcon } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../Context/AuthContext";
import API from "../api/axios";

const Navbar = () => {
  const [anchorEl, setAnchorEl] = useState(null);
  const { user } = useContext(AuthContext);
  const navigate = useNavigate();
  const open = Boolean(anchorEl);

  const [userProfile, setUserProfile] = useState({ name: "Loading...", email: "" });

  useEffect(() => {
    loadProfile();
  }, []);

  const loadProfile = () => {
    const saved = localStorage.getItem("userProfile");
    console.log("=== NAVBAR DEBUG ===");
    console.log("1. localStorage userProfile:", saved);

    if (saved && saved !== "undefined") {
      try {
        const parsed = JSON.parse(saved);
        console.log("2. Parsed profile:", parsed);
        if (parsed && parsed.email) {
          setUserProfile(parsed);
          console.log("3. Profile set from localStorage");
          return;
        }
      } catch (e) {
        console.error("Error parsing saved profile:", e);
      }
    }

    console.log("4. AuthContext user:", user);
    if (user && user.email) {
      const profile = {
        name: `${user.firstName || ""} ${user.lastName || ""}`.trim() || user.email,
        email: user.email
      };
      console.log("5. Profile set from AuthContext:", profile);
      setUserProfile(profile);
      localStorage.setItem("userProfile", JSON.stringify(profile));
      return;
    }

    console.log("6. Attempting to fetch from API...");
    fetchUserProfile();
  };

  const fetchUserProfile = async () => {
    try {
      const res = await API.get("/auth/profile");
      console.log("7. API response:", res.data);

      const profile = {
        name: `${res.data.firstName || ""} ${res.data.lastName || ""}`.trim() || res.data.email || "User",
        email: res.data.email || ""
      };
      console.log("8. Setting profile from API:", profile);
      setUserProfile(profile);
      localStorage.setItem("userProfile", JSON.stringify(profile));
    } catch (error) {
      console.error("9. API Error:", error.response?.status, error.response?.data);
      setUserProfile({ name: "User", email: "" });
    }
  };

  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    localStorage.removeItem("userProfile");
    window.location.href = "/login";
  };

  const handleSettings = () => {
    handleMenuClose();
    navigate("/settings");
  };

  return (
    <AppBar
      position="sticky"
      elevation={0}
      sx={{
        background: (theme) => theme.palette.mode === 'dark'
          ? 'linear-gradient(135deg, #1a2027 0%, #2d3748 100%)'
          : 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        backdropFilter: 'blur(10px)',
        borderBottom: (theme) => `1px solid ${theme.palette.divider}`,
      }}
    >
      <Toolbar sx={{ justifyContent: "space-between", py: 1 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <Box
            sx={{
              width: 40,
              height: 40,
              borderRadius: '12px',
              background: 'rgba(255,255,255,0.2)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontWeight: 'bold',
              fontSize: '1.2rem',
            }}
          >
            📦
          </Box>
          <Typography
            variant="h6"
            sx={{
              fontWeight: 700,
              letterSpacing: '-0.5px',
              background: 'linear-gradient(45deg, #fff 30%, rgba(255,255,255,0.8) 90%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}
          >
            Inventory Manager
          </Typography>
        </Box>
        <div>
          <IconButton
            color="inherit"
            onClick={handleMenuOpen}
            aria-controls={open ? 'profile-menu' : undefined}
            aria-haspopup="true"
            aria-expanded={open ? 'true' : undefined}
            sx={{
              border: '2px solid rgba(255,255,255,0.2)',
              '&:hover': {
                background: 'rgba(255,255,255,0.1)',
                transform: 'scale(1.05)',
                transition: 'all 0.3s ease',
              },
            }}
          >
            <AccountCircle sx={{ fontSize: 28 }} />
          </IconButton>
          <Menu
            id="profile-menu"
            anchorEl={anchorEl}
            open={open}
            onClose={handleMenuClose}
            transformOrigin={{ horizontal: 'right', vertical: 'top' }}
            anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
            PaperProps={{
              elevation: 8,
              sx: {
                minWidth: 280,
                mt: 1.5,
                borderRadius: 3,
                overflow: 'hidden',
              }
            }}
          >
            <Box
              sx={{
                px: 3,
                py: 2.5,
                background: (theme) => theme.palette.mode === 'dark'
                  ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
                  : 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              }}
            >
              <Typography variant="subtitle1" fontWeight="bold" sx={{ color: 'white' }}>
                {userProfile.name || "Guest"}
              </Typography>
              <Typography variant="body2" sx={{ color: 'rgba(255,255,255,0.9)', mt: 0.5 }}>
                {userProfile.email || "No email set"}
              </Typography>
            </Box>
            <MenuItem
              onClick={handleSettings}
              sx={{
                py: 1.5,
                px: 3,
                '&:hover': {
                  background: (theme) => theme.palette.mode === 'dark'
                    ? 'rgba(144, 202, 249, 0.1)'
                    : 'rgba(102, 126, 234, 0.1)',
                },
              }}
            >
              <SettingsIcon sx={{ mr: 2, color: 'primary.main' }} />
              <Typography>Settings</Typography>
            </MenuItem>
            <Divider sx={{ my: 0.5 }} />
            <MenuItem
              onClick={handleLogout}
              sx={{
                py: 1.5,
                px: 3,
                color: 'error.main',
                '&:hover': {
                  background: (theme) => theme.palette.mode === 'dark'
                    ? 'rgba(244, 67, 54, 0.1)'
                    : 'rgba(211, 47, 47, 0.1)',
                },
              }}
            >
              <Logout sx={{ mr: 2 }} />
              <Typography>Logout</Typography>
            </MenuItem>
          </Menu>
        </div>
      </Toolbar>
    </AppBar>
  );
};

export default Navbar;
