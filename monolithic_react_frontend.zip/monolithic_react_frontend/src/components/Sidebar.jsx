import React from "react";
import { Drawer, List, ListItemButton, ListItemIcon, ListItemText, Box, Typography } from "@mui/material";
import { Dashboard, Inventory, People, BarChart, Settings } from "@mui/icons-material";
import { Link, useLocation } from "react-router-dom";

const Sidebar = () => {
  const location = useLocation();

  const menuItems = [
    { text: "Dashboard", icon: <Dashboard />, path: "/dashboard" },
    { text: "Products", icon: <Inventory />, path: "/products" },
    { text: "Users", icon: <People />, path: "/users" },
    { text: "Reports", icon: <BarChart />, path: "/reports" },
    { text: "Settings", icon: <Settings />, path: "/settings" },
  ];

  return (
    <Drawer
      variant="permanent"
      sx={{
        width: 260,
        flexShrink: 0,
        "& .MuiDrawer-paper": {
          width: 260,
          boxSizing: "border-box",
          background: (theme) => theme.palette.mode === 'dark'
            ? 'linear-gradient(180deg, #1a2027 0%, #13191f 100%)'
            : 'linear-gradient(180deg, #ffffff 0%, #f5f7fa 100%)',
          borderRight: (theme) => `1px solid ${theme.palette.divider}`,
          pt: 2,
        }
      }}
    >
      <Box sx={{ px: 3, mb: 3 }}>
        <Typography
          variant="h6"
          sx={{
            fontWeight: 700,
            color: 'text.primary',
            mb: 0.5,
          }}
        >
          Navigation
        </Typography>
        <Typography
          variant="caption"
          sx={{ color: 'text.secondary' }}
        >
          Manage your inventory
        </Typography>
      </Box>

      <List sx={{ px: 2 }}>
        {menuItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <ListItemButton
              key={item.text}
              component={Link}
              to={item.path}
              sx={{
                mb: 1,
                borderRadius: 2,
                py: 1.5,
                background: isActive
                  ? (theme) => theme.palette.mode === 'dark'
                    ? 'linear-gradient(135deg, rgba(144, 202, 249, 0.15) 0%, rgba(102, 126, 234, 0.15) 100%)'
                    : 'linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%)'
                  : 'transparent',
                border: isActive
                  ? (theme) => `1px solid ${theme.palette.primary.main}`
                  : '1px solid transparent',
                '&:hover': {
                  background: (theme) => theme.palette.mode === 'dark'
                    ? 'rgba(144, 202, 249, 0.08)'
                    : 'rgba(102, 126, 234, 0.05)',
                  transform: 'translateX(4px)',
                  transition: 'all 0.3s ease',
                },
                transition: 'all 0.3s ease',
              }}
            >
              <ListItemIcon
                sx={{
                  color: isActive ? 'primary.main' : 'text.secondary',
                  minWidth: 40,
                }}
              >
                {item.icon}
              </ListItemIcon>
              <ListItemText
                primary={item.text}
                primaryTypographyProps={{
                  fontWeight: isActive ? 600 : 400,
                  color: isActive ? 'primary.main' : 'text.primary',
                }}
              />
            </ListItemButton>
          );
        })}
      </List>

      <Box
        sx={{
          position: 'absolute',
          bottom: 20,
          left: 20,
          right: 20,
          p: 2,
          borderRadius: 2,
          background: (theme) => theme.palette.mode === 'dark'
            ? 'rgba(144, 202, 249, 0.05)'
            : 'rgba(102, 126, 234, 0.05)',
          border: (theme) => `1px solid ${theme.palette.divider}`,
        }}
      >
        <Typography variant="caption" sx={{ color: 'text.secondary', display: 'block' }}>
          Version 1.0.0
        </Typography>
        <Typography variant="caption" sx={{ color: 'text.secondary' }}>
          © 2025 Inventory Manager
        </Typography>
      </Box>
    </Drawer>
  );
};

export default Sidebar;
