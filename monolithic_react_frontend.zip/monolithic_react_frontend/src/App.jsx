import React, { useState, useEffect, createContext } from "react";
import AppRoutes from "./Routes/AppRoutes";
import { ThemeProvider, createTheme, CssBaseline } from "@mui/material";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { BrowserRouter } from "react-router-dom";
import { AuthProvider } from "./Context/AuthContext";

export const ThemeContext = createContext();

function App() {
  const [darkMode, setDarkMode] = useState(() => {
    const saved = localStorage.getItem("darkMode");
    return saved ? JSON.parse(saved) : false;
  });

  useEffect(() => {
    localStorage.setItem("darkMode", JSON.stringify(darkMode));
  }, [darkMode]);

  // Ensure full screen display
  useEffect(() => {
    document.body.style.margin = '0';
    document.body.style.padding = '0';
    document.documentElement.style.margin = '0';
    document.documentElement.style.padding = '0';
    document.body.style.overflow = 'hidden';
    document.body.style.width = '100%';
    document.body.style.height = '100%';
  }, []);

  const theme = createTheme({
    palette: {
      mode: darkMode ? "dark" : "light",
      primary: {
        main: darkMode ? "#90caf9" : "#1976d2",
        light: darkMode ? "#e3f2fd" : "#42a5f5",
        dark: darkMode ? "#42a5f5" : "#1565c0",
      },
      secondary: {
        main: darkMode ? "#f48fb1" : "#dc004e",
        light: darkMode ? "#fce4ec" : "#e91e63",
        dark: darkMode ? "#c2185b" : "#c51162",
      },
      success: {
        main: darkMode ? "#66bb6a" : "#2e7d32",
      },
      warning: {
        main: darkMode ? "#ffa726" : "#ed6c02",
      },
      error: {
        main: darkMode ? "#f44336" : "#d32f2f",
      },
      background: {
        default: darkMode ? "#0a1929" : "#f5f7fa",
        paper: darkMode ? "#1a2027" : "#ffffff",
      },
      text: {
        primary: darkMode ? "#ffffff" : "#1a2027",
        secondary: darkMode ? "#b2bac2" : "#5f6c7b",
      },
    },
    typography: {
      fontFamily: '"Inter", "Roboto", "Helvetica", "Arial", sans-serif',
      h4: {
        fontWeight: 700,
        fontSize: "2rem",
      },
      h5: {
        fontWeight: 600,
        fontSize: "1.5rem",
      },
      h6: {
        fontWeight: 600,
        fontSize: "1.25rem",
      },
      button: {
        textTransform: "none",
        fontWeight: 600,
      },
    },
    shape: {
      borderRadius: 12,
    },
    shadows: [
      'none',
      darkMode ? '0px 2px 4px rgba(0,0,0,0.5)' : '0px 2px 4px rgba(0,0,0,0.1)',
      darkMode ? '0px 4px 8px rgba(0,0,0,0.5)' : '0px 4px 8px rgba(0,0,0,0.1)',
      darkMode ? '0px 8px 16px rgba(0,0,0,0.5)' : '0px 8px 16px rgba(0,0,0,0.1)',
      darkMode ? '0px 12px 24px rgba(0,0,0,0.5)' : '0px 12px 24px rgba(0,0,0,0.1)',
      ...Array(20).fill(darkMode ? '0px 16px 32px rgba(0,0,0,0.5)' : '0px 16px 32px rgba(0,0,0,0.1)'),
    ],
    components: {
      MuiButton: {
        styleOverrides: {
          root: {
            borderRadius: 8,
            padding: '10px 24px',
            boxShadow: 'none',
            '&:hover': {
              boxShadow: darkMode ? '0 4px 12px rgba(144, 202, 249, 0.3)' : '0 4px 12px rgba(25, 118, 210, 0.2)',
              transform: 'translateY(-2px)',
              transition: 'all 0.3s ease',
            },
          },
        },
      },
      MuiPaper: {
        styleOverrides: {
          root: {
            backgroundImage: 'none',
          },
        },
      },
      MuiCard: {
        styleOverrides: {
          root: {
            borderRadius: 16,
            boxShadow: darkMode ? '0 4px 20px rgba(0,0,0,0.5)' : '0 4px 20px rgba(0,0,0,0.08)',
          },
        },
      },
    },
  });

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  return (
    <div style={{ width: '100vw', height: '100vh', margin: 0, padding: 0, overflow: 'hidden' }}>
      <BrowserRouter>
        <AuthProvider>
          <ThemeContext.Provider value={{ darkMode, toggleDarkMode }}>
            <ThemeProvider theme={theme}>
              <CssBaseline />
              <AppRoutes />
              <ToastContainer position="bottom-right" autoClose={2000} theme={darkMode ? "dark" : "light"} />
            </ThemeProvider>
          </ThemeContext.Provider>
        </AuthProvider>
      </BrowserRouter>
    </div>
  );
}

export default App;
