import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:8088/api",
  headers: {
    "Content-Type": "application/json",
  },
  timeout: 10000,
});

// Automatically attach JWT token if present
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("token");
    if (token) {
      config.headers["Authorization"] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Add response interceptor for better error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.code === 'ERR_NETWORK' || error.message === 'Network Error') {
      console.error('🔴 BACKEND NOT REACHABLE!');
      console.error('Make sure Spring Boot backend is running on http://localhost:8088');
      error.message = 'Backend server is not running. Please start Spring Boot application.';
    }
    return Promise.reject(error);
  }
);

export default api;
