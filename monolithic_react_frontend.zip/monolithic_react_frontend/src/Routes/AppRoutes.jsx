import { Routes, Route, Navigate } from "react-router-dom";
import Dashboard from "../Pages/Dashboard/Dashboard";
import ProductList from "../Pages/Product/ProductList";
import UserList from "../Pages/Users/UserList";
import Reports from "../Pages/Reports/Reports";
import Settings from "../Pages/Settings/Settings";
import Login from "../Pages/Auth/Login";
import Register from "../Pages/Auth/Register";
import Navbar from "../components/Navbar";
import Sidebar from "../components/Sidebar";
import ProtectedRoute from "../components/ProtectedRoute";
import AddProduct from "../Pages/Product/AddProduct";
import EditProduct from "../Pages/Product/EditProduct";

export default function AppRoutes() {
  return (
    <div style={{ display: "flex", height: "100vh", width: "100%", margin: 0, padding: 0 }}>
      <Sidebar />

      <div style={{ flex: 1, display: "flex", flexDirection: "column", height: "100vh", overflow: "hidden" }}>
        <Navbar />
        <div style={{ padding: "20px", flex: 1, overflowY: "auto", overflowX: "hidden", width: "100%" }}>
          <Routes>
            <Route path="/" element={<Navigate to="/dashboard" />} />

            <Route
              path="/dashboard"
              element={
                <ProtectedRoute>
                  <Dashboard />
                </ProtectedRoute>
              }
            />
            <Route
              path="/products"
              element={
                <ProtectedRoute>
                  <ProductList />
                </ProtectedRoute>
              }
            />
            <Route
              path="/users"
              element={
                <ProtectedRoute>
                  <UserList />
                </ProtectedRoute>
              }
            />
            <Route
              path="/reports"
              element={
                <ProtectedRoute>
                  <Reports />
                </ProtectedRoute>
              }
            />
            <Route
              path="/settings"
              element={
                <ProtectedRoute>
                  <Settings />
                </ProtectedRoute>
              }
            />
            <Route
              path="/products/add"
              element={
                <ProtectedRoute>
                  <AddProduct />
                </ProtectedRoute>
              }
            />

            <Route
              path="/products/edit/:id"
              element={
                <ProtectedRoute>
                  <EditProduct />
                </ProtectedRoute>
              }
            />

            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Register />} />
          </Routes>
        </div>
      </div>
    </div>
  );
}
