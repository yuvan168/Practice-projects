import axios from "axios";

const API_BASE = "http://localhost:8088/api";

const getToken = () => localStorage.getItem("token");

const api = axios.create({
  baseURL: API_BASE,
});

api.interceptors.request.use((config) => {
  const token = getToken();
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default {
  getAllProducts: () => api.get("/products").then((res) => res.data),
  getProduct: (id) => api.get(`/products/${id}`).then((res) => res.data),
  addProduct: (product) => api.post("/products", product).then((res) => res.data),
  updateProduct: (id, product) =>
    api.put(`/products/${id}`, product).then((res) => res.data),
  deleteProduct: (id) => api.delete(`/products/${id}`),

  register: (user) => api.post("/auth/signup", user).then((res) => res.data),
  login: (credentials) =>
    api.post("/auth/login", credentials).then((res) => res.data),
};
