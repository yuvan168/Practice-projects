# Login Troubleshooting Guide

## 🔴 Cannot Login - Solutions

### **Issue: "Invalid credentials" or Login Fails**

---

## ✅ Step 1: Verify Backend is Running

### Check if Backend is Running
```bash
# Open browser and try
http://localhost:8088/api/auth/login
```

**Expected Result**: You should see a 404 or CORS error (NOT a connection refused)

**If Connection Refused**: Backend is NOT running

### Start Backend
```bash
cd path/to/spring-boot-backend
mvn spring-boot:run
```

**Wait for Message**:
```
Started InventoryManagementApplication in X seconds
```

---

## ✅ Step 2: Verify Database Setup

### Check Database Connection

**Test Credentials**:
- Email: `test@test.com`
- Password: `password123`

### If Users Don't Exist - Create Them

**Option A: Database Insert**
```sql
-- Connect to MySQL
mysql -h localhost -u root -p inventory_db

-- Check if users exist
SELECT * FROM users WHERE email = 'test@test.com';

-- If empty, insert test user (password: password123)
INSERT INTO users (email, password, first_name, last_name) 
VALUES ('test@test.com', '$2a$10$N9qo8uLOickgx2ZMRZoMYeIjZAgcg7b3XeKeJklskHwpIGcE1RJgi', 'Test', 'User');

-- Assign role
INSERT INTO user_roles (user_id, role_id) 
SELECT id, 1 FROM users WHERE email = 'test@test.com';
```

**Option B: Use Register Page**
1. Go to `http://localhost:3000/signup`
2. Register new user
3. Use that account to login

---

## ✅ Step 3: Network Debugging

### Check Frontend Configuration

**File**: `src/api/axios.js`

Verify Base URL:
```javascript
const api = axios.create({
  baseURL: "http://localhost:8088/api",  // Should be this
  headers: {
    "Content-Type": "application/json",
  },
  timeout: 10000,
});
```

If backend is on different port, change this URL.

### Browser Console Logs

1. Open Browser DevTools (F12)
2. Go to Console tab
3. Go to Login page
4. Try to login
5. Check for error messages

**Look for**:
```
Login response: { token: "...", email: "...", firstName: "...", lastName: "..." }
```

OR

```
Login error: { message: "Invalid credentials" }
```

### Network Tab Debugging

1. Open Browser DevTools (F12)
2. Go to Network tab
3. Try to login
4. Click on the POST request to `/api/auth/login`
5. Check Response tab
6. Check Status code (should be 200 for success, 401 for invalid credentials)

**Response Examples**:

**Success (200)**:
```json
{
  "token": "eyJhbGciOiJIUzUxMiJ9...",
  "email": "test@test.com",
  "firstName": "Test",
  "lastName": "User"
}
```

**Error (401)**:
```json
{
  "message": "Invalid credentials"
}
```

**Error (403 CORS)**:
```
CORS policy: No 'Access-Control-Allow-Origin' header
```

---

## ✅ Step 4: Fix Common Issues

### Issue 1: CORS Error
```
Access to XMLHttpRequest blocked by CORS policy
```

**Solution**: Update Spring Boot SecurityConfig
```java
configuration.setAllowedOrigins(Arrays.asList("http://localhost:3000"));
```

Restart backend after change.

### Issue 2: Invalid Credentials
```json
{ "message": "Invalid credentials" }
```

**Solutions**:
1. Check user exists in database: `SELECT * FROM users;`
2. Verify password is BCrypt encoded
3. Password is case-sensitive
4. Check email spelling (including case)

### Issue 3: Backend Not Found
```
Backend server is not running. Please start Spring Boot application.
```

**Solution**:
```bash
mvn spring-boot:run
# Wait for startup to complete
```

### Issue 4: Database Connection Failed
```
Error connecting to database
```

**Check MySQL**:
```bash
# Start MySQL
mysql.server start  # macOS
net start MySQL     # Windows
# Or use MySQL Workbench
```

**Check Credentials in application.properties**:
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/inventory_db
spring.datasource.username=root
spring.datasource.password=yuvan
```

---

## ✅ Complete Login Checklist

- [ ] MySQL running
- [ ] Database `inventory_db` created
- [ ] Spring Boot backend started (`mvn spring-boot:run`)
- [ ] Backend console shows "Started InventoryManagementApplication"
- [ ] Browser can access `http://localhost:8088/api/auth/login` (no error)
- [ ] Test user exists in database
- [ ] Password is correct (case-sensitive)
- [ ] Frontend running (`npm run dev`)
- [ ] Frontend on `http://localhost:3000`
- [ ] No CORS errors in browser console
- [ ] Network tab shows 200 response

---

## 🔍 Testing Login Step-by-Step

### **Step 1: Start Everything**
```bash
# Terminal 1: Start MySQL
mysql.server start

# Terminal 2: Start Backend
cd spring-boot-backend
mvn spring-boot:run

# Terminal 3: Start Frontend
cd react-frontend
npm run dev
```

### **Step 2: Create Test User**
```bash
# Connect to MySQL
mysql -u root -p inventory_db

# Insert test user
INSERT INTO users (email, password, first_name, last_name) 
VALUES ('test@test.com', '$2a$10$N9qo8uLOickgx2ZMRZoMYeIjZAgcg7b3XeKeJklskHwpIGcE1RJgi', 'Test', 'User');

INSERT INTO user_roles (user_id, role_id) 
SELECT id, 1 FROM users WHERE email = 'test@test.com';
```

### **Step 3: Test Login**
1. Go to `http://localhost:3000`
2. Enter email: `test@test.com`
3. Enter password: `password123`
4. Click "Sign In"
5. Should redirect to Dashboard

### **Step 4: Check Browser Console**
If login fails, check console (F12) for error message.

---

## 🔐 Generate BCrypt Password Hash

### Online Generator
Visit: https://bcrypt-generator.com/
- Enter password: `password123`
- Cost: 10
- Generate hash

### Using Java
```java
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class Main {
    public static void main(String[] args) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        String hash = encoder.encode("password123");
        System.out.println(hash);
        // Output: $2a$10$N9qo8uLOickgx2ZMRZoMYeIjZAgcg7b3XeKeJklskHwpIGcE1RJgi
    }
}
```

### Using Python
```python
import bcrypt
password = "password123"
hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
print(hashed.decode())
```

---

## 📋 Login Request/Response Details

### **Request Format**
```bash
curl -X POST http://localhost:8088/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@test.com",
    "password": "password123"
  }'
```

### **Success Response (200)**
```json
{
  "token": "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJ0ZXN0QHRlc3QuY29tIiwiaWF0IjoxNzAyNjM5ODc2LCJleHAiOjE3MDI3MjYyNzZ9.abc123xyz",
  "email": "test@test.com",
  "firstName": "Test",
  "lastName": "User"
}
```

### **Error Response (401)**
```json
{
  "message": "Invalid credentials"
}
```

---

## 🆘 Still Can't Login?

### Enable Debug Logging

**Backend** - Update `application.properties`:
```properties
logging.level.com.example.demo.controller=DEBUG
logging.level.org.springframework.security=DEBUG
logging.level.org.springframework.web.cors=DEBUG
```

**Frontend** - Check browser console (F12 > Console tab)

### Restart Everything
```bash
# Stop all services
# Kill Maven, stop MySQL, stop dev server

# Start MySQL
mysql.server start

# Start Backend (fresh)
mvn clean && mvn spring-boot:run

# Start Frontend (fresh)
npm run dev
```

### Contact Backend API Directly
Use Postman or curl to test backend:
```bash
curl -X POST http://localhost:8088/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@test.com","password":"password123"}' \
  -v
```

Check the response status code and body.

---

## ✅ Success Indicators

**When login works**:
- ✅ No errors in browser console
- ✅ Network tab shows 200 response
- ✅ Redirects to Dashboard
- ✅ Navbar shows user name
- ✅ Can navigate all pages

---

## 📊 Quick Reference

| Issue | Solution |
|-------|----------|
| Backend not running | `mvn spring-boot:run` |
| MySQL not running | `mysql.server start` |
| CORS error | Check `spring.datasource.url` in SecurityConfig |
| Invalid credentials | Check user exists, password is BCrypt |
| Network error | Verify `localhost:8088/api` is accessible |
| User not found | Create via Register page or SQL insert |

---

**Need Help?** Follow the complete checklist above and check browser console logs.
