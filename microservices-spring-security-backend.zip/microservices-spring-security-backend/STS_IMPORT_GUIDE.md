# STS Import Guide

## How to Import Projects into Spring Tool Suite (STS)

### Step 1: Open STS
Launch Spring Tool Suite on your Windows machine.

### Step 2: Import All Services

1. Go to **File** → **Import**

2. In the Import dialog, select **Maven** → **Existing Maven Projects**

3. Click **Next**

4. Click **Browse** and navigate to: `C:\microservices-backend\eureka-server`

5. Select the folder and click **Finish**

Repeat steps 2-5 for each service:
- eureka-server
- config-server
- api-gateway
- user-service
- product-service
- sales-service

### Step 3: Maven Clean Build

After importing all projects:

1. Right-click on each project
2. Select **Maven** → **Update Project**
3. Click **OK**

This will download all dependencies.

### Step 4: Configure Runtime

1. Go to **Window** → **Preferences**
2. Navigate to **Java** → **Installed JREs**
3. Ensure **JDK 17+** is installed and selected
4. Click **Apply and Close**

### Step 5: Run Services

For each service:

1. Right-click the project
2. Select **Run As** → **Spring Boot App**

Or use **Run** → **Run Configurations** to create custom run configurations.

## Expected Console Output

When services start successfully, you should see:
```
2024-xx-xx ... Started EurekaServerApplication in x.xxx seconds
2024-xx-xx ... Started ConfigServerApplication in x.xxx seconds
2024-xx-xx ... Started ApiGatewayApplication in x.xxx seconds
2024-xx-xx ... Started UserServiceApplication in x.xxx seconds
2024-xx-xx ... Started ProductServiceApplication in x.xxx seconds
2024-xx-xx ... Started SalesServiceApplication in x.xxx seconds
```

## Verify Services

### Eureka Dashboard
Open browser: `http://localhost:8761`

You should see all 3 microservices registered:
- USER-SERVICE
- PRODUCT-SERVICE
- SALES-SERVICE

## File Structure After Import

After importing into STS, you'll see in Project Explorer:

```
eureka-server (folder)
├── src
├── target
├── pom.xml
├── .classpath
├── .project
└── .settings

config-server (folder)
├── src
├── target
├── pom.xml
├── .classpath
├── .project
└── .settings

api-gateway (folder)
[Similar structure]

user-service (folder)
[Similar structure]

product-service (folder)
[Similar structure]

sales-service (folder)
[Similar structure]
```

## Common Issues & Solutions

### Issue: Projects not showing up after import
**Solution**: 
1. Go to **Project** → **Build All**
2. If still not visible, try **File** → **Refresh** (F5)

### Issue: Maven build errors
**Solution**:
1. Right-click project → **Maven** → **Update Project**
2. Or: Delete `target` folder and rebuild

### Issue: Cannot find JDK 17
**Solution**:
1. Download JDK 17 from Oracle website
2. Install and configure in STS preferences
3. Restart STS

### Issue: Port already in use
**Solution**: Check if another app is using the port or change port in application.yml/properties

### Issue: Database connection errors
**Solution**:
1. Verify MySQL is running
2. Create required databases
3. Check username/password in configuration files

## Run All Services Script

Create a batch file `start-all.bat` in `microservices-backend` folder:

```batch
@echo off
echo Starting Microservices...

start cmd /k "cd eureka-server && mvn spring-boot:run"
timeout /t 10
start cmd /k "cd config-server && mvn spring-boot:run"
timeout /t 5
start cmd /k "cd api-gateway && mvn spring-boot:run"
timeout /t 5
start cmd /k "cd user-service && mvn spring-boot:run"
timeout /t 5
start cmd /k "cd product-service && mvn spring-boot:run"
timeout /t 5
start cmd /k "cd sales-service && mvn spring-boot:run"

echo All services started!
```

Run with: `start-all.bat`

## Next Steps

1. Import all 6 projects into STS
2. Update database credentials in each service
3. Create MySQL databases
4. Run services in order (Eureka → Config → Gateway → Others)
5. Verify on Eureka dashboard
6. Test API endpoints

## Useful STS Shortcuts

- `Ctrl + F11` - Run last launched
- `Alt + Shift + X, B` - Run as Maven build
- `Ctrl + H` - Search and Replace
- `Ctrl + Shift + O` - Organize Imports
- `Ctrl + Space` - Content Assist

Happy coding! 🚀
