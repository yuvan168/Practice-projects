-- ============================================
-- Database Setup Script for Microservices
-- ============================================
-- Run this script in MySQL to create all required databases and tables

-- ============================================
-- CREATE DATABASES
-- ============================================

CREATE DATABASE IF NOT EXISTS userdb;
CREATE DATABASE IF NOT EXISTS productdb;
CREATE DATABASE IF NOT EXISTS salesdb;

USE userdb;

-- ============================================
-- USER DATABASE TABLES
-- ============================================

CREATE TABLE IF NOT EXISTS user (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    location VARCHAR(255),
    mobile_number VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create indexes for better query performance
CREATE INDEX idx_email ON user(email);

-- ============================================

USE productdb;

-- ============================================
-- PRODUCT DATABASE TABLES
-- ============================================

CREATE TABLE IF NOT EXISTS products (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description LONGTEXT,
    manufacturer VARCHAR(255),
    price DOUBLE NOT NULL CHECK (price > 0),
    quantity INT NOT NULL DEFAULT 0 CHECK (quantity >= 0),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create indexes for better query performance
CREATE INDEX idx_name ON products(name);
CREATE INDEX idx_manufacturer ON products(manufacturer);

-- ============================================

USE salesdb;

-- ============================================
-- SALES DATABASE TABLES
-- ============================================

CREATE TABLE IF NOT EXISTS sales (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    product_id BIGINT NOT NULL,
    product_name VARCHAR(255) NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0),
    unit_price DOUBLE NOT NULL CHECK (unit_price > 0),
    total_price DOUBLE NOT NULL CHECK (total_price > 0),
    sale_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    customer_name VARCHAR(255),
    customer_email VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create indexes for better query performance
CREATE INDEX idx_product_id ON sales(product_id);
CREATE INDEX idx_sale_date ON sales(sale_date);
CREATE INDEX idx_customer_email ON sales(customer_email);

-- ============================================
-- SAMPLE DATA (Optional)
-- ============================================

-- Insert sample users
USE userdb;

INSERT INTO user (email, password, first_name, last_name, location, mobile_number) VALUES
('admin@example.com', '$2a$10$slYQmyNdGzin7olVN3p5Be7DlH.PKZbv5H8KnzzVgXXbVxzy990qm', 'Admin', 'User', 'New York', '1234567890'),
('john.doe@example.com', '$2a$10$slYQmyNdGzin7olVN3p5Be7DlH.PKZbv5H8KnzzVgXXbVxzy990qm', 'John', 'Doe', 'Los Angeles', '9876543210'),
('jane.smith@example.com', '$2a$10$slYQmyNdGzin7olVN3p5Be7DlH.PKZbv5H8KnzzVgXXbVxzy990qm', 'Jane', 'Smith', 'Chicago', '5555555555');

-- Insert sample products
USE productdb;

INSERT INTO products (name, description, manufacturer, price, quantity) VALUES
('Laptop', 'High performance gaming laptop with 16GB RAM', 'Dell', 1299.99, 50),
('Mouse', 'Wireless ergonomic mouse', 'Logitech', 29.99, 200),
('Keyboard', 'Mechanical gaming keyboard with RGB lighting', 'Corsair', 149.99, 100),
('Monitor', '27-inch 4K display monitor', 'LG', 499.99, 30),
('Headphones', 'Noise-cancelling wireless headphones', 'Sony', 349.99, 75),
('USB-C Cable', '10ft USB-C charging cable', 'Anker', 9.99, 500);

-- ============================================
-- VERIFY DATA
-- ============================================

-- Verify users
SELECT COUNT(*) as 'Total Users' FROM userdb.user;

-- Verify products
SELECT COUNT(*) as 'Total Products' FROM productdb.products;

-- Verify sales (initially empty)
SELECT COUNT(*) as 'Total Sales' FROM salesdb.sales;

-- ============================================
-- SAMPLE QUERIES FOR TESTING
-- ============================================

-- Get all users
-- SELECT * FROM userdb.user;

-- Get all products
-- SELECT * FROM productdb.products WHERE quantity > 0;

-- Get top 5 products by quantity
-- SELECT * FROM productdb.products ORDER BY quantity DESC LIMIT 5;

-- Get sales by date range (after sales are created)
-- SELECT * FROM salesdb.sales WHERE sale_date BETWEEN '2024-01-01' AND '2024-12-31';

-- Get total revenue
-- SELECT SUM(total_price) as 'Total Revenue' FROM salesdb.sales;

-- Get sales by product
-- SELECT product_name, SUM(quantity) as 'Units Sold', SUM(total_price) as 'Revenue' 
-- FROM salesdb.sales GROUP BY product_name ORDER BY Revenue DESC;
