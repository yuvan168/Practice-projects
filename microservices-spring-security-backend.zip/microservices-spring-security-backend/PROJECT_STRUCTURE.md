# Project Directory Structure

Complete backend microservices project structure for STS import.

```
C:/microservices-backend/
│
├── eureka-server/
│   ├── pom.xml
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/
│   │   │   │   └── com/example/demo/
│   │   │   │       └── EurekaServerApplication.java
│   │   │   └── resources/
│   │   │       └── application.yml
│   │   └── test/
│   └── target/
│
├── config-server/
│   ├── pom.xml
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/
│   │   │   │   └── com/example/demo/
│   │   │   │       └── ConfigServerApplication.java
│   │   │   └── resources/
│   │   │       └── application.yml
│   │   └── test/
│   └── target/
│
├── api-gateway/
│   ├── pom.xml
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/
│   │   │   │   └── com/example/demo/
│   │   │   │       ├── ApiGatewayApplication.java
│   │   │   │       ├── config/
│   │   │   │       │   ├── CorsConfig.java
│   │   │   │       │   └── SecurityConfig.java
│   │   │   │       └── filter/
│   │   │   │           └── JwtAuthenticationFilter.java
│   │   │   └── resources/
│   │   │       └── application.yml
│   │   └── test/
│   └── target/
│
├── user-service/
│   ├── pom.xml
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/
│   │   │   │   └── com/example/userservice/
│   │   │   │       ├── UserServiceApplication.java
│   │   │   │       ├── config/
│   │   │   │       │   └── SecurityConfig.java
│   │   │   │       ├── controller/
│   │   │   │       │   └── UserController.java
│   │   │   │       ├── dto/
│   │   │   │       │   ├── LoginRequest.java
│   │   │   │       │   └── LoginResponse.java
│   │   │   │       ├── entity/
│   │   │   │       │   └── User.java
│   │   │   │       ├── repo/
│   │   │   │       │   └── UserRepository.java
│   │   │   │       └── security/
│   │   │   │           ├── CustomUserDetailsService.java
│   │   │   │           ├── JwtAuthenticationFilter.java
│   │   │   │           └── JwtUtil.java
│   │   │   └── resources/
│   │   │       └── application.properties
│   │   └── test/
│   └── target/
│
├── product-service/
│   ├── pom.xml
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/
│   │   │   │   └── com/example/productservice/
│   │   │   │       ├── ProductServiceApplication.java
│   │   │   │       ├── config/
│   │   │   │       │   └── SecurityConfig.java
│   │   │   │       ├── controller/
│   │   │   │       │   └── ProductController.java
│   │   │   │       ├── entity/
│   │   │   │       │   └── Product.java
│   │   │   │       ├── repo/
│   │   │   │       │   └── ProductRepository.java
│   │   │   │       ├── service/
│   │   │   │       │   └── ProductService.java
│   │   │   │       └── security/
│   │   │   │           ├── JwtAuthenticationFilter.java
│   │   │   │           └── JwtUtil.java
│   │   │   └── resources/
│   │   │       └── application.yml
│   │   └── test/
│   └── target/
│
├── sales-service/
│   ├── pom.xml
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/
│   │   │   │   └── com/example/salesservice/
│   │   │   │       ├── SalesServiceApplication.java
│   │   │   │       ├── client/
│   │   │   │       │   └── ProductServiceClient.java
│   │   │   │       ├── config/
│   │   │   │       │   └── RestTemplateConfig.java
│   │   │   │       ├── controller/
│   │   │   │       │   └── SaleController.java
│   │   │   │       ├── dto/
│   │   │   │       │   └── ProductDTO.java
│   │   │   │       ├── entity/
│   │   │   │       │   └── Sale.java
│   │   │   │       └── repo/
│   │   │   │           └── SaleRepository.java
│   │   │   └── resources/
│   │   │       └── application.yml
│   │   └── test/
│   └── target/
│
└── README.md (This file)
```

## Quick Summary

### Core Services
- **Eureka Server**: Service registry and discovery
- **Config Server**: Centralized configuration management
- **API Gateway**: Request routing and authentication

### Business Services
- **User Service**: User management and authentication
- **Product Service**: Product catalog management
- **Sales Service**: Sales tracking and analytics

### Key Folders in Each Service
- `java/`: Java source code
- `resources/`: Configuration files (YAML/Properties)
- `test/`: Unit and integration tests
- `target/`: Compiled build artifacts

## Configuration Files Location

| Service | Config File | Path |
|---------|------------|------|
| Eureka | application.yml | eureka-server/src/main/resources/ |
| Config | application.yml | config-server/src/main/resources/ |
| Gateway | application.yml | api-gateway/src/main/resources/ |
| User | application.properties | user-service/src/main/resources/ |
| Product | application.yml | product-service/src/main/resources/ |
| Sales | application.yml | sales-service/src/main/resources/ |

## Database Connections

Each service connects to its own MySQL database:
- User Service → userdb
- Product Service → productdb
- Sales Service → salesdb

## Ports Used

| Service | Port |
|---------|------|
| Eureka Server | 8761 |
| Config Server | 8888 |
| API Gateway | 8086 |
| User Service | 8081 |
| Product Service | 8082 |
| Sales Service | 8083 |
