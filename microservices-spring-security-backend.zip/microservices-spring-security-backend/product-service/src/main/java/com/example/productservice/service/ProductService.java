package com.example.productservice.service;
 
import com.example.productservice.entity.Product;
import com.example.productservice.repo.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import java.util.List;
import java.util.Optional;
 
@Service
public class ProductService {
 
    @Autowired
    private ProductRepository productRepository;
 
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }
 
    public Optional<Product> getProductById(Long id) {
        return productRepository.findById(id);
    }
 
    public Product addProduct(Product product) {
        return productRepository.save(product);
    }
 
    public Optional<Product> updateProduct(Long id, Product updatedProduct) {
        return productRepository.findById(id).map(product -> {
            product.setName(updatedProduct.getName());
            product.setDescription(updatedProduct.getDescription());
            product.setManufacturer(updatedProduct.getManufacturer());
            product.setPrice(updatedProduct.getPrice());
            product.setQuantity(updatedProduct.getQuantity());
            product.setSaleDate(updatedProduct.getSaleDate());
            return productRepository.save(product);
        });
    }
 
    public boolean deleteProduct(Long id) {
        if (productRepository.existsById(id)) {
            productRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
