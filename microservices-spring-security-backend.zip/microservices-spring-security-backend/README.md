# Spring Boot Microservices Architecture

Complete Spring Boot microservices backend project with Eureka Server, Config Server, API Gateway, and multiple microservices.

## Project Structure

```
microservices-backend/
├── eureka-server/                    # Service Registry
├── config-server/                    # Configuration Management Server
├── api-gateway/                      # API Gateway
├── user-service/                     # User Management Microservice
├── product-service/                  # Product Management Microservice
└── sales-service/                    # Sales Management Microservice
```

## Microservices Overview

### 1. **Eureka Server** (Port: 8761)
Service registry for service discovery
- All microservices register themselves here
- Dashboard available at: `http://localhost:8761`

**Key Files:**
- `src/main/java/com/example/demo/EurekaServerApplication.java`
- `src/main/resources/application.yml`

### 2. **Config Server** (Port: 8888)
Centralized configuration management
- Fetches configurations from Git repository
- Provides dynamic configuration to microservices

**Key Files:**
- `src/main/java/com/example/demo/ConfigServerApplication.java`
- `src/main/resources/application.yml`

### 3. **API Gateway** (Port: 8086)
Entry point for all client requests
- Routes requests to appropriate microservices
- JWT authentication filter
- CORS configuration
- Load balancing

**Key Features:**
- Route to User Service: `/user-service/**`
- Route to Product Service: `/product-service/**`
- Route to Sales Service: `/sales-service/**`

**Key Files:**
- `src/main/java/com/example/demo/ApiGatewayApplication.java`
- `src/main/java/com/example/demo/config/CorsConfig.java`
- `src/main/java/com/example/demo/config/SecurityConfig.java`
- `src/main/java/com/example/demo/filter/JwtAuthenticationFilter.java`
- `src/main/resources/application.yml`

### 4. **User Service** (Port: 8081)
User management and authentication

**Features:**
- User registration and login
- JWT token generation
- Password encryption with BCrypt
- User profile management

**API Endpoints:**
- `POST /users/register` - Register new user
- `POST /users/login` - User login
- `GET /users/all` - Get all users
- `GET /users/{id}` - Get user by ID
- `PUT /users/{id}` - Update user
- `DELETE /users/{id}` - Delete user

**Key Files:**
- `src/main/java/com/example/userservice/UserServiceApplication.java`
- `src/main/java/com/example/userservice/entity/User.java`
- `src/main/java/com/example/userservice/controller/UserController.java`
- `src/main/java/com/example/userservice/security/JwtUtil.java`
- `src/main/resources/application.properties`

**Database:**
- MySQL Database: `userdb`
- Tables: `user`

### 5. **Product Service** (Port: 8082)
Product catalog management

**Features:**
- CRUD operations on products
- Product inventory management
- Validation with Lombok annotations

**API Endpoints:**
- `GET /products/all` - Get all products
- `GET /products/{id}` - Get product by ID
- `POST /products` - Add new product
- `PUT /products/{id}` - Update product
- `DELETE /products/{id}` - Delete product

**Key Files:**
- `src/main/java/com/example/productservice/ProductServiceApplication.java`
- `src/main/java/com/example/productservice/entity/Product.java`
- `src/main/java/com/example/productservice/controller/ProductController.java`
- `src/main/resources/application.yml`

**Database:**
- MySQL Database: `productdb`
- Tables: `product`

### 6. **Sales Service** (Port: 8083)
Sales and analytics management

**Features:**
- Sales transaction recording
- Product quantity updates (via Product Service)
- Sales analytics and trends
- Inter-service communication using RestTemplate

**API Endpoints:**
- `GET /sales/all` - Get all sales
- `GET /sales/{id}` - Get sale by ID
- `POST /sales` - Create new sale
- `GET /sales/product/{productId}` - Get sales by product
- `GET /sales/date-range` - Get sales in date range
- `GET /sales/trends` - Get sales analytics
- `DELETE /sales/{id}` - Delete sale

**Key Files:**
- `src/main/java/com/example/salesservice/SalesServiceApplication.java`
- `src/main/java/com/example/salesservice/entity/Sale.java`
- `src/main/java/com/example/salesservice/controller/SaleController.java`
- `src/main/java/com/example/salesservice/client/ProductServiceClient.java`
- `src/main/resources/application.yml`

**Database:**
- MySQL Database: `salesdb`
- Tables: `sale`

## Prerequisites

- **Java 17** or higher
- **Maven 3.6+**
- **MySQL 8.0+**
- **Git**

## Installation & Setup

### 1. Create MySQL Databases

```sql
CREATE DATABASE userdb;
CREATE DATABASE productdb;
CREATE DATABASE salesdb;
```

### 2. Clone and Import Projects

Each service is a separate Maven project. Import them into STS:
- File → Import → Maven → Existing Maven Projects
- Select each microservice folder

### 3. Update Database Credentials

Update database credentials in each service's configuration file:

**User Service** (`user-service/src/main/resources/application.properties`):
```properties
spring.datasource.username=root
spring.datasource.password=your_password
```

**Product Service** (`product-service/src/main/resources/application.yml`):
```yaml
spring:
  datasource:
    username: root
    password: your_password
```

**Sales Service** (`sales-service/src/main/resources/application.yml`):
```yaml
spring:
  datasource:
    username: root
    password: your_password
```

## Running the Services

### Start services in order:

1. **Eureka Server**
```bash
cd eureka-server
mvn spring-boot:run
```

2. **Config Server**
```bash
cd config-server
mvn spring-boot:run
```

3. **API Gateway**
```bash
cd api-gateway
mvn spring-boot:run
```

4. **User Service**
```bash
cd user-service
mvn spring-boot:run
```

5. **Product Service**
```bash
cd product-service
mvn spring-boot:run
```

6. **Sales Service**
```bash
cd sales-service
mvn spring-boot:run
```

Or use STS Run button for each project.

## Configuration

### JWT Configuration

Both User and Product services use JWT for authentication.

Default JWT Secret (User Service):
```
404E635266556A586E3272357538782F413F4428472B4B6250645367566B5970
```

JWT Expiration: 24 hours (86400000 ms)

### Service Discovery

Services register with Eureka using:
- **Eureka URL**: `http://localhost:8761/eureka/`
- **Service Names**: `user-service`, `product-service`, `sales-service`

### Load Balancing

API Gateway uses `@LoadBalanced` RestTemplate for load balancing and service discovery.

## API Gateway Routes

All requests go through `http://localhost:8086`:

```
/user-service/**    → forwards to USER-SERVICE (8081)
/product-service/** → forwards to PRODUCT-SERVICE (8082)
/sales-service/**   → forwards to SALES-SERVICE (8083)
```

## Authentication

### Public Endpoints (No Auth Required)
- `POST /user-service/users/register`
- `POST /user-service/users/login`

### Protected Endpoints (JWT Required)
All other endpoints require `Authorization: Bearer <jwt_token>` header

### Getting JWT Token
1. Register user: `POST /user-service/users/register`
2. Login: `POST /user-service/users/login`
3. Copy token from response
4. Use in subsequent requests: `Authorization: Bearer <token>`

## Security Features

- **CSRF Protection**: Disabled for API (appropriate for REST APIs)
- **CORS**: Configured to allow requests from `http://localhost:3000`
- **Password Encryption**: BCrypt hashing
- **JWT Authentication**: Token-based authentication
- **SSL Validation**: Optional (can be enabled for production)

## Database Schema

### User Table (userdb)
```sql
id (BIGINT, PRIMARY KEY, AUTO_INCREMENT)
email (VARCHAR)
password (VARCHAR)
firstName (VARCHAR)
lastName (VARCHAR)
location (VARCHAR)
mobileNumber (VARCHAR)
```

### Product Table (productdb)
```sql
id (BIGINT, PRIMARY KEY, AUTO_INCREMENT)
name (VARCHAR)
description (VARCHAR)
manufacturer (VARCHAR)
price (DOUBLE)
quantity (INT)
```

### Sale Table (salesdb)
```sql
id (BIGINT, PRIMARY KEY, AUTO_INCREMENT)
productId (BIGINT)
productName (VARCHAR)
quantity (INT)
unitPrice (DOUBLE)
totalPrice (DOUBLE)
saleDate (DATETIME)
customerName (VARCHAR)
customerEmail (VARCHAR)
```

## Testing APIs

### Using Postman or cURL

**1. Register User**
```bash
POST http://localhost:8086/user-service/users/register
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "password123",
  "firstName": "John",
  "lastName": "Doe"
}
```

**2. Login**
```bash
POST http://localhost:8086/user-service/users/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "password123"
}
```

**3. Create Product** (with JWT)
```bash
POST http://localhost:8086/product-service/products
Content-Type: application/json
Authorization: Bearer <jwt_token>

{
  "name": "Laptop",
  "description": "Gaming Laptop",
  "manufacturer": "Dell",
  "price": 1200.00,
  "quantity": 50
}
```

**4. Create Sale** (with JWT)
```bash
POST http://localhost:8086/sales-service/sales
Content-Type: application/json
Authorization: Bearer <jwt_token>

{
  "productId": 1,
  "quantity": 2,
  "customerName": "John Doe",
  "customerEmail": "john@example.com"
}
```

## Troubleshooting

### Services not registering with Eureka
- Check if Eureka Server is running on port 8761
- Verify `eureka.client.service-url.defaultZone` in each service
- Check firewall settings

### Database connection errors
- Verify MySQL is running
- Check database credentials
- Ensure databases exist
- Check `spring.datasource.url` is correct

### Port already in use
- Check if another application is using the port
- Change port in `application.yml` or `application.properties`

### JWT validation errors
- Ensure `jwt.secret` is same in all services
- Check token expiration
- Verify Bearer format: `Authorization: Bearer <token>`

## Technologies Used

- **Spring Boot 3.2.x**
- **Spring Cloud 2023.0.x**
- **Spring Security**
- **JWT (JJWT)**
- **Spring Data JPA**
- **MySQL 8.0**
- **Netflix Eureka**
- **Spring Cloud Config**
- **Spring Cloud Gateway**
- **Lombok**

## Project Maintenance

### Adding New Service
1. Create new Maven project in each service folder
2. Add Spring Boot and Cloud dependencies
3. Create `@SpringBootApplication` with `@EnableDiscoveryClient`
4. Register with Eureka by adding config
5. Add routes in API Gateway

### Scaling Services
- Multiple instances can register with same name
- Load balancer in gateway distributes requests
- Sticky sessions not configured by default

## Notes

- All services use port ranges 8081-8083, 8086, 8761, 8888
- Ensure no port conflicts
- Database credentials should be secured (use environment variables in production)
- CORS is configured for localhost:3000, update for production
- SSL/TLS should be enabled for production
