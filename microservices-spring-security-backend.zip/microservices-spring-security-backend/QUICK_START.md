# Quick Start Guide

Get your microservices running in 15 minutes!

## Prerequisites Check

```bash
# Check Java version
java -version

# Check Maven version
mvn -version

# Check MySQL
mysql --version
```

Required:
- ✅ Java 17 or higher
- ✅ Maven 3.6 or higher
- ✅ MySQL 8.0 or higher

---

## Step 1: Setup Database (5 minutes)

### 1.1 Start MySQL
```bash
# Windows
net start MySQL80

# Or use MySQL Workbench GUI
```

### 1.2 Run Database Setup Script
```bash
# Option A: Using MySQL Command Line
mysql -u root -p < C:\microservices-backend\database-setup.sql

# Option B: Using MySQL Workbench
# 1. Open MySQL Workbench
# 2. Connect to MySQL Server
# 3. File → Open SQL Script
# 4. Select database-setup.sql
# 5. Click Execute
```

### 1.3 Verify Database Creation
```sql
SHOW DATABASES;
```

Expected output should include:
- userdb
- productdb
- salesdb

---

## Step 2: Import Projects into STS (3 minutes)

### 2.1 Open STS
Launch Spring Tool Suite

### 2.2 Import Projects
1. **File** → **Import**
2. Select **Maven** → **Existing Maven Projects**
3. **Next**
4. **Browse** to: `C:\microservices-backend\eureka-server`
5. **Finish**

Repeat for:
- config-server
- api-gateway
- user-service
- product-service
- sales-service

### 2.3 Update Maven Projects
For each project:
- Right-click → **Maven** → **Update Project**
- Select all and click **OK**

---

## Step 3: Configure Database Credentials (2 minutes)

### For User Service
Edit: `user-service/src/main/resources/application.properties`

Find and update:
```properties
spring.datasource.username=root
spring.datasource.password=YOUR_PASSWORD
```

### For Product Service
Edit: `product-service/src/main/resources/application.yml`

Find and update:
```yaml
spring:
  datasource:
    username: root
    password: YOUR_PASSWORD
```

### For Sales Service
Edit: `sales-service/src/main/resources/application.yml`

Find and update:
```yaml
spring:
  datasource:
    username: root
    password: YOUR_PASSWORD
```

---

## Step 4: Start Services (5 minutes)

### Important: Start in this order!

#### 4.1 Eureka Server (Port 8761)
1. Right-click **eureka-server**
2. Select **Run As** → **Spring Boot App**
3. Wait for: `Started EurekaServerApplication`
4. Verify: Open browser → `http://localhost:8761`

#### 4.2 Config Server (Port 8888)
1. Right-click **config-server**
2. Select **Run As** → **Spring Boot App**
3. Wait for: `Started ConfigServerApplication`

#### 4.3 API Gateway (Port 8086)
1. Right-click **api-gateway**
2. Select **Run As** → **Spring Boot App**
3. Wait for: `Started ApiGatewayApplication`

#### 4.4 User Service (Port 8081)
1. Right-click **user-service**
2. Select **Run As** → **Spring Boot App**
3. Wait for: `Started UserServiceApplication`

#### 4.5 Product Service (Port 8082)
1. Right-click **product-service**
2. Select **Run As** → **Spring Boot App**
3. Wait for: `Started ProductServiceApplication`

#### 4.6 Sales Service (Port 8083)
1. Right-click **sales-service**
2. Select **Run As** → **Spring Boot App**
3. Wait for: `Started SalesServiceApplication`

---

## Step 5: Verify All Services Running

### 5.1 Check Eureka Dashboard
Open browser: `http://localhost:8761`

You should see:
- USER-SERVICE (UP)
- PRODUCT-SERVICE (UP)
- SALES-SERVICE (UP)

### 5.2 Verify Console Logs
Each service should show in its console:
```
Started [ServiceName]Application in X.XXX seconds
```

---

## Step 6: Test APIs (5 minutes)

### 6.1 Register User
```bash
POST http://localhost:8086/user-service/users/register
Content-Type: application/json

{
  "email": "test@example.com",
  "password": "Test123!",
  "firstName": "Test",
  "lastName": "User"
}
```

### 6.2 Login
```bash
POST http://localhost:8086/user-service/users/login
Content-Type: application/json

{
  "email": "test@example.com",
  "password": "Test123!"
}
```

Response will include JWT token:
```json
{
  "success": true,
  "message": "Login successful",
  "token": "eyJhbGciOiJIUzI1NiJ9..."
}
```

### 6.3 Create Product (use JWT token)
```bash
POST http://localhost:8086/product-service/products
Authorization: Bearer <YOUR_JWT_TOKEN>
Content-Type: application/json

{
  "name": "Test Laptop",
  "description": "Test Description",
  "manufacturer": "Test Brand",
  "price": 999.99,
  "quantity": 10
}
```

### 6.4 Get All Products
```bash
GET http://localhost:8086/product-service/products/all
Authorization: Bearer <YOUR_JWT_TOKEN>
```

---

## Using Postman for Testing

### 1. Create Collection
- Name: "Microservices"

### 2. Set Environment Variable
- Variable: `token`
- Initial value: (empty, will be filled after login)

### 3. Login Request
```
POST: {{base_url}}/user-service/users/login
Body (raw JSON):
{
  "email": "test@example.com",
  "password": "Test123!"
}

In Tests tab, add:
pm.environment.set("token", pm.response.json().token);
```

### 4. Use Token in Subsequent Requests
```
Authorization: Bearer {{token}}
```

---

## Troubleshooting

### ❌ "Port already in use"
```bash
# Find process using port
netstat -ano | findstr :8761

# Kill process
taskkill /PID <PID> /F
```

### ❌ "Cannot connect to MySQL"
- Verify MySQL is running
- Check username/password
- Verify database exists

### ❌ "Eureka shows 0 instances"
- Wait 30 seconds for services to register
- Check service console for errors
- Verify eureka.client.service-url.defaultZone

### ❌ "401 Unauthorized"
- Verify JWT token is included
- Check token format: `Authorization: Bearer <token>`
- Login again if token expired

### ❌ "Cannot find symbol" during build
- Right-click project → Maven → Update Project
- Delete target folder and rebuild

---

## Useful Console Commands

### View running Java processes
```bash
jps -l
```

### Kill service on port
```bash
# Find PID
netstat -ano | findstr :PORT

# Kill process
taskkill /PID <PID> /F
```

### Tail log file
```bash
# Windows PowerShell
Get-Content .\service.log -Wait
```

---

## Common Ports

| Service | Port | URL |
|---------|------|-----|
| Eureka | 8761 | http://localhost:8761 |
| Config | 8888 | http://localhost:8888 |
| Gateway | 8086 | http://localhost:8086 |
| User Service | 8081 | http://localhost:8081 |
| Product Service | 8082 | http://localhost:8082 |
| Sales Service | 8083 | http://localhost:8083 |

---

## Sample Database Credentials

Used in setup script:
- **Host**: localhost
- **Port**: 3306
- **Username**: root
- **Password**: (your MySQL password)

---

## Default Test Credentials (from database-setup.sql)

```
Email: admin@example.com
Password: admin123 (hashed in DB)

Email: john.doe@example.com
Password: password123 (hashed in DB)
```

---

## Sample Data Created

### Users (3)
- admin@example.com
- john.doe@example.com
- jane.smith@example.com

### Products (6)
- Laptop: $1299.99 (qty: 50)
- Mouse: $29.99 (qty: 200)
- Keyboard: $149.99 (qty: 100)
- Monitor: $499.99 (qty: 30)
- Headphones: $349.99 (qty: 75)
- USB-C Cable: $9.99 (qty: 500)

---

## Next Steps

1. ✅ Database setup complete
2. ✅ Projects imported
3. ✅ Services running
4. ✅ APIs tested

### Now you can:
- Read `README.md` for detailed documentation
- Check `API_TESTING.md` for more API examples
- Review `PROJECT_STRUCTURE.md` for folder organization
- Customize services for your needs

---

## Quick Commands

### Build all services
```bash
cd microservices-backend
for /d %d in (*) do (
    cd %d && mvn clean package && cd ..
)
```

### View service logs
In STS: 
- Click on **Console** tab at bottom
- Select desired service from dropdown

### Stop a service
- Press `Ctrl + C` in the service console
- Or click **Terminate** button

---

## Need Help?

### Check logs
1. Look at service console in STS
2. Check for error messages
3. Verify all prerequisites are met

### Common fixes
1. Update Maven: `mvn clean install`
2. Clear cache: Delete `target` folder
3. Restart STS
4. Restart MySQL service

### Documentation
- **README.md** - Complete documentation
- **STS_IMPORT_GUIDE.md** - Detailed import steps
- **API_TESTING.md** - API examples
- **PROJECT_STRUCTURE.md** - File structure

---

## Success Checklist

- [ ] Java 17+ installed
- [ ] Maven installed
- [ ] MySQL installed and running
- [ ] Database created
- [ ] All 6 projects imported
- [ ] Credentials configured
- [ ] Services started (all showing logs)
- [ ] Eureka dashboard shows 3 services UP
- [ ] Can login and get JWT token
- [ ] Can create products
- [ ] Can create sales
- [ ] Trends/Analytics working

---

🎉 **You're all set!** Your microservices backend is ready to use.

Start building your frontend to connect with these APIs!
