# Microservices Architecture Documentation

## System Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                         CLIENT APPLICATIONS                          │
│                  (React, Angular, Mobile Apps, etc.)                 │
└────────────────────────────────┬────────────────────────────────────┘
                                 │
                                 ▼
                    ┌────────────────────────┐
                    │   API GATEWAY (8086)   │
                    │ - CORS Configuration   │
                    │ - JWT Auth Filter      │
                    │ - Route Management     │
                    │ - Load Balancing       │
                    └────────────┬───────────┘
                                 │
         ┌───────────────────────┼───────────────────────┐
         │                       │                       │
         ▼                       ▼                       ▼
    ┌─────────────┐         ┌──────────────┐        ┌─────────────┐
    │USER SERVICE │         │PRODUCT SRVCE │        │ SALES SRVCE │
    │  (8081)     │         │  (8082)      │        │  (8083)     │
    │ - Auth      │         │ - Inventory  │        │ - Tracking  │
    │ - Profiles  │         │ - CRUD       │        │ - Analytics │
    └──────┬──────┘         └──────┬───────┘        └──────┬──────┘
           │                       │                       │
           ▼                       ▼                       ▼
      ┌────────────┐          ┌──────────┐           ┌─────────┐
      │  userdb    │          │productdb │           │salesdb  │
      │  (MySQL)   │          │ (MySQL)  │           │(MySQL)  │
      └────────────┘          └──────────┘           └─────────┘
           ▲                       ▲                       ▲
           │                       │                       │
           └───────────────────────┼───────────────────────┘
                    (Inter-service Communication)


┌─────────────────────────────────────────────────────────────────────┐
│              INFRASTRUCTURE & SUPPORTING SERVICES                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                       │
│  ┌──────────────┐              ┌──────────────────┐                 │
│  │EUREKA SERVER │              │ CONFIG SERVER    │                 │
│  │   (8761)     │              │    (8888)        │                 │
│  │              │              │                  │                 │
│  │- Service     │              │- Centralized     │                 │
│  │  Registry    │              │  Configuration   │                 │
│  │- Discovery   │              │- Git Integration │                 │
│  │- Load Info   │              │- Dynamic Config  │                 │
│  └──────────────┘              └──────────────────┘                 │
│                                                                       │
└─────────────────────────────────────────────────────────────────────┘
```

## Component Details

### 1. API Gateway
**Location**: Port 8086  
**Technology**: Spring Cloud Gateway

**Responsibilities**:
- Route incoming requests to appropriate microservices
- Apply JWT authentication filters
- Handle CORS (Cross-Origin Resource Sharing)
- Load balancing through Eureka
- Strip prefixes from request paths

**Key Routes**:
```
/user-service/**     → USER-SERVICE (8081)
/product-service/**  → PRODUCT-SERVICE (8082)
/sales-service/**    → SALES-SERVICE (8083)
```

**Routing Configuration**:
```yaml
spring:
  cloud:
    gateway:
      routes:
        - id: user-service
          uri: lb://USER-SERVICE
          predicates:
            - Path=/user-service/**
          filters:
            - StripPrefix=1
```

---

### 2. Service Registry (Eureka)
**Location**: Port 8761  
**Technology**: Netflix Eureka

**Responsibilities**:
- Service registration
- Service discovery
- Health monitoring
- Dashboard for viewing services

**Key Features**:
- Automatic service registration
- Health checks every 30 seconds
- Client-side load balancing
- Fault tolerance through service isolation

**Dashboard Features**:
- View all registered services
- Monitor service instances
- Track instance health
- View instance metadata

---

### 3. Configuration Server
**Location**: Port 8888  
**Technology**: Spring Cloud Config

**Responsibilities**:
- Centralized configuration management
- Git-based configuration storage
- Dynamic configuration updates
- Environment-specific configs

**Benefits**:
- Single source of truth for configuration
- No need to rebuild services for config changes
- Version control for configuration
- Easy environment management

---

### 4. User Service
**Location**: Port 8081  
**Database**: userdb

**Responsibilities**:
- User registration
- User authentication
- Profile management
- JWT token generation

**Key Classes**:
- `User` - JPA Entity
- `UserController` - REST endpoints
- `UserRepository` - Data access
- `JwtUtil` - Token generation/validation
- `JwtAuthenticationFilter` - Request filtering
- `SecurityConfig` - Spring Security configuration

**Endpoints**:
```
POST   /users/register      - Register new user
POST   /users/login         - User login (public)
GET    /users/all           - Get all users
GET    /users/{id}          - Get user by ID
PUT    /users/{id}          - Update user
DELETE /users/{id}          - Delete user
```

**Database Schema**:
```sql
Table: user
├── id (BIGINT, PK)
├── email (VARCHAR, UNIQUE)
├── password (VARCHAR, hashed)
├── firstName (VARCHAR)
├── lastName (VARCHAR)
├── location (VARCHAR)
├── mobileNumber (VARCHAR)
└── timestamps
```

---

### 5. Product Service
**Location**: Port 8082  
**Database**: productdb

**Responsibilities**:
- Product catalog management
- Inventory tracking
- Product CRUD operations
- Product availability validation

**Key Classes**:
- `Product` - JPA Entity with validation
- `ProductController` - REST endpoints
- `ProductService` - Business logic
- `ProductRepository` - Data access

**Endpoints**:
```
GET    /products/all        - Get all products
GET    /products/{id}       - Get product by ID
POST   /products            - Create product
PUT    /products/{id}       - Update product
DELETE /products/{id}       - Delete product
```

**Database Schema**:
```sql
Table: products
├── id (BIGINT, PK)
├── name (VARCHAR)
├── description (LONGTEXT)
├── manufacturer (VARCHAR)
├── price (DOUBLE, CHECK > 0)
├── quantity (INT, CHECK >= 0)
└── timestamps
```

**Validation Rules**:
- Name: Required (not blank)
- Description: Required
- Manufacturer: Required
- Price: Must be positive
- Quantity: Must be non-negative

---

### 6. Sales Service
**Location**: Port 8083  
**Database**: salesdb

**Responsibilities**:
- Record sales transactions
- Track inventory changes
- Generate sales analytics
- Provide sales trends and reports

**Key Classes**:
- `Sale` - JPA Entity
- `SaleController` - REST endpoints
- `ProductServiceClient` - Inter-service communication
- `SaleRepository` - Data access with custom queries
- `RestTemplateConfig` - Load balanced HTTP client

**Endpoints**:
```
GET    /sales/all                - Get all sales
GET    /sales/{id}               - Get sale by ID
POST   /sales                    - Create sale
GET    /sales/product/{id}       - Get sales by product
GET    /sales/date-range         - Get sales in date range
GET    /sales/trends             - Get sales analytics
DELETE /sales/{id}               - Delete sale
```

**Database Schema**:
```sql
Table: sales
├── id (BIGINT, PK)
├── productId (BIGINT, FK)
├── productName (VARCHAR)
├── quantity (INT)
├── unitPrice (DOUBLE)
├── totalPrice (DOUBLE)
├── saleDate (DATETIME)
├── customerName (VARCHAR)
├── customerEmail (VARCHAR)
└── timestamps
```

**Inter-service Communication**:
```java
// Using RestTemplate with Eureka Load Balancing
@LoadBalanced
public RestTemplate restTemplate() { ... }

// Calling Product Service
restTemplate.getForObject("http://product-service/products/{id}", ...)
```

---

## Authentication & Security

### JWT (JSON Web Tokens)

**Token Structure**:
```
eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1c2VyQGV4YW1wbGUuY29tIiwiaWF0IjoxNjc5NDA5NjAwfQ.signature
```

**Token Components**:
1. **Header**: Algorithm and token type
2. **Payload**: User email and issued time
3. **Signature**: HMAC-SHA256 signature

**Configuration**:
```properties
jwt.secret=404E635266556A586E3272357538782F413F4428472B4B6250645367566B5970
jwt.expiration=86400000  # 24 hours
```

### Authentication Flow

```
1. User Registration
   POST /users/register
   ├─ Receive email & password
   ├─ Hash password with BCrypt
   └─ Save to database

2. User Login
   POST /users/login
   ├─ Receive email & password
   ├─ Find user by email
   ├─ Compare password with hash
   ├─ Generate JWT token
   └─ Return token to client

3. Subsequent Requests
   GET /products (with Authorization header)
   ├─ Extract token from header
   ├─ Validate token signature
   ├─ Check token expiration
   ├─ Extract username from token
   └─ Process request if valid

4. Token Validation
   JwtAuthenticationFilter
   ├─ Extract "Bearer <token>" from header
   ├─ Validate signature
   ├─ Check expiration time
   ├─ Extract claims (username)
   └─ Create authentication object
```

### Security Layers

**Layer 1: API Gateway**
- Global JWT filter
- Public endpoint whitelist
- CORS validation

**Layer 2: Microservice**
- Spring Security configuration
- JWT filter at service level
- Method-level authorization (if needed)

**Layer 3: Database**
- Encrypted passwords (BCrypt)
- Unique constraints on sensitive fields
- Data isolation per service

---

## Inter-Service Communication

### Service-to-Service Communication Pattern

```
Sales Service needs product data:

1. SalesController receives sale request
   ├─ Validate sale data
   └─ Call ProductServiceClient

2. ProductServiceClient
   ├─ Build request URL: "http://product-service/products/{id}"
   ├─ Use LoadBalanced RestTemplate
   ├─ Eureka resolves "product-service" to actual URL
   └─ Make HTTP request

3. Product Service
   ├─ Receive request
   ├─ Validate JWT token
   ├─ Process request
   └─ Return product data

4. Sales Service continues
   ├─ Receive product data
   ├─ Validate inventory
   ├─ Calculate totals
   ├─ Update product quantity
   └─ Save sale record
```

### LoadBalanced RestTemplate

**Configuration**:
```java
@Configuration
public class RestTemplateConfig {
    @Bean
    @LoadBalanced
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}
```

**Usage**:
```java
// Eureka resolves service name to actual instance
restTemplate.getForObject("http://product-service/products/{id}", ProductDTO.class)

// LoadBalancer distributes across multiple instances if available
// If service is down, client handles exception
```

---

## Data Flow Examples

### 1. User Registration Flow

```
Client Request:
POST /user-service/users/register
Content-Type: application/json
{
  "email": "user@example.com",
  "password": "plaintext_password",
  "firstName": "John",
  "lastName": "Doe"
}

API Gateway:
├─ Route to USER-SERVICE (8081)
└─ Remove "/user-service" prefix

User Service:
├─ Receive request
├─ Validate input
├─ Encrypt password: BCrypt("plaintext_password")
├─ Create User entity
├─ Save to userdb
└─ Return created user

Database:
INSERT INTO user (email, password, firstName, lastName)
VALUES ('user@example.com', '$2a$10$encrypted_hash', 'John', 'Doe')

Client Response:
{
  "id": 1,
  "email": "user@example.com",
  "firstName": "John",
  "lastName": "Doe",
  "status": "created"
}
```

---

### 2. Sales Creation with Product Update Flow

```
Client Request:
POST /sales-service/sales
Authorization: Bearer <jwt_token>
{
  "productId": 1,
  "quantity": 2,
  "customerName": "John Doe",
  "customerEmail": "john@example.com"
}

API Gateway:
├─ Extract JWT from Authorization header
├─ Validate JWT signature
├─ Route to SALES-SERVICE (8081)
└─ Pass JWT to service

Sales Service:
├─ Receive request with valid JWT
├─ Validate sale data
├─ Call ProductServiceClient.getProductById(1)

Product Service (called by Sales):
├─ Receive request
├─ Validate JWT
├─ Find product (id=1)
├─ Return product details

Sales Service continues:
├─ Verify inventory (quantity >= 2)
├─ Calculate total price
├─ Create Sale entity
├─ Call ProductServiceClient.updateProductQuantity(1, newQty)

Product Service (update called):
├─ Receive update request
├─ Find product (id=1)
├─ Update quantity: quantity - 2
├─ Save changes
└─ Return success

Sales Service final:
├─ Save sale to salesdb
├─ Return created sale with transaction ID

Database Changes:
userdb: [no change]
productdb: UPDATE products SET quantity = quantity - 2 WHERE id = 1
salesdb: INSERT INTO sales (...) VALUES (...)

Client Response:
{
  "id": 1,
  "productId": 1,
  "productName": "Laptop",
  "quantity": 2,
  "unitPrice": 1299.99,
  "totalPrice": 2599.98,
  "saleDate": "2024-01-15T10:30:00",
  "customerName": "John Doe"
}
```

---

## Deployment Architecture

### Single Server Deployment

```
Server (Windows/Linux)
├── Port 8761 - Eureka Server
├── Port 8888 - Config Server
├── Port 8086 - API Gateway
├── Port 8081 - User Service
├── Port 8082 - Product Service
├── Port 8083 - Sales Service
└── MySQL Database (localhost:3306)
    ├── userdb
    ├── productdb
    └── salesdb
```

### Multi-Server Deployment (Scalable)

```
Load Balancer
│
├─── Server 1
│    ├── API Gateway (8086)
│    └── MySQL (3306)
│
├─── Server 2
│    └── User Service (multiple instances)
│
├─── Server 3
│    └── Product Service (multiple instances)
│
├─── Server 4
│    └── Sales Service (multiple instances)
│
├─── Server 5
│    ├── Eureka Server (8761)
│    └── Config Server (8888)
│
└─── Database Cluster
     ├── userdb
     ├── productdb
     └── salesdb
```

---

## Technology Stack

### Framework & Runtime
- **Java 17**: Language
- **Spring Boot 3.2.x**: Framework
- **Spring Cloud 2023.0.x**: Microservices framework

### Database
- **MySQL 8.0**: Relational database
- **JPA/Hibernate**: ORM

### Security
- **Spring Security**: Authentication & Authorization
- **JJWT**: JWT token handling
- **BCrypt**: Password encryption

### Service Discovery & Config
- **Netflix Eureka**: Service registry
- **Spring Cloud Config**: Configuration management

### API & Web
- **Spring Cloud Gateway**: API Gateway
- **Spring Web**: RESTful web services
- **Spring WebFlux**: Reactive programming

### Testing & Build
- **Maven 3.6+**: Build tool
- **Spring Boot Test**: Testing framework
- **JUnit**: Unit testing

---

## Configuration Management

### Environment Variables (Recommended for Production)

```properties
# Database
DATABASE_HOST=localhost
DATABASE_PORT=3306
DATABASE_USER=root
DATABASE_PASSWORD=encrypted_password

# JWT
JWT_SECRET=secure_random_string
JWT_EXPIRATION=86400000

# Eureka
EUREKA_URL=http://eureka-server:8761/eureka/

# Services
SERVICE_PORT=8081
SERVICE_NAME=user-service
```

### Application Properties Hierarchy

1. Command line arguments
2. System environment variables
3. application.yml / application.properties
4. Config Server (if enabled)
5. Default values in code

---

## Monitoring & Troubleshooting

### Health Checks

**Eureka Dashboard**:
- URL: `http://localhost:8761`
- Shows all registered services
- Displays instance health

**Actuator Endpoints** (available on each service):
```
GET  /actuator/health           - Service health
GET  /actuator/env              - Environment variables
GET  /actuator/metrics          - Performance metrics
GET  /actuator/beans            - Spring beans
```

### Logging

**Log Levels in application.yml**:
```yaml
logging:
  level:
    com.example: DEBUG
    org.springframework.web: DEBUG
    org.hibernate: DEBUG
```

---

## Performance Considerations

### Caching Strategy
- Database indexes on frequently queried fields
- JWT token caching (if needed)
- Consider Redis for distributed cache

### Database Optimization
- Indexes on foreign keys
- Denormalization where appropriate
- Query optimization in custom repositories

### Service Scalability
- Stateless services for horizontal scaling
- Load balancing through gateway
- Database connection pooling

---

## Security Best Practices

1. **JWT Secret Management**
   - Use strong, random secrets
   - Store in environment variables
   - Rotate periodically

2. **Password Security**
   - Always hash passwords
   - Use strong hashing algorithms (BCrypt)
   - Never log passwords

3. **CORS Configuration**
   - Restrict to known origins in production
   - Avoid `*` (any origin) in production

4. **HTTPS/TLS**
   - Enable SSL/TLS in production
   - Use valid certificates
   - Redirect HTTP to HTTPS

5. **Database Security**
   - Use principle of least privilege
   - Regular backups
   - Encrypt sensitive data

---

## Conclusion

This microservices architecture provides:
- ✅ Scalability through service separation
- ✅ Resilience through Eureka service discovery
- ✅ Security through JWT authentication
- ✅ Flexibility through configuration management
- ✅ Maintainability through clear separation of concerns

The system is designed to grow with your needs while maintaining simplicity and clarity.
