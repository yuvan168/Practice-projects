# API Testing Collection

This document contains example requests for testing all microservices.

## Base URLs

- **API Gateway**: `http://localhost:8086`
- **Direct Services** (bypassing gateway):
  - User Service: `http://localhost:8081`
  - Product Service: `http://localhost:8082`
  - Sales Service: `http://localhost:8083`

## 1. USER SERVICE APIs

### 1.1 Register User
**Method**: POST  
**URL**: `http://localhost:8086/user-service/users/register`  
**Headers**: 
```
Content-Type: application/json
```
**Body**:
```json
{
  "email": "newuser@example.com",
  "password": "securePassword123",
  "firstName": "John",
  "lastName": "Doe",
  "location": "New York",
  "mobileNumber": "555-0123"
}
```
**Expected Response**: 201 Created with user data

---

### 1.2 Login User
**Method**: POST  
**URL**: `http://localhost:8086/user-service/users/login`  
**Headers**: 
```
Content-Type: application/json
```
**Body**:
```json
{
  "email": "newuser@example.com",
  "password": "securePassword123"
}
```
**Expected Response**: 200 OK with JWT token
```json
{
  "success": true,
  "message": "Login successful",
  "token": "eyJhbGciOiJIUzI1NiJ9...",
  "email": "newuser@example.com",
  "firstName": "John",
  "lastName": "Doe"
}
```

---

### 1.3 Get All Users
**Method**: GET  
**URL**: `http://localhost:8086/user-service/users/all`  
**Headers**: 
```
Authorization: Bearer <JWT_TOKEN>
```
**Expected Response**: 200 OK with list of users

---

### 1.4 Get User by ID
**Method**: GET  
**URL**: `http://localhost:8086/user-service/users/1`  
**Headers**: 
```
Authorization: Bearer <JWT_TOKEN>
```
**Expected Response**: 200 OK with user data

---

### 1.5 Update User
**Method**: PUT  
**URL**: `http://localhost:8086/user-service/users/1`  
**Headers**: 
```
Authorization: Bearer <JWT_TOKEN>
Content-Type: application/json
```
**Body**:
```json
{
  "firstName": "Jane",
  "lastName": "Smith",
  "location": "Los Angeles",
  "mobileNumber": "555-9876"
}
```
**Expected Response**: 200 OK with updated user data

---

### 1.6 Delete User
**Method**: DELETE  
**URL**: `http://localhost:8086/user-service/users/1`  
**Headers**: 
```
Authorization: Bearer <JWT_TOKEN>
```
**Expected Response**: 204 No Content

---

## 2. PRODUCT SERVICE APIs

### 2.1 Create Product
**Method**: POST  
**URL**: `http://localhost:8086/product-service/products`  
**Headers**: 
```
Authorization: Bearer <JWT_TOKEN>
Content-Type: application/json
```
**Body**:
```json
{
  "name": "Gaming Laptop",
  "description": "High-performance gaming laptop with RTX 4080",
  "manufacturer": "ASUS",
  "price": 1999.99,
  "quantity": 25
}
```
**Expected Response**: 200 OK with created product

---

### 2.2 Get All Products
**Method**: GET  
**URL**: `http://localhost:8086/product-service/products/all`  
**Headers**: 
```
Authorization: Bearer <JWT_TOKEN>
```
**Expected Response**: 200 OK with list of products

---

### 2.3 Get Product by ID
**Method**: GET  
**URL**: `http://localhost:8086/product-service/products/1`  
**Headers**: 
```
Authorization: Bearer <JWT_TOKEN>
```
**Expected Response**: 200 OK with product data

---

### 2.4 Update Product
**Method**: PUT  
**URL**: `http://localhost:8086/product-service/products/1`  
**Headers**: 
```
Authorization: Bearer <JWT_TOKEN>
Content-Type: application/json
```
**Body**:
```json
{
  "name": "Gaming Laptop Pro",
  "description": "Updated description",
  "manufacturer": "ASUS",
  "price": 2199.99,
  "quantity": 20
}
```
**Expected Response**: 200 OK with updated product

---

### 2.5 Delete Product
**Method**: DELETE  
**URL**: `http://localhost:8086/product-service/products/1`  
**Headers**: 
```
Authorization: Bearer <JWT_TOKEN>
```
**Expected Response**: 204 No Content

---

## 3. SALES SERVICE APIs

### 3.1 Create Sale
**Method**: POST  
**URL**: `http://localhost:8086/sales-service/sales`  
**Headers**: 
```
Authorization: Bearer <JWT_TOKEN>
Content-Type: application/json
```
**Body**:
```json
{
  "productId": 1,
  "quantity": 2,
  "customerName": "John Doe",
  "customerEmail": "customer@example.com"
}
```
**Expected Response**: 200 OK with created sale

---

### 3.2 Get All Sales
**Method**: GET  
**URL**: `http://localhost:8086/sales-service/sales/all`  
**Headers**: 
```
Authorization: Bearer <JWT_TOKEN>
```
**Expected Response**: 200 OK with list of sales

---

### 3.3 Get Sale by ID
**Method**: GET  
**URL**: `http://localhost:8086/sales-service/sales/1`  
**Headers**: 
```
Authorization: Bearer <JWT_TOKEN>
```
**Expected Response**: 200 OK with sale data

---

### 3.4 Get Sales by Product
**Method**: GET  
**URL**: `http://localhost:8086/sales-service/sales/product/1`  
**Headers**: 
```
Authorization: Bearer <JWT_TOKEN>
```
**Expected Response**: 200 OK with sales for product

---

### 3.5 Get Sales by Date Range
**Method**: GET  
**URL**: `http://localhost:8086/sales-service/sales/date-range?startDate=2024-01-01T00:00:00&endDate=2024-12-31T23:59:59`  
**Headers**: 
```
Authorization: Bearer <JWT_TOKEN>
```
**Expected Response**: 200 OK with sales in date range

---

### 3.6 Get Sales Trends (Analytics)
**Method**: GET  
**URL**: `http://localhost:8086/sales-service/sales/trends?startDate=2024-01-01T00:00:00&endDate=2024-12-31T23:59:59`  
**Headers**: 
```
Authorization: Bearer <JWT_TOKEN>
```
**Expected Response**: 200 OK with sales analytics
```json
{
  "totalRevenue": 15000.00,
  "totalSales": 25,
  "dailyRevenue": { "2024-01-15": 1500.00, ... },
  "dailyCount": { "2024-01-15": 3, ... },
  "topProducts": [
    {
      "productId": 1,
      "productName": "Gaming Laptop",
      "totalQuantity": 10,
      "totalRevenue": 19999.90
    }
  ],
  "startDate": "2024-01-01T00:00:00",
  "endDate": "2024-12-31T23:59:59"
}
```

---

### 3.7 Delete Sale
**Method**: DELETE  
**URL**: `http://localhost:8086/sales-service/sales/1`  
**Headers**: 
```
Authorization: Bearer <JWT_TOKEN>
```
**Expected Response**: 204 No Content

---

## Error Responses

### 401 Unauthorized
```json
{
  "error": "Unauthorized",
  "message": "Missing or invalid JWT token"
}
```

### 400 Bad Request
```json
{
  "error": "Bad Request",
  "message": "Validation error details"
}
```

### 404 Not Found
```json
{
  "error": "Not Found",
  "message": "Resource not found"
}
```

### 500 Internal Server Error
```json
{
  "error": "Internal Server Error",
  "message": "Error details"
}
```

---

## Testing Workflow

1. **Register a new user**
   - POST /users/register

2. **Login to get JWT token**
   - POST /users/login
   - Save the token from response

3. **Create products** (use token)
   - POST /products

4. **Create sales** (use token)
   - POST /sales

5. **Get sales trends** (use token)
   - GET /sales/trends

6. **View all data** (use token)
   - GET /users/all
   - GET /products/all
   - GET /sales/all

---

## Using Postman

### Import Collection
1. Create new Collection: "Microservices API"
2. Create folder: "User Service"
3. Add each request with appropriate method and URL
4. Set "Authorization" tab to "Bearer Token"
5. Add `{{token}}` variable in Authorization header

### Set Environment Variables
1. Create Environment: "Development"
2. Variables:
   - `base_url`: http://localhost:8086
   - `token`: [JWT token from login]

### Use Variables in Requests
```
{{base_url}}/user-service/users/all
Authorization: Bearer {{token}}
```

---

## cURL Examples

### Login and Save Token
```bash
curl -X POST http://localhost:8086/user-service/users/login \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","password":"password123"}'
```

### Get All Products with Token
```bash
curl -X GET http://localhost:8086/product-service/products/all \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json"
```

### Create Sale
```bash
curl -X POST http://localhost:8086/sales-service/sales \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "productId": 1,
    "quantity": 2,
    "customerName": "John Doe",
    "customerEmail": "john@example.com"
  }'
```

---

## Notes

- Replace `<JWT_TOKEN>` with actual token from login response
- All requests use API Gateway on port 8086
- Services auto-register with Eureka for load balancing
- Timestamps use ISO 8601 format
- All prices are in USD currency
- Quantities must be positive integers
