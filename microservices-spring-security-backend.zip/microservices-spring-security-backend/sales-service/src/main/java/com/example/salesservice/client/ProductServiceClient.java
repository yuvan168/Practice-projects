package com.example.salesservice.client;

import com.example.salesservice.dto.ProductDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class ProductServiceClient {

    @Autowired
    private RestTemplate restTemplate;

    private static final String PRODUCT_SERVICE_URL = "http://product-service/products";

    public ProductDTO getProductById(Long productId) {
        try {
            String url = PRODUCT_SERVICE_URL + "/" + productId;
            return restTemplate.getForObject(url, ProductDTO.class);
        } catch (Exception e) {
            System.err.println("Error calling product service: " + e.getMessage());
            return null;
        }
    }

    public boolean updateProductQuantity(Long productId, Integer newQuantity) {
        try {
            ProductDTO product = getProductById(productId);
            if (product != null) {
                product.setQuantity(newQuantity);
                restTemplate.put(PRODUCT_SERVICE_URL + "/" + productId, product);
                return true;
            }
            return false;
        } catch (Exception e) {
            System.err.println("Error updating product quantity: " + e.getMessage());
            return false;
        }
    }
}
