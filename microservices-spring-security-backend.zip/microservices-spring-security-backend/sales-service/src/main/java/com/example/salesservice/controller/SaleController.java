package com.example.salesservice.controller;

import com.example.salesservice.entity.Sale;
import com.example.salesservice.repo.SaleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

@RestController
@RequestMapping("/sales-service/sales")
@CrossOrigin(origins = "http://localhost:3000")
public class SaleController {

    @Autowired
    private SaleRepository saleRepository;

    // Get all sales
    @GetMapping("/all")
    public ResponseEntity<List<Sale>> getAllSales() {
        List<Sale> sales = saleRepository.findAll();
        return ResponseEntity.ok(sales);
    }

    // Get sale by ID
    @GetMapping("/{id}")
    public ResponseEntity<Sale> getSaleById(@PathVariable Long id) {
        return saleRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Create a new sale
    @PostMapping
    public ResponseEntity<?> createSale(@RequestBody Sale sale) {
        try {
            // Validate required fields
            if (sale.getProductId() == null || sale.getProductId() <= 0) {
                return ResponseEntity.badRequest().body(Map.of("error", "Product ID is required"));
            }
            if (sale.getQuantity() == null || sale.getQuantity() <= 0) {
                return ResponseEntity.badRequest().body(Map.of("error", "Quantity must be positive"));
            }
            if (sale.getCustomerName() == null || sale.getCustomerName().trim().isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of("error", "Customer name is required"));
            }
            if (sale.getCustomerEmail() == null || sale.getCustomerEmail().trim().isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of("error", "Customer email is required"));
            }

            // Set sale date to now if not provided
            if (sale.getSaleDate() == null) {
                sale.setSaleDate(LocalDateTime.now());
            }

            // Save and return
            Sale savedSale = saleRepository.save(sale);
            return ResponseEntity.ok(savedSale);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    // Get sales by date range
    @GetMapping("/date-range")
    public ResponseEntity<List<Sale>> getSalesByDateRange(
            @RequestParam(required = false) String startDate,
            @RequestParam(required = false) String endDate) {
        try {
            LocalDateTime parsedStartDate = startDate != null ? LocalDate.parse(startDate).atStartOfDay() : LocalDateTime.now().minusDays(30);
            LocalDateTime parsedEndDate = endDate != null ? LocalDate.parse(endDate).atTime(23, 59, 59) : LocalDateTime.now();
            List<Sale> sales = saleRepository.findBySaleDateBetween(parsedStartDate, parsedEndDate);
            return ResponseEntity.ok(sales);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(new ArrayList<>());
        }
    }

    // Get simple sales trends
    @GetMapping("/trends")
    public ResponseEntity<Map<String, Object>> getSalesTrends(
            @RequestParam(required = false) String startDate,
            @RequestParam(required = false) String endDate) {

        try {
            // If no date range provided, use last 1 year
            LocalDate parsedEndDate = endDate != null ? LocalDate.parse(endDate) : LocalDate.now().plusDays(1);
            LocalDate parsedStartDate = startDate != null ? LocalDate.parse(startDate) : parsedEndDate.minusYears(1);

            Map<String, Object> trends = new HashMap<>();
            List<Sale> allSales = saleRepository.findAll();
            
            Double totalRevenue = 0.0;
            Map<String, Double> dailyRevenue = new LinkedHashMap<>();
            Map<String, Integer> dailyCount = new LinkedHashMap<>();
            Map<Long, Map<String, Object>> productMetrics = new HashMap<>();
            int totalSalesCount = 0;
            
            for (Sale sale : allSales) {
                LocalDate saleDateOnly = sale.getSaleDate().toLocalDate();
                if (!saleDateOnly.isBefore(parsedStartDate) && !saleDateOnly.isAfter(parsedEndDate)) {
                    String dateKey = saleDateOnly.toString();
                    dailyRevenue.put(dateKey, dailyRevenue.getOrDefault(dateKey, 0.0) + (sale.getTotalPrice() != null ? sale.getTotalPrice() : 0.0));
                    dailyCount.put(dateKey, dailyCount.getOrDefault(dateKey, 0) + 1);
                    totalRevenue += (sale.getTotalPrice() != null ? sale.getTotalPrice() : 0.0);
                    totalSalesCount++;
                    
                    Long productId = sale.getProductId();
                    productMetrics.putIfAbsent(productId, new HashMap<>());
                    Map<String, Object> metrics = productMetrics.get(productId);
                    metrics.put("productId", productId);
                    metrics.put("productName", sale.getProductName() != null ? sale.getProductName() : "Unknown");
                    metrics.put("totalQuantity", (Integer) metrics.getOrDefault("totalQuantity", 0) + sale.getQuantity());
                    metrics.put("totalRevenue", (Double) metrics.getOrDefault("totalRevenue", 0.0) + (sale.getTotalPrice() != null ? sale.getTotalPrice() : 0.0));
                }
            }

            List<Map<String, Object>> topProducts = new ArrayList<>(productMetrics.values());
            topProducts.sort((a, b) -> Double.compare((Double) b.get("totalRevenue"), (Double) a.get("totalRevenue")));
            if (topProducts.size() > 10) {
                topProducts = topProducts.subList(0, 10);
            }
            
            trends.put("totalRevenue", totalRevenue);
            trends.put("totalSales", totalSalesCount);
            trends.put("dailyRevenue", dailyRevenue);
            trends.put("dailyCount", dailyCount);
            trends.put("topProducts", topProducts);
            trends.put("startDate", parsedStartDate.toString());
            trends.put("endDate", parsedEndDate.toString());

            return ResponseEntity.ok(trends);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", "Invalid date format"));
        }
    }

    // Update a sale
    @PutMapping("/{id}")
    public ResponseEntity<?> updateSale(@PathVariable Long id, @RequestBody Sale updatedSale) {
        try {
            Optional<Sale> existingSale = saleRepository.findById(id);
            if (!existingSale.isPresent()) {
                return ResponseEntity.notFound().build();
            }

            Sale sale = existingSale.get();
            
            // Validate required fields
            if (updatedSale.getProductId() == null || updatedSale.getProductId() <= 0) {
                return ResponseEntity.badRequest().body(Map.of("error", "Product ID is required"));
            }
            if (updatedSale.getQuantity() == null || updatedSale.getQuantity() <= 0) {
                return ResponseEntity.badRequest().body(Map.of("error", "Quantity must be positive"));
            }
            if (updatedSale.getCustomerName() == null || updatedSale.getCustomerName().trim().isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of("error", "Customer name is required"));
            }
            if (updatedSale.getCustomerEmail() == null || updatedSale.getCustomerEmail().trim().isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of("error", "Customer email is required"));
            }

            // Update fields
            sale.setProductId(updatedSale.getProductId());
            sale.setProductName(updatedSale.getProductName());
            sale.setQuantity(updatedSale.getQuantity());
            sale.setUnitPrice(updatedSale.getUnitPrice());
            sale.setTotalPrice(updatedSale.getTotalPrice());
            sale.setCustomerName(updatedSale.getCustomerName());
            sale.setCustomerEmail(updatedSale.getCustomerEmail());
            if (updatedSale.getSaleDate() != null) {
                sale.setSaleDate(updatedSale.getSaleDate());
            }

            Sale savedSale = saleRepository.save(sale);
            return ResponseEntity.ok(savedSale);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    // Delete a sale
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSale(@PathVariable Long id) {
        if (saleRepository.existsById(id)) {
            saleRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
