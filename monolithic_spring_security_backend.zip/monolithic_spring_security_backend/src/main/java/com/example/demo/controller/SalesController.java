package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.repository.SalesRepository;
import com.example.demo.entity.Sales;

import java.util.Collections;
import java.util.List;

@RestController
@RequestMapping("/api/sales")
@CrossOrigin(origins = "http://localhost:3000")
public class SalesController {

	@Autowired
	private SalesRepository salesRepo;

	// Get all sales data
	@GetMapping
	public ResponseEntity<List<Sales>> getAllSales() {
		List<Sales> sales = salesRepo.findAll();
		return ResponseEntity.ok(sales);
	}

	// Create new sales entry
	@PostMapping
	public ResponseEntity<?> createSales(@RequestBody Sales sales) {
		try {
			Sales saved = salesRepo.save(sales);
			return ResponseEntity.ok(saved);
		} catch (Exception e) {
			return ResponseEntity.badRequest()
					.body(Collections.singletonMap("message", "Failed to create sales data"));
		}
	}

	// Update sales entry with revenue
	@PutMapping("/{id}")
	public ResponseEntity<?> updateSales(@PathVariable Long id, @RequestBody Sales salesData) {
		try {
			Sales sales = salesRepo.findById(id)
					.orElseThrow(() -> new RuntimeException("Sales data not found"));
			
			sales.setName(salesData.getName());
			sales.setSales(salesData.getSales());
			if (salesData.getRevenue() != null) {
				sales.setRevenue(salesData.getRevenue());
			}
			
			salesRepo.save(sales);
			return ResponseEntity.ok(Collections.singletonMap("message", "Sales data updated successfully"));
		} catch (Exception e) {
			return ResponseEntity.badRequest()
					.body(Collections.singletonMap("message", "Failed to update sales data"));
		}
	}

	// Delete sales entry
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteSales(@PathVariable Long id) {
		try {
			if (!salesRepo.existsById(id)) {
				return ResponseEntity.status(404)
						.body(Collections.singletonMap("message", "Sales data not found"));
			}
			salesRepo.deleteById(id);
			return ResponseEntity.ok(Collections.singletonMap("message", "Sales data deleted successfully"));
		} catch (Exception e) {
			return ResponseEntity.badRequest()
					.body(Collections.singletonMap("message", "Failed to delete sales data"));
		}
	}
}
