package com.example.demo.controller;

import com.example.demo.entity.User;
import com.example.demo.entity.Role;
import com.example.demo.repository.RoleRepository;
import com.example.demo.repository.UserRepository;
import com.example.demo.dto.LoginRequest;
import com.example.demo.jwt.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:3000")
public class AuthController {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private JwtUtil jwtUtil;

	// ============================================
	// LOGIN
	// ============================================
	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
		try {
			Optional<User> userOpt = userRepository.findByEmail(loginRequest.getEmail());
			
			if (userOpt.isEmpty()) {
				return ResponseEntity.status(401)
					.body(Collections.singletonMap("message", "Invalid credentials"));
			}

			User user = userOpt.get();
			
			if (!passwordEncoder.matches(loginRequest.getPassword(), user.getPassword())) {
				return ResponseEntity.status(401)
					.body(Collections.singletonMap("message", "Invalid credentials"));
			}

			String token = jwtUtil.generateToken(user.getEmail());
			
			Map<String, Object> response = new HashMap<>();
			response.put("token", token);
			response.put("email", user.getEmail());
			response.put("firstName", user.getFirstName());
			response.put("lastName", user.getLastName());

			System.out.println("Login successful for user: " + user.getEmail());
			
			return ResponseEntity.ok(response);

		} catch (Exception e) {
			e.printStackTrace();
			return ResponseEntity.status(500)
				.body(Collections.singletonMap("message", "Login error: " + e.getMessage()));
		}
	}

	// ============================================
	// REGISTER
	// ============================================
	@PostMapping("/register")
	public ResponseEntity<?> register(@RequestBody User user) {
		try {
			if (userRepository.findByEmail(user.getEmail()).isPresent()) {
				return ResponseEntity.badRequest()
					.body(Collections.singletonMap("message", "Email already exists"));
			}

			user.setPassword(passwordEncoder.encode(user.getPassword()));

			// Find or create ROLE_USER
			Role userRole = roleRepository.findByName("ROLE_USER")
				.orElseGet(() -> {
					Role newRole = new Role();
					newRole.setName("ROLE_USER");
					return roleRepository.save(newRole);
				});

			Set<Role> roles = new HashSet<>();
			roles.add(userRole);
			user.setRoles(roles);

			User savedUser = userRepository.save(user);

			return ResponseEntity.ok(Collections.singletonMap("message", "User registered successfully"));

		} catch (Exception e) {
			e.printStackTrace();
			return ResponseEntity.status(500)
				.body(Collections.singletonMap("message", "Error registering user: " + e.getMessage()));
		}
	}

	// ============================================
	// GET ALL USERS (without passwords)
	// ============================================
	@GetMapping("/users")
	public ResponseEntity<?> getAllUsers() {
		try {
			System.out.println("=== GET ALL USERS ===");
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			System.out.println("Authenticated user: " + (auth != null ? auth.getName() : "null"));
			
			List<User> users = userRepository.findAll();
			System.out.println("Found " + users.size() + " users in database");
			
			// Create user DTOs without passwords
			List<Map<String, Object>> userDTOs = users.stream().map(user -> {
				Map<String, Object> dto = new HashMap<>();
				dto.put("id", user.getId());
				dto.put("email", user.getEmail());
				dto.put("firstName", user.getFirstName());
				dto.put("lastName", user.getLastName());
				// Get role names
				if (user.getRoles() != null && !user.getRoles().isEmpty()) {
					String role = user.getRoles().iterator().next().getName();
					dto.put("role", role.replace("ROLE_", ""));
				} else {
					dto.put("role", "USER");
				}
				return dto;
			}).collect(Collectors.toList());

			System.out.println("Returning " + userDTOs.size() + " users");
			return ResponseEntity.ok(userDTOs);

		} catch (Exception e) {
			System.err.println("ERROR in getAllUsers: " + e.getMessage());
			e.printStackTrace();
			return ResponseEntity.status(500)
				.body(Collections.singletonMap("message", "Error fetching users: " + e.getMessage()));
		}
	}

	// ============================================
	// CREATE USER
	// ============================================
	@PostMapping("/users")
	public ResponseEntity<?> createUser(@RequestBody User user) {
		try {
			System.out.println("Creating user: " + user.getEmail());
			
			if (userRepository.findByEmail(user.getEmail()).isPresent()) {
				return ResponseEntity.badRequest()
					.body(Collections.singletonMap("message", "Email already exists"));
			}

			user.setPassword(passwordEncoder.encode(user.getPassword()));

			// Find or create ROLE_USER
			Role userRole = roleRepository.findByName("ROLE_USER")
				.orElseGet(() -> {
					Role newRole = new Role();
					newRole.setName("ROLE_USER");
					return roleRepository.save(newRole);
				});

			Set<Role> roles = new HashSet<>();
			roles.add(userRole);
			user.setRoles(roles);

			User savedUser = userRepository.save(user);
			System.out.println("User created successfully: " + savedUser.getEmail());

			// Return DTO without password
			Map<String, Object> dto = new HashMap<>();
			dto.put("id", savedUser.getId());
			dto.put("email", savedUser.getEmail());
			dto.put("firstName", savedUser.getFirstName());
			dto.put("lastName", savedUser.getLastName());
			dto.put("role", "USER");

			return ResponseEntity.ok(dto);

		} catch (Exception e) {
			System.err.println("ERROR in createUser: " + e.getMessage());
			e.printStackTrace();
			return ResponseEntity.status(500)
				.body(Collections.singletonMap("message", "Error creating user: " + e.getMessage()));
		}
	}

	// ============================================
	// UPDATE USER
	// ============================================
	@PutMapping("/users/{id}")
	public ResponseEntity<?> updateUser(@PathVariable Long id, @RequestBody User userData) {
		try {
			Optional<User> userOpt = userRepository.findById(id);
			
			if (userOpt.isEmpty()) {
				return ResponseEntity.status(404)
					.body(Collections.singletonMap("message", "User not found"));
			}

			User user = userOpt.get();
			user.setFirstName(userData.getFirstName());
			user.setLastName(userData.getLastName());
			user.setEmail(userData.getEmail());

			if (userData.getPassword() != null && !userData.getPassword().isEmpty()) {
				user.setPassword(passwordEncoder.encode(userData.getPassword()));
			}

			userRepository.save(user);
			
			return ResponseEntity.ok(Collections.singletonMap("message", "User updated successfully"));

		} catch (Exception e) {
			e.printStackTrace();
			return ResponseEntity.status(500)
				.body(Collections.singletonMap("message", "Error updating user: " + e.getMessage()));
		}
	}

	// ============================================
	// DELETE USER
	// ============================================
	@DeleteMapping("/users/{id}")
	public ResponseEntity<?> deleteUser(@PathVariable Long id) {
		try {
			if (!userRepository.existsById(id)) {
				return ResponseEntity.status(404)
					.body(Collections.singletonMap("message", "User not found"));
			}

			userRepository.deleteById(id);
			return ResponseEntity.ok(Collections.singletonMap("message", "User deleted successfully"));

		} catch (Exception e) {
			e.printStackTrace();
			return ResponseEntity.status(500)
				.body(Collections.singletonMap("message", "Error deleting user: " + e.getMessage()));
		}
	}

	// ============================================
	// GET PROFILE
	// ============================================
	@GetMapping("/profile")
	public ResponseEntity<?> getProfile() {
		try {
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String email = auth.getName();

			Optional<User> userOpt = userRepository.findByEmail(email);
			
			if (userOpt.isEmpty()) {
				return ResponseEntity.status(404)
					.body(Collections.singletonMap("message", "User not found"));
			}

			User user = userOpt.get();
			
			Map<String, Object> profile = new HashMap<>();
			profile.put("email", user.getEmail());
			profile.put("firstName", user.getFirstName());
			profile.put("lastName", user.getLastName());

			return ResponseEntity.ok(profile);

		} catch (Exception e) {
			e.printStackTrace();
			return ResponseEntity.status(500)
				.body(Collections.singletonMap("message", "Error fetching profile: " + e.getMessage()));
		}
	}

	// ============================================
	// UPDATE PROFILE
	// ============================================
	@PutMapping("/profile")
	public ResponseEntity<?> updateProfile(@RequestBody Map<String, String> updates) {
		try {
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String email = auth.getName();

			Optional<User> userOpt = userRepository.findByEmail(email);
			
			if (userOpt.isEmpty()) {
				return ResponseEntity.status(404)
					.body(Collections.singletonMap("message", "User not found"));
			}

			User user = userOpt.get();
			user.setFirstName(updates.get("firstName"));
			user.setLastName(updates.get("lastName"));

			userRepository.save(user);
			
			return ResponseEntity.ok(Collections.singletonMap("message", "Profile updated successfully"));

		} catch (Exception e) {
			e.printStackTrace();
			return ResponseEntity.status(500)
				.body(Collections.singletonMap("message", "Error updating profile: " + e.getMessage()));
		}
	}
}
