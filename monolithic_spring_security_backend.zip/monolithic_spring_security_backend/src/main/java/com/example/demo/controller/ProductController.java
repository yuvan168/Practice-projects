package com.example.demo.controller;

import com.example.demo.service.ProductService;
import com.example.demo.entity.Product;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@RestController
@RequestMapping("/api/products")
@CrossOrigin(origins = "http://localhost:3000")
public class ProductController {
	@Autowired
	private ProductService productService;

	@GetMapping
	public ResponseEntity<List<Product>> all() {
		return ResponseEntity.ok(productService.findAll());
	}

	@GetMapping("/{id}")
	public ResponseEntity<Product> get(@PathVariable Long id) {
		Product p = productService.findById(id);
		return p == null ? ResponseEntity.notFound().build() : ResponseEntity.ok(p);
	}

	@PostMapping
	public ResponseEntity<Product> create(@RequestBody Product product) {
		Product saved = productService.save(product);
		return ResponseEntity.status(HttpStatus.CREATED).body(saved);
	}

	@PutMapping("/{id}")
	public ResponseEntity<Product> update(@PathVariable Long id, @RequestBody Product product) {
		Product existing = productService.findById(id);
		if (existing == null) return ResponseEntity.notFound().build();

		existing.setName(product.getName());
		existing.setDescription(product.getDescription());
		existing.setManufacturer(product.getManufacturer());
		existing.setPrice(product.getPrice());
		existing.setQuantity(product.getQuantity());

		productService.save(existing);
		return ResponseEntity.ok(existing);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<?> delete(@PathVariable Long id) {
		Product existing = productService.findById(id);
		if (existing == null) return ResponseEntity.notFound().build();
		productService.deleteById(id);
		return ResponseEntity.noContent().build();
	}
}
