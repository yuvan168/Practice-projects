package com.example.demo.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "sales")
public class Sales {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable = false)
	private String name; // Month name (Jan, Feb, etc.)

	@Column(nullable = false)
	private Integer sales; // Sales amount

	@Column
	private Double revenue; // Revenue for this month

	// Constructors
	public Sales() {}

	public Sales(String name, Integer sales) {
		this.name = name;
		this.sales = sales;
	}

	public Sales(String name, Integer sales, Double revenue) {
		this.name = name;
		this.sales = sales;
		this.revenue = revenue;
	}

	// Getters and Setters
	public Long getId() { return id; }
	public void setId(Long id) { this.id = id; }

	public String getName() { return name; }
	public void setName(String name) { this.name = name; }

	public Integer getSales() { return sales; }
	public void setSales(Integer sales) { this.sales = sales; }

	public Double getRevenue() { return revenue; }
	public void setRevenue(Double revenue) { this.revenue = revenue; }
}
