package com.example.demo.service;

import org.springframework.stereotype.Service;
import com.example.demo.repository.ProductRepository;
import com.example.demo.entity.Product;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@Service
public class ProductService {
	@Autowired
	private ProductRepository productRepo;

	public List<Product> findAll() { 
		return productRepo.findAll(); 
	}
	
	public Product findById(Long id) { 
		return productRepo.findById(id).orElse(null); 
	}
	
	public Product save(Product p) { 
		return productRepo.save(p); 
	}
	
	public void deleteById(Long id) { 
		productRepo.deleteById(id); 
	}
}
