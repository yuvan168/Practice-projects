package com.example.demo.dto;

public class JwtResponse {
	private String token;
	private String type = "Bearer";
	private String email;

	// Default constructor
	public JwtResponse() {}

	// Constructor with all fields
	public JwtResponse(String token, String type, String email) {
		this.token = token;
		this.type = type;
		this.email = email;
	}

	// Constructor without type (uses default "Bearer")
	public JwtResponse(String token, String email) {
		this.token = token;
		this.type = "Bearer";
		this.email = email;
	}

	// Getters and setters
	public String getToken() { return token; }
	public void setToken(String token) { this.token = token; }

	public String getType() { return type; }
	public void setType(String type) { this.type = type; }

	public String getEmail() { return email; }
	public void setEmail(String email) { this.email = email; }
}

