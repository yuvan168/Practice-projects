package com.example.demo.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Product;
import com.example.demo.repo.ProductRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    // Get all products
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    // Get product by ID
    public Optional<Product> getProductById(Long id) {
        return productRepository.findById(id);
    }

    // Search products by keyword
    public List<Product> searchProducts(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllProducts();
        }
        return productRepository.searchByKeyword(keyword);
    }

    // Get low stock products
    public List<Product> getLowStockProducts(Integer threshold) {
        if (threshold == null || threshold < 0) {
            threshold = 10; // Default threshold
        }
        return productRepository.getLowStockProducts(threshold);
    }

    // Get out of stock products
    public List<Product> getOutOfStockProducts() {
        return productRepository.findOutOfStockProducts();
    }

    // Get products with discount
    public List<Product> getProductsWithDiscount() {
        return productRepository.findProductsWithDiscount();
    }

    // Get featured products
    public List<Product> getFeaturedProducts() {
        return productRepository.getFeaturedProducts();
    }

    // Create product
    public Product createProduct(Product product) {
        // Validate product
        if (product.getProductName() == null || product.getProductName().trim().isEmpty()) {
            throw new IllegalArgumentException("Product name is required");
        }
        if (product.getPrice() == null || product.getPrice() <= 0) {
            throw new IllegalArgumentException("Price must be greater than 0");
        }
        if (product.getSku() == null || product.getSku().trim().isEmpty()) {
            throw new IllegalArgumentException("SKU is required");
        }
        if (product.getProductCode() == null || product.getProductCode().trim().isEmpty()) {
            throw new IllegalArgumentException("Product code is required");
        }
        if (product.getQuantity() == null || product.getQuantity() < 0) {
            throw new IllegalArgumentException("Quantity cannot be negative");
        }

        // Check for duplicate SKU
        Optional<Product> existingSku = productRepository.findBySku(product.getSku());
        if (existingSku.isPresent()) {
            throw new IllegalArgumentException("SKU already exists");
        }

        // Set default values
        if (product.getInStock() == null) {
            product.setInStock(product.getQuantity() > 0);
        }
        if (product.getIsActive() == null) {
            product.setIsActive(true);
        }
        if (product.getStatus() == null || product.getStatus().isEmpty()) {
            product.setStatus("ACTIVE");
        }
        if (product.getCreatedAt() == null) {
            product.setCreatedAt(LocalDateTime.now());
        }
        if (product.getUpdatedAt() == null) {
            product.setUpdatedAt(LocalDateTime.now());
        }

        return productRepository.save(product);
    }

    // Update product
    public Product updateProduct(Long id, Product productDetails) {
        Optional<Product> product = productRepository.findById(id);
        
        if (!product.isPresent()) {
            throw new IllegalArgumentException("Product not found");
        }

        Product existingProduct = product.get();

        // Validate and update product name
        if (productDetails.getProductName() != null && !productDetails.getProductName().trim().isEmpty()) {
            existingProduct.setProductName(productDetails.getProductName());
        }

        // Validate and update price
        if (productDetails.getPrice() != null && productDetails.getPrice() > 0) {
            existingProduct.setPrice(productDetails.getPrice());
        }

        // Validate and update quantity
        if (productDetails.getQuantity() != null && productDetails.getQuantity() >= 0) {
            existingProduct.setQuantity(productDetails.getQuantity());
            existingProduct.setInStock(productDetails.getQuantity() > 0);
        }

        // Validate and update SKU
        if (productDetails.getSku() != null && !productDetails.getSku().trim().isEmpty()) {
            // Check if SKU is already used by another product
            Optional<Product> existingSku = productRepository.findBySku(productDetails.getSku());
            if (existingSku.isPresent() && !existingSku.get().getId().equals(id)) {
                throw new IllegalArgumentException("SKU already exists");
            }
            existingProduct.setSku(productDetails.getSku());
        }

        // Validate and update product code
        if (productDetails.getProductCode() != null && !productDetails.getProductCode().trim().isEmpty()) {
            existingProduct.setProductCode(productDetails.getProductCode());
        }

        // Update description if provided
        if (productDetails.getDescription() != null) {
            existingProduct.setDescription(productDetails.getDescription());
        }

        // Update image URL if provided
        if (productDetails.getImageUrl() != null) {
            existingProduct.setImageUrl(productDetails.getImageUrl());
        }

        // Update discount if provided
        if (productDetails.getDiscount() != null && productDetails.getDiscount() >= 0) {
            existingProduct.setDiscount(productDetails.getDiscount());
        }

        // Update status if provided
        if (productDetails.getStatus() != null && !productDetails.getStatus().isEmpty()) {
            existingProduct.setStatus(productDetails.getStatus());
        }

        // Update is active if provided
        if (productDetails.getIsActive() != null) {
            existingProduct.setIsActive(productDetails.getIsActive());
        }

        // Update min quantity if provided
        if (productDetails.getMinQuantity() != null && productDetails.getMinQuantity() >= 0) {
            existingProduct.setMinQuantity(productDetails.getMinQuantity());
        }

        // Always update the modified timestamp
        existingProduct.setUpdatedAt(LocalDateTime.now());

        return productRepository.save(existingProduct);
    }

    // Delete product
    public void deleteProduct(Long id) {
        if (!productRepository.existsById(id)) {
            throw new IllegalArgumentException("Product not found");
        }
        productRepository.deleteById(id);
    }

    // Delete multiple products
    public void deleteMultipleProducts(List<Long> ids) {
        for (Long id : ids) {
            if (productRepository.existsById(id)) {
                productRepository.deleteById(id);
            }
        }
    }

    // Get products by price range
    public List<Product> getProductsByPriceRange(Double minPrice, Double maxPrice) {
        if (minPrice == null) minPrice = 0.0;
        if (maxPrice == null) maxPrice = Double.MAX_VALUE;
        return productRepository.findByPriceRange(minPrice, maxPrice);
    }

    // Advanced search
    public List<Product> advancedSearch(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllProducts();
        }
        return productRepository.advancedSearch(keyword);
    }

    // Get product statistics
    public ProductStatistics getStatistics() {
        List<Product> allProducts = getAllProducts();
        
        ProductStatistics stats = new ProductStatistics();
        stats.setTotalProducts(allProducts.size());
        stats.setActiveProducts(productRepository.findActiveProducts().size());
        stats.setOutOfStockProducts(getOutOfStockProducts().size());
        stats.setProductsWithDiscount(getProductsWithDiscount().size());
        
        // Calculate total inventory value
        double totalInventoryValue = 0;
        for (Product p : allProducts) {
            totalInventoryValue += (p.getPrice() * p.getQuantity());
        }
        stats.setTotalInventoryValue(totalInventoryValue);
        
        return stats;
    }

    // Helper class for statistics
    public static class ProductStatistics {
        private int totalProducts;
        private int activeProducts;
        private int outOfStockProducts;
        private int productsWithDiscount;
        private double totalInventoryValue;

        // Getters and setters
        public int getTotalProducts() {
            return totalProducts;
        }

        public void setTotalProducts(int totalProducts) {
            this.totalProducts = totalProducts;
        }

        public int getActiveProducts() {
            return activeProducts;
        }

        public void setActiveProducts(int activeProducts) {
            this.activeProducts = activeProducts;
        }

        public int getOutOfStockProducts() {
            return outOfStockProducts;
        }

        public void setOutOfStockProducts(int outOfStockProducts) {
            this.outOfStockProducts = outOfStockProducts;
        }

        public int getProductsWithDiscount() {
            return productsWithDiscount;
        }

        public void setProductsWithDiscount(int productsWithDiscount) {
            this.productsWithDiscount = productsWithDiscount;
        }

        public double getTotalInventoryValue() {
            return totalInventoryValue;
        }

        public void setTotalInventoryValue(double totalInventoryValue) {
            this.totalInventoryValue = totalInventoryValue;
        }
    }
}
