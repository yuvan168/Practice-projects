package com.example.demo.repo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Product;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
    
    // Search products by name
    @Query("SELECT p FROM Product p WHERE LOWER(p.productName) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<Product> searchByName(@Param("keyword") String keyword);
    
    // Search by SKU
    Optional<Product> findBySku(String sku);
    
    // Search by Product Code
    Optional<Product> findByProductCode(String productCode);
    
    // Get low stock products
    @Query("SELECT p FROM Product p WHERE p.quantity < :threshold")
    List<Product> getLowStockProducts(@Param("threshold") Integer threshold);
    
    // Complex search with multiple criteria
    @Query("SELECT p FROM Product p WHERE " +
           "LOWER(p.productName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(p.sku) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(p.productCode) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<Product> searchByKeyword(@Param("keyword") String keyword);

    // Find active products
    @Query("SELECT p FROM Product p WHERE p.isActive = true ORDER BY p.createdAt DESC")
    List<Product> findActiveProducts();
    
    // Find by price range
    @Query("SELECT p FROM Product p WHERE p.price BETWEEN :minPrice AND :maxPrice ORDER BY p.price ASC")
    List<Product> findByPriceRange(@Param("minPrice") Double minPrice, @Param("maxPrice") Double maxPrice);
    
    // Get out of stock products
    @Query("SELECT p FROM Product p WHERE p.quantity = 0 ORDER BY p.productName ASC")
    List<Product> findOutOfStockProducts();
    
    // Get products with discount
    @Query("SELECT p FROM Product p WHERE p.discount > 0 ORDER BY p.discount DESC")
    List<Product> findProductsWithDiscount();
    
    // Search with multiple criteria (name, description, sku, productCode)
    @Query("SELECT p FROM Product p WHERE " +
           "(LOWER(p.productName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(p.description) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(p.sku) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(p.productCode) LIKE LOWER(CONCAT('%', :keyword, '%'))) AND " +
           "p.isActive = true " +
           "ORDER BY p.createdAt DESC")
    List<Product> advancedSearch(@Param("keyword") String keyword);
    
    // Get in stock products
    @Query("SELECT p FROM Product p WHERE p.inStock = true AND p.isActive = true ORDER BY p.createdAt DESC")
    List<Product> findInStockProducts();
    
    // Get discounted products in stock
    @Query("SELECT p FROM Product p WHERE p.discount > 0 AND p.inStock = true AND p.isActive = true ORDER BY p.discount DESC")
    List<Product> getFeaturedProducts();
    
    // Get best sellers by quantity sold (approximate by discount)
    @Query("SELECT p FROM Product p WHERE p.isActive = true AND p.quantity > 0 ORDER BY p.quantity DESC")
    List<Product> getBestSellers();
    
    // Get new arrivals
    @Query("SELECT p FROM Product p WHERE p.isActive = true ORDER BY p.createdAt DESC")
    List<Product> getNewArrivals();
    
    // Find products by status
    @Query("SELECT p FROM Product p WHERE p.status = :status ORDER BY p.createdAt DESC")
    List<Product> findByStatus(@Param("status") String status);
}
