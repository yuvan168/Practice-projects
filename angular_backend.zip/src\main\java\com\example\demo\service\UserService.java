package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.User;
import com.example.demo.repo.UserRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    // Get all users
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    // Get user by ID
    public Optional<User> getUserById(Long id) {
        return userRepository.findById(id);
    }

    // Get user by email
    public Optional<User> getUserByEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            throw new IllegalArgumentException("Email is required");
        }
        return userRepository.findByEmail(email);
    }

    // Check if user exists by email
    public boolean emailExists(String email) {
        if (email == null || email.trim().isEmpty()) {
            return false;
        }
        return userRepository.existsByEmail(email);
    }

    // Create user
    public User createUser(User user) {
        // Validate email
        if (user.getEmail() == null || user.getEmail().trim().isEmpty()) {
            throw new IllegalArgumentException("Email is required");
        }

        // Check if email already exists
        if (userRepository.existsByEmail(user.getEmail())) {
            throw new IllegalArgumentException("Email already exists");
        }

        // Validate email format
        if (!isValidEmail(user.getEmail())) {
            throw new IllegalArgumentException("Invalid email format");
        }

        // Validate first name
        if (user.getFirstName() == null || user.getFirstName().trim().isEmpty()) {
            throw new IllegalArgumentException("First name is required");
        }

        // Validate last name
        if (user.getLastName() == null || user.getLastName().trim().isEmpty()) {
            throw new IllegalArgumentException("Last name is required");
        }

        // Set default values
        if (user.getIsActive() == null) {
            user.setIsActive(true);
        }

        // Set timestamps
        if (user.getCreatedAt() == null) {
            user.setCreatedAt(LocalDateTime.now());
        }
        if (user.getUpdatedAt() == null) {
            user.setUpdatedAt(LocalDateTime.now());
        }

        return userRepository.save(user);
    }

    // Update user
    public User updateUser(Long id, User userDetails) {
        Optional<User> userOpt = userRepository.findById(id);
        
        if (!userOpt.isPresent()) {
            throw new IllegalArgumentException("User not found");
        }

        User existingUser = userOpt.get();

        // Update email if provided and different
        if (userDetails.getEmail() != null && !userDetails.getEmail().trim().isEmpty()) {
            if (!userDetails.getEmail().equals(existingUser.getEmail())) {
                if (userRepository.existsByEmail(userDetails.getEmail())) {
                    throw new IllegalArgumentException("Email already exists");
                }
                if (!isValidEmail(userDetails.getEmail())) {
                    throw new IllegalArgumentException("Invalid email format");
                }
                existingUser.setEmail(userDetails.getEmail());
            }
        }

        // Update first name if provided
        if (userDetails.getFirstName() != null && !userDetails.getFirstName().trim().isEmpty()) {
            existingUser.setFirstName(userDetails.getFirstName());
        }

        // Update last name if provided
        if (userDetails.getLastName() != null && !userDetails.getLastName().trim().isEmpty()) {
            existingUser.setLastName(userDetails.getLastName());
        }

        // Update is active if provided
        if (userDetails.getIsActive() != null) {
            existingUser.setIsActive(userDetails.getIsActive());
        }

        // Always update the modified timestamp
        existingUser.setUpdatedAt(LocalDateTime.now());

        return userRepository.save(existingUser);
    }

    // Delete user
    public void deleteUser(Long id) {
        if (!userRepository.existsById(id)) {
            throw new IllegalArgumentException("User not found");
        }
        userRepository.deleteById(id);
    }

    // Delete multiple users
    public void deleteMultipleUsers(List<Long> ids) {
        for (Long id : ids) {
            if (userRepository.existsById(id)) {
                userRepository.deleteById(id);
            }
        }
    }

    // Get active users
    public List<User> getActiveUsers() {
        return userRepository.findAll().stream()
                .filter(user -> user.getIsActive() != null && user.getIsActive())
                .toList();
    }

    // Search users by name
    public List<User> searchUsersByName(String searchTerm) {
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return getAllUsers();
        }
        
        String lowerSearchTerm = searchTerm.toLowerCase();
        return userRepository.findAll().stream()
                .filter(user -> 
                    (user.getFirstName() != null && user.getFirstName().toLowerCase().contains(lowerSearchTerm)) ||
                    (user.getLastName() != null && user.getLastName().toLowerCase().contains(lowerSearchTerm)) ||
                    (user.getEmail() != null && user.getEmail().toLowerCase().contains(lowerSearchTerm))
                )
                .toList();
    }

    // Get user count
    public long getUserCount() {
        return userRepository.count();
    }

    // Get active user count
    public long getActiveUserCount() {
        return userRepository.findAll().stream()
                .filter(user -> user.getIsActive() != null && user.getIsActive())
                .count();
    }

    // Helper method to validate email format
    private boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@([A-Za-z0-9.-]+\\.[A-Za-z]{2,})$";
        return email.matches(emailRegex);
    }

    // Get user statistics
    public UserStatistics getUserStatistics() {
        List<User> allUsers = getAllUsers();
        
        UserStatistics stats = new UserStatistics();
        stats.setTotalUsers(allUsers.size());
        stats.setActiveUsers((int) getActiveUserCount());
        stats.setInactiveUsers(allUsers.size() - (int) getActiveUserCount());
        
        return stats;
    }

    // Helper class for user statistics
    public static class UserStatistics {
        private int totalUsers;
        private int activeUsers;
        private int inactiveUsers;

        // Getters and setters
        public int getTotalUsers() {
            return totalUsers;
        }

        public void setTotalUsers(int totalUsers) {
            this.totalUsers = totalUsers;
        }

        public int getActiveUsers() {
            return activeUsers;
        }

        public void setActiveUsers(int activeUsers) {
            this.activeUsers = activeUsers;
        }

        public int getInactiveUsers() {
            return inactiveUsers;
        }

        public void setInactiveUsers(int inactiveUsers) {
            this.inactiveUsers = inactiveUsers;
        }
    }
}
